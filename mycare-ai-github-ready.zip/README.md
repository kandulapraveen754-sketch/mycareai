# MyCare AI 🩺
### *Your Health. Your Care. Your Family.*

[![License: MIT](https://img.shields.io/badge/License-MIT-teal.svg)](LICENSE)
[![React](https://img.shields.io/badge/React-18.3-blue.svg)](https://react.dev)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.6-blue.svg)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/TailwindCSS-3.4-38bdf8.svg)](https://tailwindcss.com/)
[![Google Gemini](https://img.shields.io/badge/AI-Google_Gemini-orange.svg)](https://ai.google.dev/)
[![Status](https://img.shields.io/badge/Status-Production_Ready-emerald.svg)]()

> **MyCare AI** is an intelligent, compassionate elderly healthcare and safety ecosystem connecting elderly loved ones, family members, caregivers, doctors, and pharmacy services through one unified, accessible platform.

---

## 🌟 Key Innovations & Features

### 1. 🎨 Warm, Accessible Healthcare Design System
- **Color Palette:** Warm cream background (`#F5F0E6`), Deep teal sidebar (`#174F4A`), Sage green (`#DDE8D7`), Peach (`#F3D5C2`), Terracotta (`#C77B5A`), Muted mustard (`#E5C477`), and Soft lavender (`#E5DDF0`).
- **Elderly-Friendly Mode:** One-click toggle that scales typography, enlarges primary touch targets, activates high-contrast borders, and simplifies card navigation.
- **Multilingual Support:** Full UI and speech support for **English**, **Telugu (తెలుగు)**, and **Hindi (हिन्दी)**.

### 2. 💊 Medication Management & Daily Dose Tracking
- Daily scheduled routines segmented into **Morning**, **Afternoon**, **Evening**, and **Night**.
- **Interactive Tracking:** "Mark as Taken" with celebratory confetti, "Skip with Reason" modal, inventory tracking, refill alerts, and daily/weekly adherence calculations.
- Comprehensive prescription details: Prescribed doctor, dosage form, strength, instructions, and pill stock.

### 3. 📷 AI Medicine Photo Scanner
- **Gemini Vision & OCR Engine:** Recognizes medicine packaging front, extracts salt name, brand, strength (mg/mcg), dosage form, and manufacturer.
- **1-Click Test Presets:** Test instant scanning with 5 built-in packaging samples (Telmikind 40, Glycomet 500 SR, Dolo 650, Pan 40, Blurry sample) without requiring a webcam!
- **Catalogue Matching & Cart Addition:** Matches extracted packaging against pharmacy stock with match confidence scores and safety verification warnings.
- **Medical Safety Guardrails:** Strict disclaimers preventing misidentification or taking unverified pills.

### 4. 🛍️ Medicine Ordering & Senior Pharmacy
- Complete pharmacy catalogue across Cardiac, Diabetes, Pain Relief, Vitamins, Digestive, and General categories.
- Real-time stock levels, Schedule H prescription check, senior doorstep delivery discounts.
- **7-Stage Live Order Tracking:** *Pending → Confirmed → Prescription Verification → Packed → Shipped → Out for Delivery → Delivered*.
- Reorder past medications in one click.

### 5. 👨‍⚕️ Doctor Appointment Booking
- Directory of verified geriatricians, senior cardiologists, diabetologists, neurologists, orthopedics, and ophthalmologists.
- Real available date and time slots with double-booking prevention.
- Choose between **In-Person Clinic Consultation** and **Video Teleconsultation**.
- Reschedule or cancel appointments at any time.

### 6. 🤖 Multilingual Voice & AI Guardian
- Conversational assistant powered by Google Gemini API with access to live patient clinical context.
- Understands today's schedule, pending doses, next appointments, and weekly adherence.
- **Speech-to-Text & Text-to-Speech:** Speak in English, Telugu, or Hindi using the large microphone button, with speech review before sending.
- Clinical boundaries: Guided triage directing emergencies to 112/108 without fabricating diagnoses.

### 7. 👨‍👩‍👧 Family Circle & Care Coordination
- Connect family guardians (e.g. daughter Priya) and certified nurses (Sister Anjali).
- Fine-grained permission controls: View vitals, manage medicines, book appointments, receive emergency SOS.
- Collaborative care task board with assignment, due dates, urgency flags, and completion logs.

### 8. 🚨 Emergency Shield (Immediate SOS)
- Massive Emergency SOS button with 1-touch broadcast.
- Real-time GPS location dispatch (Banjara Hills, Hyderabad).
- Instant phone call shortcuts to primary family contacts and ambulance hotlines (112, 108, 1066).
- Status lifecycle: *Initiated → Sent → Acknowledged → Resolved*.

### 9. 📊 Health Insights & Reports
- Interactive Recharts visualizing 7-day adherence trends, blood pressure curves, pulse, blood glucose, and oxygen saturation (SpO2).
- One-click **Print / Download Clinical Summary Report** formatted for hospital visits.

---

## 👥 Demo Personas & Credentials

Switch seamlessly between all 4 roles using the **Role Switcher** in the top navigation or sidebar:

| Role | Persona | Details | Primary Capabilities |
| :--- | :--- | :--- | :--- |
| **Elderly Member** | **Ramesh Sharma** (74 yrs) | Hypertension, Type 2 Diabetes, Hyderabad | Mark doses, use Voice AI Guardian, order medicines, trigger SOS |
| **Family Guardian** | **Priya Sharma** (Daughter) | Resides in Bengaluru, primary contact | Monitor vitals, track adherence, order refills, receive alerts |
| **Care Nurse** | **Sister Anjali Rao** | Certified Geriatric Caregiver, Hyderabad | Record vitals (BP, sugar), complete care tasks, confirm doses |
| **Medical Admin** | **Dr. Vikram Patel** | Chief Medical Officer, Apollo Elder Care | Manage doctors, review audit trails, update medicine catalogue |

---

## 🏗️ System Architecture & Technology Stack

```
                     ┌────────────────────────────────────────────────┐
                     │          MYCARE AI CLIENT (React 18)           │
                     │  TypeScript • Tailwind CSS • Lucide • Recharts │
                     └───────────────────────┬────────────────────────┘
                                             │
                       ┌─────────────────────┴─────────────────────┐
                       ▼                                           ▼
      ┌─────────────────────────────────┐         ┌─────────────────────────────────┐
      │     Multilingual Voice Engine   │         │    AI Guardian & Vision Scanner │
      │  SpeechRecognition + Synthesis  │         │   Gemini 1.5/2.0 API + OCR      │
      │  (English, Telugu, Hindi)       │         │   Clinical Context Injection    │
      └─────────────────────────────────┘         └────────────────┬────────────────┘
                                                                   │
                                                                   ▼
                                                  ┌─────────────────────────────────┐
                                                  │       Unified Express Server    │
                                                  │   REST API (/api/guardian,      │
                                                  │   /api/scanner, /api/health)    │
                                                  └─────────────────────────────────┘
```

---

## 🚀 Quick Start Guide

### Prerequisites
- **Node.js** (v18 or higher)
- **npm** (v9 or higher)

### 1. Installation
```bash
# Navigate to the project directory
cd "C:\Users\Praveen Kandula\.gemini\antigravity\scratch\mycare-ai"

# Dependencies are already installed! If needed:
npm install
```

### 2. Configure Environment (Optional)
A `.env` file is prepared. To connect live Google Gemini API credentials:
```env
PORT=5000
GEMINI_API_KEY=your_gemini_api_key_here
```
*(Note: If `GEMINI_API_KEY` is omitted, MyCare AI automatically runs its built-in clinical rule engine for 100% functionality!)*

### 3. Run Application
```bash
# Option A: Start production unified server (Frontend + Backend on http://localhost:5000)
npm run server

# Option B: Run Vite development server
npm run dev

# Option C: Windows 1-Click Launch
Double-click "start-mycare.bat"
```

Open **`http://localhost:5000`** (or `http://localhost:3000` for Vite dev) in your web browser.

---

## 🧪 20 User Journeys Verified

1. ✅ **Register & Log In:** Switch between Senior, Family, Caregiver, and Admin personas in 1 click.
2. ✅ **Elderly Profile:** View Ramesh Sharma's age, blood group (O+), conditions, and allergies.
3. ✅ **Add a Medicine:** Fill in medicine name, dosage, schedule times, and refill thresholds.
4. ✅ **Set Schedule:** Filter doses by Morning, Afternoon, Evening, and Night.
5. ✅ **Mark as Taken:** Instant dose logging with celebratory confetti animation.
6. ✅ **Skip Dose:** Record clinical reasons (e.g. stomach sensitivity) with notification alerts.
7. ✅ **Caregiver Escalation:** Real-time logging of doses and vital updates.
8. ✅ **Scan Medicine Photo:** Open camera, upload photo, or test with 1-click packaging presets.
9. ✅ **Verify Match:** Extract text, recognize strength and brand with confidence percentage.
10. ✅ **Add to Cart:** Add verified packaging directly to the pharmacy shopping cart.
11. ✅ **Complete Order:** Doorstep delivery checkout with prescription verification.
12. ✅ **Search Doctors:** Filter specialists across Geriatrics, Cardiology, and Endocrinology.
13. ✅ **Book Appointment:** Choose between In-person Clinic and Video Teleconsultation.
14. ✅ **Ask AI Guardian:** Live query answering on medicines, next visits, and adherence.
15. ✅ **Multilingual Voice:** Test Telugu (`తెలుగు`) and Hindi (`हिन्दी`) speech recognition.
16. ✅ **Connect Family:** Invite members with relation details and permission grants.
17. ✅ **Assign Care Tasks:** Delegate morning BP check and walking assistance to Sister Anjali.
18. ✅ **Emergency SOS:** Trigger full emergency broadcast with GPS location.
19. ✅ **Health Insights:** Review weekly adherence charts, vitals curves, and export summaries.
20. ✅ **Accessibility Settings:** Toggle Elderly-Friendly Mode, font scaling, and voice auto-speak.

---

## 🛡️ Medical Safety & Privacy Disclaimers

- **Non-Diagnostic Nature:** MyCare AI Guardian assists in routine management, reminders, and patient record synthesis. It does not replace certified medical diagnosis or physician evaluation.
- **Schedule H Drugs:** Prescription medications require pharmacist verification in accordance with the Indian Drugs and Cosmetics Act.
- **Emergency Situations:** In acute medical crises (e.g., chest pain, shortness of breath, loss of consciousness), users are guided to press the **EMERGENCY SOS** button or immediately call **112 / 108 / 1066**.

---

## 📢 Hackathon LinkedIn Post Draft

```
🌟 Introducing MyCare AI — Your Health. Your Care. Your Family. 🩺👵👴

Elderly healthcare is too often fragmented: forgotten medicines, confusing pill packages, scattered doctor appointments, and delayed emergency communication.

To solve this, I built MyCare AI — an intelligent, compassionate healthcare ecosystem designed specifically for older adults and their care circles.

✨ Core Highlights:
• 🎨 Warm, Accessible Healthcare UX: Custom cream/deep teal palette with 1-click Elderly-Friendly Mode (large text, high contrast, simplified touch navigation).
• 💊 Smart Medication Engine: Morning, Afternoon, Evening, and Night routines with unconfirmed-dose escalation and adherence analytics.
• 📷 AI Medicine Photo Scanner: Powered by Google Gemini Vision & OCR to recognize packaging, extract strength & dosage, and match pharmacy stock.
• 🎙️ Multilingual Voice Guardian: Speech-to-Text & Text-to-Speech in English, Telugu (తెలుగు), and Hindi (हिन्दी) connected to patient clinical context.
• 🛍️ Senior Pharmacy & Orders: Prescription verification (Schedule H), senior discounts, and 7-stage live delivery tracking.
• 👨‍⚕️ Specialist Appointments: Double-booking prevention for in-person clinic and teleconsultations.
• 🚨 Emergency Shield: 1-touch SOS broadcast with GPS coordinates and direct ambulance shortcuts.
• 👨‍👩‍👧 Family & Caregiver Circle: Shared care tasks, vitals tracking, and permission management.

Built with React 18, TypeScript, Tailwind CSS, Node.js Express, and Google Gemini API.

#Healthcare #AI #ElderCare #GoogleGemini #React #Accessibility #MedTech #Innovation #Hackathon
```

---

*MyCare AI — Empowering seniors to live healthy, independent, and connected lives.*
