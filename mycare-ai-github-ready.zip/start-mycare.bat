@echo off
title MyCare AI — Elderly Healthcare and Safety Ecosystem
echo ========================================================
echo   MYCARE AI — Your Health. Your Care. Your Family.
echo ========================================================
echo.
echo Starting MyCare AI Unified Server (Frontend + Backend)...
echo Opening http://localhost:5000 in your browser...
echo.

start "" "http://localhost:5000"
node server/index.js

pause
