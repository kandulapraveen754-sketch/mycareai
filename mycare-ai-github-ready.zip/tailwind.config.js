/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        cream: {
          50: '#FAF7F2',
          100: '#F5F0E6', // Warm cream background
          200: '#EDE4D5', // Soft beige
          300: '#E4D6C0',
        },
        teal: {
          850: '#174F4A', // Deep teal sidebar
          900: '#123D39',
          700: '#286B61', // Teal accent
          600: '#348B7E',
          500: '#42A899',
        },
        sage: {
          50: '#F4F7F3',
          100: '#DDE8D7', // Sage green
          200: '#C7D9C0',
          300: '#B9D0B5', // Soft green
          600: '#4F794A',
          700: '#3D5E39',
        },
        peach: {
          50: '#FCF5F0',
          100: '#F3D5C2', // Peach accent
          200: '#ECC0A6',
          400: '#D89874',
          500: '#C77B5A', // Terracotta
          600: '#B26444',
          700: '#8C4B30',
        },
        mustard: {
          100: '#F9F1DC',
          200: '#F0E2BA',
          300: '#E5C477', // Muted mustard
          500: '#C99E39',
          600: '#A47E24',
        },
        lavender: {
          100: '#E5DDF0', // Soft lavender
          200: '#D2C3E5',
          300: '#BAA2D7',
          700: '#69488F',
        },
        charcoal: {
          900: '#1F2725',
          800: '#293431', // Deep charcoal text
          700: '#3B4844',
          600: '#566661',
          400: '#839590',
          200: '#C7D1CE',
        }
      },
      fontFamily: {
        sans: ['Plus Jakarta Sans', 'Inter', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
        display: ['Outfit', 'Plus Jakarta Sans', 'sans-serif']
      },
      boxShadow: {
        'card': '0 4px 20px -2px rgba(23, 79, 74, 0.06), 0 2px 6px -1px rgba(23, 79, 74, 0.04)',
        'card-hover': '0 10px 25px -4px rgba(23, 79, 74, 0.10), 0 4px 10px -2px rgba(23, 79, 74, 0.05)',
        'modal': '0 20px 40px -8px rgba(23, 79, 74, 0.20)',
        'glow': '0 0 15px rgba(40, 107, 97, 0.35)',
        'sos': '0 0 25px rgba(199, 123, 90, 0.5)'
      }
    },
  },
  plugins: [],
}
