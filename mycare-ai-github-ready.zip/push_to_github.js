import fs from 'fs';
import path from 'path';

const GITHUB_TOKEN = process.argv[2] || process.env.GITHUB_TOKEN;
const REPO_NAME = process.argv[3] || 'mycare-ai';
const IS_PRIVATE = process.argv[4] === 'private';

if (!GITHUB_TOKEN) {
  console.log(`
Usage:
  node push_to_github.js <YOUR_GITHUB_PERSONAL_ACCESS_TOKEN> [repo-name] [public|private]

Example:
  node push_to_github.js ghp_xxxxxxxxxxxxxxxxxxxx mycare-ai public
`);
  process.exit(1);
}

const headers = {
  'Authorization': `Bearer ${GITHUB_TOKEN}`,
  'Accept': 'application/vnd.github.v3+json',
  'User-Agent': 'MyCareAI-Uploader',
  'Content-Type': 'application/json'
};

const baseDir = 'C:\\Users\\Praveen Kandula\\Desktop\\mycare-ai-github-ready';

const ignoreList = new Set([
  'node_modules',
  'dist',
  '.env',
  '.git',
  '.DS_Store'
]);

function getAllFiles(dir, fileList = []) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    if (ignoreList.has(entry.name)) continue;
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      getAllFiles(fullPath, fileList);
    } else if (entry.isFile()) {
      fileList.push(fullPath);
    }
  }
  return fileList;
}

async function run() {
  try {
    console.log('1. Checking GitHub authentication...');
    const userRes = await fetch('https://api.github.com/user', { headers });
    if (!userRes.ok) {
      const err = await userRes.text();
      throw new Error(`Authentication failed (${userRes.status}): ${err}`);
    }
    const user = await userRes.json();
    console.log(` Authenticated as GitHub user: @${user.login}`);

    console.log(`2. Checking repository "${user.login}/${REPO_NAME}"...`);
    let repoRes = await fetch(`https://api.github.com/repos/${user.login}/${REPO_NAME}`, { headers });
    let repoData;

    if (repoRes.status === 404) {
      console.log(`Creating new repository "${REPO_NAME}"...`);
      const createRes = await fetch('https://api.github.com/user/repos', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          name: REPO_NAME,
          description: 'MyCare AI — Intelligent Elderly Healthcare & Safety Platform. Your Health. Your Care. Your Family.',
          private: IS_PRIVATE,
          auto_init: true
        })
      });
      if (!createRes.ok) {
        throw new Error(`Failed to create repo: ${await createRes.text()}`);
      }
      repoData = await createRes.json();
      console.log(` Repository created: ${repoData.html_url}`);
      // Wait 2 seconds for GitHub to initialize default branch
      await new Promise(r => setTimeout(r, 2000));
    } else if (repoRes.ok) {
      repoData = await repoRes.json();
      console.log(` Repository exists: ${repoData.html_url}`);
    } else {
      throw new Error(`Failed to inspect repo: ${await repoRes.text()}`);
    }

    console.log('3. Gathering files to push...');
    const allFiles = getAllFiles(baseDir);
    console.log(`Found ${allFiles.length} files to upload.`);

    // Get current main commit SHA
    let parentCommitSha = null;
    let baseTreeSha = null;
    const refRes = await fetch(`https://api.github.com/repos/${user.login}/${REPO_NAME}/git/ref/heads/main`, { headers });
    if (refRes.ok) {
      const refData = await refRes.json();
      parentCommitSha = refData.object.sha;
      const commitRes = await fetch(`https://api.github.com/repos/${user.login}/${REPO_NAME}/git/commits/${parentCommitSha}`, { headers });
      if (commitRes.ok) {
        const commitData = await commitRes.json();
        baseTreeSha = commitData.tree.sha;
      }
    }

    console.log('4. Uploading file blobs...');
    const treeItems = [];
    for (let i = 0; i < allFiles.length; i++) {
      const file = allFiles[i];
      const relPath = path.relative(baseDir, file).replace(/\\/g, '/');
      const content = fs.readFileSync(file);
      const isBinary = file.match(/\.(png|jpg|jpeg|gif|ico|webp|svg|woff|woff2|ttf|eot)$/i);

      let blobData;
      if (isBinary) {
        const blobRes = await fetch(`https://api.github.com/repos/${user.login}/${REPO_NAME}/git/blobs`, {
          method: 'POST',
          headers,
          body: JSON.stringify({
            content: content.toString('base64'),
            encoding: 'base64'
          })
        });
        blobData = await blobRes.json();
      } else {
        const blobRes = await fetch(`https://api.github.com/repos/${user.login}/${REPO_NAME}/git/blobs`, {
          method: 'POST',
          headers,
          body: JSON.stringify({
            content: content.toString('utf-8'),
            encoding: 'utf-8'
          })
        });
        blobData = await blobRes.json();
      }

      treeItems.push({
        path: relPath,
        mode: '100644',
        type: 'blob',
        sha: blobData.sha
      });

      if ((i + 1) % 10 === 0 || i === allFiles.length - 1) {
        process.stdout.write(` Uploaded ${i + 1}/${allFiles.length} files...\r`);
      }
    }
    console.log('\n All files uploaded successfully.');

    console.log('5. Creating Git tree...');
    const treeRes = await fetch(`https://api.github.com/repos/${user.login}/${REPO_NAME}/git/trees`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        tree: treeItems
      })
    });
    if (!treeRes.ok) throw new Error(`Tree creation failed: ${await treeRes.text()}`);
    const newTree = await treeRes.json();

    console.log('6. Creating commit...');
    const commitBody = {
      message: 'feat: initial commit - MyCare AI complete healthcare platform',
      tree: newTree.sha
    };
    if (parentCommitSha) {
      commitBody.parents = [parentCommitSha];
    }
    const commitRes = await fetch(`https://api.github.com/repos/${user.login}/${REPO_NAME}/git/commits`, {
      method: 'POST',
      headers,
      body: JSON.stringify(commitBody)
    });
    if (!commitRes.ok) throw new Error(`Commit creation failed: ${await commitRes.text()}`);
    const newCommit = await commitRes.json();

    console.log('7. Updating main branch...');
    const updateRefRes = await fetch(`https://api.github.com/repos/${user.login}/${REPO_NAME}/git/refs/heads/main`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify({
        sha: newCommit.sha,
        force: true
      })
    });

    if (!updateRefRes.ok) {
      // If ref didn't exist, create it
      await fetch(`https://api.github.com/repos/${user.login}/${REPO_NAME}/git/refs`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          ref: 'refs/heads/main',
          sha: newCommit.sha
        })
      });
    }

    console.log('\n==================================================');
    console.log(` SUCCESS! Repository is live at:`);
    console.log(` ${repoData.html_url}`);
    console.log('==================================================\n');
  } catch (e) {
    console.error('Error pushing to GitHub:', e.message);
    process.exit(1);
  }
}

run();
