$rootDir = "C:\Users\Praveen Kandula\.gemini\antigravity\scratch\mycare-ai"
$desktop = "C:\Users\Praveen Kandula\Desktop"
$targetFolder = "$desktop\mycare-ai-github-ready"
$targetZip = "$desktop\mycare-ai-github-ready.zip"

node "$rootDir\package_github.js"

if (Test-Path $targetZip) {
    Remove-Item $targetZip -Force
}

Compress-Archive -Path "$targetFolder\*" -DestinationPath $targetZip -Force
Write-Output "Zip created at: $targetZip"
