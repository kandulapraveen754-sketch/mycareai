// ==========================================
// MYCARE AI - MULTILINGUAL TRANSLATION SYSTEM
// Supports: English, Telugu (తెలుగు), Hindi (हिन्दी)
// ==========================================

import { LanguageCode } from '../types';

export interface Translations {
  appName: string;
  tagline: string;
  // Navigation
  dashboard: string;
  myHealth: string;
  medicines: string;
  medicineOrdering: string;
  aiGuardian: string;
  doctorAppointments: string;
  familyCircle: string;
  healthInsights: string;
  emergencySos: string;
  notifications: string;
  settings: string;
  logout: string;
  // Dashboard Sections
  welcomeGreeting: string;
  goodMorning: string;
  goodAfternoon: string;
  goodEvening: string;
  healthSafetyNote: string;
  todaysMedicines: string;
  nextAppointment: string;
  medicationAdherence: string;
  familyCaregiverStatus: string;
  markAsTaken: string;
  taken: string;
  pending: string;
  missed: string;
  skipped: string;
  skipDose: string;
  // AI Guardian
  askGuardian: string;
  aiGuardianSub: string;
  voiceInput: string;
  listening: string;
  speakNow: string;
  typeYourMessage: string;
  send: string;
  suggestedQuestions: string;
  // Emergency
  emergencyShield: string;
  sosAlert: string;
  holdToTrigger: string;
  emergencyNotice: string;
  callDoctor: string;
  callFamily: string;
  // Elderly Friendly
  elderlyMode: string;
  normalMode: string;
  largeText: string;
  // Pharmacy & Scan
  scanMedicine: string;
  browseMedicines: string;
  searchMedicines: string;
  addToCart: string;
  cart: string;
  checkout: string;
  orders: string;
  // Doctors
  bookDoctor: string;
  findSpecialist: string;
  confirmBooking: string;
  reschedule: string;
  cancel: string;
}

export const translations: Record<LanguageCode, Translations> = {
  en: {
    appName: "MyCare AI",
    tagline: "Your Health. Your Care. Your Family.",
    dashboard: "Dashboard",
    myHealth: "My Health",
    medicines: "Medicines",
    medicineOrdering: "Medicine Ordering",
    aiGuardian: "AI Guardian",
    doctorAppointments: "Doctor Appointments",
    familyCircle: "Family Circle",
    healthInsights: "Health Insights",
    emergencySos: "Emergency SOS",
    notifications: "Notifications",
    settings: "Settings",
    logout: "Logout",
    welcomeGreeting: "Welcome back",
    goodMorning: "Good morning",
    goodAfternoon: "Good afternoon",
    goodEvening: "Good evening",
    healthSafetyNote: "Your blood pressure is stable. Next medicine dose is in 45 minutes.",
    todaysMedicines: "Today's Medicines",
    nextAppointment: "Next Appointment",
    medicationAdherence: "Medication Adherence",
    familyCaregiverStatus: "Family & Caregiver",
    markAsTaken: "Mark as Taken",
    taken: "Taken",
    pending: "Pending",
    missed: "Missed",
    skipped: "Skipped",
    skipDose: "Skip Dose",
    askGuardian: "Ask AI Guardian",
    aiGuardianSub: "Your personal voice-enabled health companion",
    voiceInput: "Voice Assistant",
    listening: "Listening...",
    speakNow: "Speak now in English, Telugu, or Hindi",
    typeYourMessage: "Type your health query...",
    send: "Send",
    suggestedQuestions: "Quick questions to ask:",
    emergencyShield: "Emergency Shield",
    sosAlert: "Trigger Emergency SOS",
    holdToTrigger: "Press & hold 3 seconds to alert family and caregivers",
    emergencyNotice: "Simulated emergency alert will notify designated contacts with GPS location.",
    callDoctor: "Call Doctor",
    callFamily: "Call Family",
    elderlyMode: "Elderly-Friendly Mode",
    normalMode: "Standard Mode",
    largeText: "Large Text & High Contrast",
    scanMedicine: "Scan Medicine Packaging",
    browseMedicines: "Browse Pharmacy Catalogue",
    searchMedicines: "Search medicines, brands, symptoms...",
    addToCart: "Add to Cart",
    cart: "Cart",
    checkout: "Proceed to Checkout",
    orders: "My Orders",
    bookDoctor: "Book Appointment",
    findSpecialist: "Find a Specialist",
    confirmBooking: "Confirm Booking",
    reschedule: "Reschedule",
    cancel: "Cancel",
  },
  te: {
    appName: "మైకేర్ AI (MyCare AI)",
    tagline: "మీ ఆరోగ్యం. మీ సంరక్షణ. మీ కుటుంబం.",
    dashboard: "డ్యాష్‌బోర్డ్",
    myHealth: "నా ఆరోగ్యం",
    medicines: "మందులు",
    medicineOrdering: "మందుల ఆర్డర్",
    aiGuardian: "AI గార్డియన్",
    doctorAppointments: "డాక్టర్ అపాయింట్‌మెంట్లు",
    familyCircle: "కుటుంబ సర్కిల్",
    healthInsights: "ఆరోగ్య నివేదికలు",
    emergencySos: "ఎమర్జెన్సీ SOS",
    notifications: "నోటిఫికేషన్లు",
    settings: "సెట్టింగులు",
    logout: "లాగ్ అవుట్",
    welcomeGreeting: "స్వాగతం",
    goodMorning: "శుభోదయం",
    goodAfternoon: "శుభ మధ్యాహ్నం",
    goodEvening: "శుభ సాయంత్రం",
    healthSafetyNote: "మీ రక్తపోటు స్థిరంగా ఉంది. తదుపరి మందు 45 నిమిషాల్లో వేసుకోవాలి.",
    todaysMedicines: "నేటి మందులు",
    nextAppointment: "తదుపరి అపాయింట్‌మెంట్",
    medicationAdherence: "మందుల క్రమశిక్షణ",
    familyCaregiverStatus: "కుటుంబం & సంరక్షకుడు",
    markAsTaken: "తీసుకున్నట్లు గుర్తించు",
    taken: "వేసుకున్నారు",
    pending: "వేసుకోవాలి",
    missed: "మిస్ అయింది",
    skipped: "వదిలేశారు",
    skipDose: "డోస్ దాటవేయి",
    askGuardian: "AI గార్డియన్‌ను అడగండి",
    aiGuardianSub: "మీ వ్యక్తిగత ఆరోగ్య సహాయకుడు",
    voiceInput: "వాయిస్ అసిస్టెంట్",
    listening: "వింటోంది...",
    speakNow: "తెలుగు, హిందీ లేదా ఇంగ్లీషులో మాట్లాడండి",
    typeYourMessage: "మీ ఆరోగ్య ప్రశ్నను ఇక్కడ రాయండి...",
    send: "పంపు",
    suggestedQuestions: "త్వరిత ప్రశ్నలు:",
    emergencyShield: "ఎమర్జెన్సీ షీల్డ్",
    sosAlert: "ఎమర్జెన్సీ SOS పంపు",
    holdToTrigger: "కుటుంబ సభ్యులకు సమాచారం అందించడానికి 3 సెకన్లు నొక్కి పట్టుకోండి",
    emergencyNotice: "ఈ హెచ్చరిక ద్వారా కుటుంబ సభ్యులకు మరియు కేర్‌గివర్‌కు సమాచారం వెళ్తుంది.",
    callDoctor: "డాక్టర్‌కు కాల్ చేయండి",
    callFamily: "కుటుంబానికి కాల్ చేయండి",
    elderlyMode: "పెద్దల సులభ మోడ్",
    normalMode: "సాధారణ మోడ్",
    largeText: "పెద్ద అక్షరాలు & స్పష్టమైన రంగులు",
    scanMedicine: "మందు ప్యాకెట్‌ను స్కాన్ చేయండి",
    browseMedicines: "మందుల జాబితా చూడండి",
    searchMedicines: "మందులు, బ్రాండ్‌లను శోధించండి...",
    addToCart: "కార్ట్‌కు జోడించు",
    cart: "కార్ట్",
    checkout: "ఆర్డర్ పూర్తి చేయండి",
    orders: "నా ఆర్డర్లు",
    bookDoctor: "అపాయింట్‌మెంట్ బుక్ చేయండి",
    findSpecialist: "స్పెషలిస్ట్‌ను ఎంచుకోండి",
    confirmBooking: "బుకింగ్ నిర్ధారించండి",
    reschedule: "సమయం మార్చు",
    cancel: "రద్దు చేయి",
  },
  hi: {
    appName: "माइकेयर AI (MyCare AI)",
    tagline: "आपका स्वास्थ्य। आपकी देखभाल। आपका परिवार।",
    dashboard: "डैशबोर्ड",
    myHealth: "मेरा स्वास्थ्य",
    medicines: "दवाइयाँ",
    medicineOrdering: "दवा ऑर्डर",
    aiGuardian: "AI गार्जियन",
    doctorAppointments: "डॉक्टर अपॉइंटमेंट",
    familyCircle: "परिवार मंडल",
    healthInsights: "स्वास्थ्य रिपोर्ट",
    emergencySos: "आपातकालीन SOS",
    notifications: "सूचनाएँ",
    settings: "सेटिंग्स",
    logout: "लॉग आउट",
    welcomeGreeting: "स्वागत है",
    goodMorning: "शुभ प्रभात",
    goodAfternoon: "शुभ दोपहर",
    goodEvening: "शुभ संध्या",
    healthSafetyNote: "आपका रक्तचाप स्थिर है। अगली दवा 45 मिनट में लेनी है।",
    todaysMedicines: "आज की दवाइयाँ",
    nextAppointment: "अगला अपॉइंटमेंट",
    medicationAdherence: "दवा नियमिता",
    familyCaregiverStatus: "परिवार एवं देखभालकर्ता",
    markAsTaken: "दवा ली गई",
    taken: "ली गई",
    pending: "बाकी है",
    missed: "छूट गई",
    skipped: "छोड़ी गई",
    skipDose: "खुराक छोड़ें",
    askGuardian: "AI गार्जियन से पूछें",
    aiGuardianSub: "आपका व्यक्तिगत वॉइस स्वास्थ्य साथी",
    voiceInput: "वॉइस असिस्टेंट",
    listening: "सुन रहा हूँ...",
    speakNow: "हिंदी, तेलुगु या अंग्रेज़ी में बोलें",
    typeYourMessage: "अपना स्वास्थ्य प्रश्न पूछें...",
    send: "भेजें",
    suggestedQuestions: "सुझाए गए प्रश्न:",
    emergencyShield: "इमरजेंसी शील्ड",
    sosAlert: "इमरजेंसी SOS भेजें",
    holdToTrigger: "परिवार को सतर्क करने के लिए 3 सेकंड दबाकर रखें",
    emergencyNotice: "आपातकालीन सूचना जीपीएस लोकेशन के साथ परिवार को भेजी जाएगी।",
    callDoctor: "डॉक्टर को कॉल करें",
    callFamily: "परिवार को कॉल करें",
    elderlyMode: "वरिष्ठ नागरिक सुलभ मोड",
    normalMode: "सामान्य मोड",
    largeText: "बड़ा टेक्स्ट और उच्च कंट्रास्ट",
    scanMedicine: "दवा पैकेट स्कैन करें",
    browseMedicines: "दवा कैटलॉग देखें",
    searchMedicines: "दवा या ब्रांड खोजें...",
    addToCart: "कार्ट में जोड़ें",
    cart: "कार्ट",
    checkout: "ऑर्डर पूरा करें",
    orders: "मेरे ऑर्डर्स",
    bookDoctor: "अपॉइंटमेंट बुक करें",
    findSpecialist: "विशेषज्ञ डॉक्टर चुनें",
    confirmBooking: "बुकिंग कन्फर्म करें",
    reschedule: "समय बदलें",
    cancel: "रद्द करें",
  }
};
