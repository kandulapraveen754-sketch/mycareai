// ==========================================
// MYCARE AI - REALISTIC HEALTHCARE DEMO DATA
// Patient: Ramesh Sharma (74 yrs), Hyderabad
// ==========================================

import {
  UserProfile,
  ScheduledDose,
  Medicine,
  MedicineCatalogueItem,
  Doctor,
  Appointment,
  CareTask,
  FamilyMember,
  EmergencyContact,
  NotificationItem,
  HealthVital,
  Order
} from '../types';

export const mockUsers: Record<string, UserProfile> = {
  elderly: {
    id: "usr_demo_elderly",
    name: "Ramesh Sharma [DEMO PATIENT]",
    email: "demo.senior@mycare.ai",
    phone: "+91 98000 DEMO1",
    role: "elderly",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=256&q=80",
    age: 74,
    gender: "Male",
    city: "Banjara Hills, Hyderabad [DEMO]",
    bloodGroup: "O+",
    conditions: ["Hypertension (Grade 1)", "Type 2 Diabetes (Managed)", "Mild Osteoarthritis"],
    allergies: ["Penicillin", "Sulfa drugs"],
    primaryDoctor: "Dr. Vikram Patel (Demo Specialist)",
    language: "en",
    emergencyContactId: "em_demo_01",
    isDemoData: true
  },
  family: {
    id: "usr_demo_family",
    name: "Demo Family Member (Daughter)",
    email: "demo.family@mycare.ai",
    phone: "+91 98000 DEMO2",
    role: "family",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=256&q=80",
    city: "Indiranagar, Bengaluru [DEMO]",
    language: "en",
    elderlyId: "usr_demo_elderly",
    isDemoData: true
  },
  caregiver: {
    id: "usr_demo_caregiver",
    name: "Demo Healthcare Caregiver (Staff Nurse)",
    email: "demo.caregiver@mycare.ai",
    phone: "+91 98000 DEMO3",
    role: "caregiver",
    avatar: "https://images.unsplash.com/photo-1594824813583-0667e436d933?auto=format&fit=crop&w=256&q=80",
    city: "Hyderabad [DEMO]",
    language: "te",
    elderlyId: "usr_demo_elderly",
    isDemoData: true
  },
  admin: {
    id: "usr_demo_admin",
    name: "Demo Medical Admin (Dr. Patel)",
    email: "demo.admin@mycare.ai",
    phone: "+91 98000 DEMO4",
    role: "admin",
    avatar: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=256&q=80",
    city: "Apollo Health City [DEMO]",
    language: "en",
    isDemoData: true
  }
};

export const initialMedicines: Medicine[] = [
  {
    id: "med_telmi_01",
    name: "Telmisartan",
    brand: "Telmikind 40",
    strength: "40 mg",
    dosageForm: "Tablet",
    frequency: "Once daily morning",
    scheduleTimes: ["Morning"],
    exactTimes: ["08:00 AM"],
    dosage: "1 tablet",
    startDate: "2026-01-10",
    instructions: "Take with water immediately after breakfast. Do not crush.",
    prescribedBy: "Dr. Arvind Rao (Cardiologist)",
    image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=300&q=80",
    category: "Cardiac",
    remainingPills: 18,
    refillThreshold: 5,
    isPrescriptionRequired: true
  },
  {
    id: "med_metformin_02",
    name: "Metformin Hydrochloride SR",
    brand: "Glycomet 500 SR",
    strength: "500 mg",
    dosageForm: "Tablet",
    frequency: "Twice daily after meals",
    scheduleTimes: ["Morning", "Night"],
    exactTimes: ["08:30 AM", "08:30 PM"],
    dosage: "1 tablet",
    startDate: "2025-11-04",
    instructions: "Take with breakfast and dinner to avoid gastric irritation.",
    prescribedBy: "Dr. Sunita Reddy (Endocrinologist)",
    image: "https://images.unsplash.com/photo-1587854692152-cbe660dbde88?auto=format&fit=crop&w=300&q=80",
    category: "Diabetes",
    remainingPills: 24,
    refillThreshold: 6,
    isPrescriptionRequired: true
  },
  {
    id: "med_panto_03",
    name: "Pantoprazole Gastro-resistant",
    brand: "Pan 40",
    strength: "40 mg",
    dosageForm: "Tablet",
    frequency: "Once daily empty stomach",
    scheduleTimes: ["Morning"],
    exactTimes: ["07:30 AM"],
    dosage: "1 tablet",
    startDate: "2026-02-01",
    instructions: "Take at least 30 minutes before morning tea or breakfast.",
    prescribedBy: "Dr. Vikram Patel (Geriatrician)",
    image: "https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&w=300&q=80",
    category: "Digestive",
    remainingPills: 8,
    refillThreshold: 5,
    isPrescriptionRequired: true
  },
  {
    id: "med_ecosprin_04",
    name: "Aspirin Gastro-resistant",
    brand: "Ecosprin 75",
    strength: "75 mg",
    dosageForm: "Tablet",
    frequency: "Once daily with lunch",
    scheduleTimes: ["Afternoon"],
    exactTimes: ["01:30 PM"],
    dosage: "1 tablet",
    startDate: "2026-01-10",
    instructions: "Take during or right after afternoon meal.",
    prescribedBy: "Dr. Arvind Rao (Cardiologist)",
    image: "https://images.unsplash.com/photo-1550572017-ed3145455648?auto=format&fit=crop&w=300&q=80",
    category: "Cardiac",
    remainingPills: 14,
    refillThreshold: 4,
    isPrescriptionRequired: true
  },
  {
    id: "med_atorva_05",
    name: "Atorvastatin Calcium",
    brand: "Atorva 20",
    strength: "20 mg",
    dosageForm: "Tablet",
    frequency: "Once daily at bedtime",
    scheduleTimes: ["Night"],
    exactTimes: ["09:00 PM"],
    dosage: "1 tablet",
    startDate: "2026-01-10",
    instructions: "Take at night before sleeping.",
    prescribedBy: "Dr. Arvind Rao (Cardiologist)",
    image: "https://images.unsplash.com/photo-1576602976047-174e57a47881?auto=format&fit=crop&w=300&q=80",
    category: "Cardiac",
    remainingPills: 12,
    refillThreshold: 5,
    isPrescriptionRequired: true
  },
  {
    id: "med_vitd_06",
    name: "Cholecalciferol (Vitamin D3)",
    brand: "Calcirol 60K",
    strength: "60,000 IU",
    dosageForm: "Capsule",
    frequency: "Once weekly (Sundays)",
    scheduleTimes: ["Morning"],
    exactTimes: ["10:00 AM"],
    dosage: "1 softgel capsule",
    startDate: "2026-03-01",
    instructions: "Take with warm milk or after food for best absorption.",
    prescribedBy: "Dr. Vikram Patel (Geriatrician)",
    image: "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?auto=format&fit=crop&w=300&q=80",
    category: "Vitamins & Minerals",
    remainingPills: 3,
    refillThreshold: 1,
    isPrescriptionRequired: false
  }
];

export const initialTodayDoses: ScheduledDose[] = [
  {
    id: "dose_01",
    medicineId: "med_panto_03",
    medicineName: "Pantoprazole (Pan 40)",
    strength: "40 mg",
    dosage: "1 tablet",
    timeSlot: "Morning",
    scheduledTime: "07:30 AM",
    instructions: "Before breakfast on empty stomach with warm water",
    status: "taken",
    takenAt: "07:34 AM",
    confirmedBy: "Ramesh Sharma",
    colorTag: "#B9D0B5",
    shape: "tablet"
  },
  {
    id: "dose_02",
    medicineId: "med_telmi_01",
    medicineName: "Telmisartan (Telmikind 40)",
    strength: "40 mg",
    dosage: "1 tablet",
    timeSlot: "Morning",
    scheduledTime: "08:00 AM",
    instructions: "Take after breakfast for blood pressure control",
    status: "taken",
    takenAt: "08:12 AM",
    confirmedBy: "Ramesh Sharma",
    colorTag: "#DDE8D7",
    shape: "tablet"
  },
  {
    id: "dose_03",
    medicineId: "med_metformin_02",
    medicineName: "Metformin SR (Glycomet 500)",
    strength: "500 mg",
    dosage: "1 tablet",
    timeSlot: "Morning",
    scheduledTime: "08:30 AM",
    instructions: "Take with or right after breakfast",
    status: "taken",
    takenAt: "08:35 AM",
    confirmedBy: "Ramesh Sharma",
    colorTag: "#F3D5C2",
    shape: "tablet"
  },
  {
    id: "dose_04",
    medicineId: "med_ecosprin_04",
    medicineName: "Aspirin (Ecosprin 75)",
    strength: "75 mg",
    dosage: "1 tablet",
    timeSlot: "Afternoon",
    scheduledTime: "01:30 PM",
    instructions: "Take right after lunch with water",
    status: "pending",
    colorTag: "#E5C477",
    shape: "tablet"
  },
  {
    id: "dose_05",
    medicineId: "med_metformin_02",
    medicineName: "Metformin SR (Glycomet 500)",
    strength: "500 mg",
    dosage: "1 tablet",
    timeSlot: "Night",
    scheduledTime: "08:30 PM",
    instructions: "Take with dinner",
    status: "pending",
    colorTag: "#F3D5C2",
    shape: "tablet"
  },
  {
    id: "dose_06",
    medicineId: "med_atorva_05",
    medicineName: "Atorvastatin (Atorva 20)",
    strength: "20 mg",
    dosage: "1 tablet",
    timeSlot: "Night",
    scheduledTime: "09:00 PM",
    instructions: "Take at bedtime",
    status: "pending",
    colorTag: "#E5DDF0",
    shape: "tablet"
  }
];

import { masterMedicineCatalogue } from './medicineCatalogueExpanded';

export const medicineCatalogue: MedicineCatalogueItem[] = masterMedicineCatalogue;

export const sampleScanPresets = [
  {
    id: "preset_telmi",
    name: "Telmikind 40 (Telmisartan)",
    label: "Telmikind 40 Packaging Strip",
    imageUrl: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80",
    detectedName: "Telmikind 40",
    detectedStrength: "40 mg",
    detectedBrand: "Mankind Pharma",
    detectedManufacturer: "Mankind Pharma Ltd.",
    detectedDosageForm: "Tablet",
    confidence: 96,
    extractedText: "TELMIKIND 40 | Telmisartan Tablets IP 40mg | Mankind Pharma Ltd. | Batch TK902 | Mfg Jan 2026 Exp Dec 2028 | Schedule H Prescription Drug - Caution: To be sold by retail on prescription of a Registered Medical Practitioner only.",
    catalogueMatchId: "cat_01"
  },
  {
    id: "preset_glycomet",
    name: "Glycomet 500 SR (Metformin)",
    label: "Glycomet 500 SR Strip",
    imageUrl: "https://images.unsplash.com/photo-1587854692152-cbe660dbde88?auto=format&fit=crop&w=600&q=80",
    detectedName: "Glycomet 500 SR",
    detectedStrength: "500 mg",
    detectedBrand: "USV Private Limited",
    detectedManufacturer: "USV Ltd.",
    detectedDosageForm: "Tablet",
    confidence: 94,
    extractedText: "GLYCOMET 500 SR | Metformin Hydrochloride Sustained Release Tablets IP 500mg | USV Ltd. | Store protected from light & moisture | Keep out of reach of children.",
    catalogueMatchId: "cat_02"
  },
  {
    id: "preset_dolo",
    name: "Dolo 650 (Paracetamol)",
    label: "Dolo 650 Blister Pack",
    imageUrl: "https://images.unsplash.com/photo-1550572017-ed3145455648?auto=format&fit=crop&w=600&q=80",
    detectedName: "Dolo 650",
    detectedStrength: "650 mg",
    detectedBrand: "Micro Labs Ltd",
    detectedManufacturer: "Micro Labs Limited",
    detectedDosageForm: "Tablet",
    confidence: 98,
    extractedText: "DOLO 650 | Paracetamol Tablets IP 650mg | Micro Labs Limited | Fast relief from fever & pain | Keep in cool dry place.",
    catalogueMatchId: "cat_07"
  },
  {
    id: "preset_pan",
    name: "Pan 40 (Pantoprazole)",
    label: "Pan 40 Gastro-resistant Pack",
    imageUrl: "https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&w=600&q=80",
    detectedName: "Pan 40",
    detectedStrength: "40 mg",
    detectedBrand: "Alkem Laboratories",
    detectedManufacturer: "Alkem Laboratories Ltd.",
    detectedDosageForm: "Tablet",
    confidence: 92,
    extractedText: "PAN 40 | Pantoprazole Gastro-resistant Tablets IP | Alkem | 40mg per tablet | Swallow whole, do not chew.",
    catalogueMatchId: "cat_03"
  },
  {
    id: "preset_blurry",
    name: "Unclear Packaging Test",
    label: "Blurry / Faded Packaging Sample",
    imageUrl: "https://images.unsplash.com/photo-1576602976047-174e57a47881?auto=format&fit=crop&w=600&q=80",
    detectedName: "Uncertain Detection",
    detectedStrength: "Unknown",
    detectedBrand: "Unclear",
    detectedManufacturer: "Unverified",
    detectedDosageForm: "Tablet",
    confidence: 38,
    extractedText: "Tab ... 20mg ... [Partial text unreadable due to reflection or angle] ...",
    catalogueMatchId: null
  }
];

export const mockDoctors: Doctor[] = [
  {
    id: "doc_patel_01",
    name: "Dr. Vikram Patel",
    specialization: "Geriatric Medicine Specialist",
    qualifications: "MBBS, MD (Geriatrics), Fellowship in Ageing (UK)",
    experienceYears: 22,
    hospital: "Apollo Elder Care Clinic, Jubilee Hills, Hyderabad",
    rating: 4.9,
    reviewCount: 340,
    consultationFee: 1000,
    image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=400&q=80",
    about: "Senior consultant geriatrician specializing in comprehensive geriatric assessment, multi-morbidities management, polypharmacy review, and dementia care.",
    languages: ["English", "Telugu", "Hindi"],
    availableSlots: [
      { date: "2026-11-16", slots: ["10:00 AM", "11:30 AM", "04:00 PM"] },
      { date: "2026-11-17", slots: ["09:30 AM", "12:00 PM", "05:00 PM"] },
      { date: "2026-11-18", slots: ["10:30 AM", "03:30 PM", "04:30 PM"] },
      { date: "2026-11-20", slots: ["11:00 AM", "02:30 PM"] }
    ]
  },
  {
    id: "doc_rao_02",
    name: "Dr. Arvind Rao",
    specialization: "Senior Cardiologist",
    qualifications: "MBBS, MD (General Med), DM (Cardiology), FACC",
    experienceYears: 26,
    hospital: "Care Hospitals, Banjara Hills, Hyderabad",
    rating: 4.9,
    reviewCount: 520,
    consultationFee: 1200,
    image: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&w=400&q=80",
    about: "Distinguished cardiologist with extensive expertise in elderly cardiovascular wellness, hypertension control, post-angioplasty care, and heart failure prevention.",
    languages: ["English", "Telugu", "Hindi"],
    availableSlots: [
      { date: "2026-11-16", slots: ["11:00 AM", "03:00 PM"] },
      { date: "2026-11-17", slots: ["10:00 AM", "02:00 PM", "04:30 PM"] },
      { date: "2026-11-19", slots: ["09:30 AM", "11:30 AM"] }
    ]
  },
  {
    id: "doc_reddy_03",
    name: "Dr. Sunita Reddy",
    specialization: "Endocrinologist & Diabetologist",
    qualifications: "MBBS, MD, DNB (Endocrinology)",
    experienceYears: 18,
    hospital: "AIG Hospitals, Gachibowli, Hyderabad",
    rating: 4.8,
    reviewCount: 290,
    consultationFee: 900,
    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=400&q=80",
    about: "Specialist in senior diabetes management, diabetic neuropathy prevention, thyroid disorders, and dietary balance for older adults.",
    languages: ["English", "Telugu", "Hindi"],
    availableSlots: [
      { date: "2026-11-16", slots: ["02:00 PM", "03:30 PM", "05:00 PM"] },
      { date: "2026-11-18", slots: ["10:00 AM", "11:00 AM"] }
    ]
  },
  {
    id: "doc_verma_04",
    name: "Dr. Rajesh Verma",
    specialization: "Neurologist",
    qualifications: "MBBS, MD, DM (Neurology)",
    experienceYears: 20,
    hospital: "Yashoda Hospitals, Somajiguda, Hyderabad",
    rating: 4.7,
    reviewCount: 210,
    consultationFee: 1100,
    image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&w=400&q=80",
    about: "Focuses on age-related cognitive health, memory care, Parkinson's disease, and tremor management.",
    languages: ["English", "Hindi"],
    availableSlots: [
      { date: "2026-11-17", slots: ["11:00 AM", "04:00 PM"] },
      { date: "2026-11-19", slots: ["02:30 PM", "03:30 PM"] }
    ]
  },
  {
    id: "doc_nair_05",
    name: "Dr. Meenakshi Nair",
    specialization: "Orthopedic & Joint Care",
    qualifications: "MBBS, MS (Ortho), Fellowship in Joint Replacement",
    experienceYears: 16,
    hospital: "Sunshine Bone & Joint Institute, Secunderabad",
    rating: 4.8,
    reviewCount: 310,
    consultationFee: 950,
    image: "https://images.unsplash.com/photo-1594824813583-0667e436d933?auto=format&fit=crop&w=400&q=80",
    about: "Expert in elderly knee osteoarthritis, osteoporosis prevention, fall risk assessment, and gentle joint rehabilitation.",
    languages: ["English", "Telugu", "Hindi", "Malayalam"],
    availableSlots: [
      { date: "2026-11-16", slots: ["09:00 AM", "12:00 PM"] },
      { date: "2026-11-18", slots: ["03:00 PM", "05:30 PM"] }
    ]
  },
  {
    id: "doc_sharma_06",
    name: "Dr. Alok Sharma",
    specialization: "Ophthalmologist (Eye Care)",
    qualifications: "MBBS, MS (Ophth), Vitreo-Retina Specialist",
    experienceYears: 19,
    hospital: "L.V. Prasad Eye Institute, Banjara Hills",
    rating: 4.9,
    reviewCount: 460,
    consultationFee: 850,
    image: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?auto=format&fit=crop&w=400&q=80",
    about: "Specialized in senile cataract evaluation, diabetic retinopathy screening, and age-related macular degeneration (AMD).",
    languages: ["English", "Hindi", "Telugu"],
    availableSlots: [
      { date: "2026-11-17", slots: ["10:30 AM", "01:30 PM"] },
      { date: "2026-11-20", slots: ["09:30 AM", "11:00 AM"] }
    ]
  }
];

export const initialAppointments: Appointment[] = [
  {
    id: "apt_01",
    doctorId: "doc_patel_01",
    doctorName: "Dr. Vikram Patel",
    specialization: "Geriatric Medicine Specialist",
    doctorImage: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=400&q=80",
    hospital: "Apollo Elder Care Clinic, Jubilee Hills",
    date: "2026-11-18",
    time: "10:30 AM",
    type: "In-person Clinic",
    status: "Confirmed",
    consultationFee: 1000,
    reason: "Routine quarterly geriatric checkup & medication review",
    notes: "Please bring recent blood pressure log and fasting blood sugar test reports."
  },
  {
    id: "apt_02",
    doctorId: "doc_rao_02",
    doctorName: "Dr. Arvind Rao",
    specialization: "Senior Cardiologist",
    doctorImage: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&w=400&q=80",
    hospital: "Care Hospitals, Banjara Hills",
    date: "2026-11-25",
    time: "11:00 AM",
    type: "Video Consultation",
    status: "Confirmed",
    consultationFee: 1200,
    reason: "Hypertension medication evaluation & ECG follow-up",
    notes: "Teleconsultation video link will activate 10 minutes prior to appointment."
  },
  {
    id: "apt_past_03",
    doctorId: "doc_reddy_03",
    doctorName: "Dr. Sunita Reddy",
    specialization: "Endocrinologist & Diabetologist",
    doctorImage: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=400&q=80",
    hospital: "AIG Hospitals, Gachibowli",
    date: "2026-10-20",
    time: "03:30 PM",
    type: "In-person Clinic",
    status: "Completed",
    consultationFee: 900,
    reason: "HbA1c review (Result: 6.8% - Well controlled)",
    notes: "Continue Glycomet 500 SR twice daily. Recheck HbA1c in 3 months."
  }
];

export const initialFamilyMembers: FamilyMember[] = [
  {
    id: "fam_demo_01",
    name: "Demo Family Member (Daughter)",
    relation: "Daughter (Primary Guardian) [DEMO]",
    role: "Family Member",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=256&q=80",
    phone: "+91 98000 DEMO2",
    email: "demo.family@mycare.ai",
    permissions: {
      canViewVitals: true,
      canManageMedicines: true,
      canBookAppointments: true,
      canReceiveSOS: true
    },
    lastActive: "15 mins ago",
    status: "Active",
    isDemoData: true
  },
  {
    id: "fam_demo_02",
    name: "Demo Family Member (Son)",
    relation: "Son (Overseas Contact) [DEMO]",
    role: "Family Member",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=256&q=80",
    phone: "+65 8000 DEMO5",
    email: "demo.son@mycare.ai",
    permissions: {
      canViewVitals: true,
      canManageMedicines: false,
      canBookAppointments: false,
      canReceiveSOS: true
    },
    lastActive: "2 hours ago",
    status: "Active",
    isDemoData: true
  },
  {
    id: "fam_demo_03",
    name: "Demo Healthcare Caregiver (Staff Nurse)",
    relation: "Assigned Healthcare Nurse [DEMO]",
    role: "Primary Caregiver",
    avatar: "https://images.unsplash.com/photo-1594824813583-0667e436d933?auto=format&fit=crop&w=256&q=80",
    phone: "+91 98000 DEMO3",
    email: "demo.caregiver@mycare.ai",
    permissions: {
      canViewVitals: true,
      canManageMedicines: true,
      canBookAppointments: true,
      canReceiveSOS: true
    },
    lastActive: "Just now",
    status: "Active",
    isDemoData: true
  }
];

export const initialCareTasks: CareTask[] = [
  {
    id: "task_01",
    title: "Check Morning Blood Pressure",
    description: "Take resting BP using digital monitor before morning walk.",
    category: "Vitals Check",
    assignedTo: "Demo Healthcare Caregiver",
    assignedToRole: "Caregiver",
    dueDate: "Today",
    timeSlot: "08:00 AM",
    completed: true,
    completedAt: "08:05 AM",
    completedBy: "Demo Healthcare Caregiver",
    notes: "Reading was 126/82 mmHg, Pulse 72 bpm. Good reading."
  },
  {
    id: "task_02",
    title: "20-Minute Evening Garden Walk",
    description: "Support senior member with comfortable walking shoes around building compound.",
    category: "Mobility/Exercise",
    assignedTo: "Demo Healthcare Caregiver",
    assignedToRole: "Caregiver",
    dueDate: "Today",
    timeSlot: "05:30 PM",
    completed: false,
    notes: "Keep hydration bottle handy."
  },
  {
    id: "task_03",
    title: "Refill Telmikind 40 & Glycomet 500",
    description: "Remaining strips have 4-5 days supply. Order through MyCare AI pharmacy.",
    category: "Medication",
    assignedTo: "Demo Family Member (Daughter)",
    assignedToRole: "Family",
    dueDate: "Tomorrow",
    completed: false,
    urgent: true
  },
  {
    id: "task_04",
    title: "Prepare Reports for Dr. Patel's Visit",
    description: "Gather last week's fasting sugar sheets and digital BP printouts.",
    category: "Doctor/Appointment",
    assignedTo: "Demo Family Member (Daughter)",
    assignedToRole: "Family",
    dueDate: "2026-11-17",
    completed: false
  }
];

export const initialEmergencyContacts: EmergencyContact[] = [
  {
    id: "em_demo_01",
    name: "Demo Family Member (Daughter)",
    relation: "Daughter [DEMO CONTACT]",
    phone: "+91 98000 DEMO2",
    isPrimary: true,
    notifyOnSOS: true,
    isDemoData: true
  },
  {
    id: "em_demo_02",
    name: "Demo Healthcare Caregiver (Staff Nurse)",
    relation: "Caregiver [DEMO CONTACT]",
    phone: "+91 98000 DEMO3",
    isPrimary: false,
    notifyOnSOS: true,
    isDemoData: true
  },
  {
    id: "em_demo_03",
    name: "Apollo Jubilee Hills Emergency [DEMO]",
    relation: "Hospital Ambulance Hotline",
    phone: "1066",
    isPrimary: false,
    notifyOnSOS: true,
    isDemoData: true
  },
  {
    id: "em_demo_04",
    name: "Demo Family Member (Son)",
    relation: "Son (Overseas) [DEMO CONTACT]",
    phone: "+65 8000 DEMO5",
    isPrimary: false,
    notifyOnSOS: true,
    isDemoData: true
  }
];

export const initialNotifications: NotificationItem[] = [
  {
    id: "notif_01",
    title: "Medicine Taken Confirmed",
    message: "Morning doses (Pan 40, Telmikind 40, Glycomet 500) logged on time at 08:35 AM.",
    type: "medicine",
    timestamp: "3 hours ago",
    read: true
  },
  {
    id: "notif_02",
    title: "Afternoon Dose Reminder",
    message: "Ecosprin 75 mg is scheduled at 01:30 PM with afternoon lunch.",
    type: "medicine",
    timestamp: "25 mins ago",
    read: false
  },
  {
    id: "notif_03",
    title: "Upcoming Doctor Appointment",
    message: "Dr. Vikram Patel (Geriatrics) visit scheduled for Wednesday, Nov 18 at 10:30 AM.",
    type: "appointment",
    timestamp: "1 day ago",
    read: true
  },
  {
    id: "notif_04",
    title: "Caregiver Vital Update",
    message: "Sister Anjali recorded morning blood pressure: 126/82 mmHg (Normal).",
    type: "caregiver",
    timestamp: "4 hours ago",
    read: true
  },
  {
    id: "notif_05",
    title: "Low Stock Alert: Calcirol 60K",
    message: "Only 3 capsules remaining. Refill recommended within 5 days.",
    type: "order",
    timestamp: "2 days ago",
    read: false
  }
];

export const initialVitals: HealthVital[] = [
  {
    id: "vit_01",
    date: "Today (08:05 AM)",
    bloodPressureSystolic: 126,
    bloodPressureDiastolic: 82,
    heartRate: 72,
    bloodGlucose: 118,
    spo2: 98,
    recordedBy: "Sister Anjali Rao"
  },
  {
    id: "vit_02",
    date: "Yesterday",
    bloodPressureSystolic: 128,
    bloodPressureDiastolic: 84,
    heartRate: 74,
    bloodGlucose: 122,
    spo2: 97,
    recordedBy: "Sister Anjali Rao"
  },
  {
    id: "vit_03",
    date: "13 Nov 2026",
    bloodPressureSystolic: 130,
    bloodPressureDiastolic: 85,
    heartRate: 76,
    bloodGlucose: 115,
    spo2: 98,
    recordedBy: "Ramesh Sharma"
  },
  {
    id: "vit_04",
    date: "12 Nov 2026",
    bloodPressureSystolic: 124,
    bloodPressureDiastolic: 80,
    heartRate: 71,
    bloodGlucose: 110,
    spo2: 99,
    recordedBy: "Sister Anjali Rao"
  },
  {
    id: "vit_05",
    date: "11 Nov 2026",
    bloodPressureSystolic: 132,
    bloodPressureDiastolic: 86,
    heartRate: 75,
    bloodGlucose: 125,
    spo2: 98,
    recordedBy: "Sister Anjali Rao"
  },
  {
    id: "vit_06",
    date: "10 Nov 2026",
    bloodPressureSystolic: 125,
    bloodPressureDiastolic: 81,
    heartRate: 70,
    bloodGlucose: 112,
    spo2: 98,
    recordedBy: "Sister Anjali Rao"
  },
  {
    id: "vit_07",
    date: "09 Nov 2026",
    bloodPressureSystolic: 127,
    bloodPressureDiastolic: 83,
    heartRate: 73,
    bloodGlucose: 116,
    spo2: 97,
    recordedBy: "Sister Anjali Rao"
  }
];

export const weeklyAdherenceData = [
  { day: "Mon", taken: 5, missed: 0, adherence: 100 },
  { day: "Tue", taken: 5, missed: 0, adherence: 100 },
  { day: "Wed", taken: 4, missed: 1, adherence: 80 },
  { day: "Thu", taken: 5, missed: 0, adherence: 100 },
  { day: "Fri", taken: 5, missed: 0, adherence: 100 },
  { day: "Sat", taken: 5, missed: 0, adherence: 100 },
  { day: "Sun (Today)", taken: 3, missed: 0, pending: 3, adherence: 100 }
];

export const initialOrders: Order[] = [
  {
    id: "ord_1082",
    orderNumber: "MCA-98421",
    date: "2026-11-10",
    items: [
      { medicine: medicineCatalogue[0], quantity: 2 },
      { medicine: medicineCatalogue[1], quantity: 1 }
    ],
    subtotal: 159.00,
    discount: 15.00,
    deliveryFee: 0,
    total: 144.00,
    status: "Delivered",
    deliveryAddress: "Flat 402, Sai Nilayam, Road No. 12, Banjara Hills, Hyderabad - 500034",
    estimatedDelivery: "Delivered on 11 Nov 2026, 04:30 PM",
    prescriptionStatus: "Verified",
    paymentMethod: "Cash on Delivery (Senior Pay)"
  }
];

export const recentActivityLogs = [
  {
    id: "act_01",
    title: "Morning Medication Taken",
    time: "08:35 AM Today",
    description: "Pan 40, Telmikind 40, and Glycomet 500 confirmed by Ramesh Sharma.",
    icon: "Pill",
    type: "success"
  },
  {
    id: "act_02",
    title: "Vital Signs Recorded",
    time: "08:05 AM Today",
    description: "Blood pressure 126/82 mmHg logged by Sister Anjali Rao.",
    icon: "HeartPulse",
    type: "info"
  },
  {
    id: "act_03",
    title: "Doctor Appointment Confirmed",
    time: "Yesterday, 04:20 PM",
    description: "Appointment with Dr. Vikram Patel for Nov 18 confirmed.",
    icon: "Calendar",
    type: "info"
  },
  {
    id: "act_04",
    title: "Care Task Completed",
    time: "Yesterday, 06:00 PM",
    description: "Sister Anjali completed the 20-min evening walking assistance.",
    icon: "CheckCircle2",
    type: "success"
  }
];
