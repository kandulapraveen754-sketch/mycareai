// ==========================================
// MYCARE AI - DASHBOARD MAIN PAGE
// Complete warm, premium healthcare dashboard
// ==========================================

import React from 'react';
import { WelcomeBanner } from '../components/dashboard/WelcomeBanner';
import { SummaryCards } from '../components/dashboard/SummaryCards';
import { TodayMedicinesCard } from '../components/dashboard/TodayMedicinesCard';
import { UpcomingAppointmentsSection } from '../components/dashboard/UpcomingAppointmentsSection';
import { AIGuardianWidget } from '../components/dashboard/AIGuardianWidget';
import { MedicineOrderingQuickSection } from '../components/dashboard/MedicineOrderingQuickSection';
import { HealthInsightsSection } from '../components/dashboard/HealthInsightsSection';
import { FamilyCircleSection } from '../components/dashboard/FamilyCircleSection';
import { EmergencySOSWidget } from '../components/dashboard/EmergencySOSWidget';
import { RecentActivitySection } from '../components/dashboard/RecentActivitySection';

export const DashboardPage: React.FC = () => {
  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300">
      {/* 1. Welcome Banner */}
      <WelcomeBanner />

      {/* 2. Four Colorful Summary Cards */}
      <SummaryCards />

      {/* 3. Doses & AI Guardian Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7">
          <TodayMedicinesCard />
        </div>
        <div className="lg:col-span-5">
          <AIGuardianWidget />
        </div>
      </div>

      {/* 4. Upcoming Doctor Appointments */}
      <UpcomingAppointmentsSection />

      {/* 5. Medicine Ordering & Packaging Scan */}
      <MedicineOrderingQuickSection />

      {/* 6. Health Insights & Adherence Trends */}
      <HealthInsightsSection />

      {/* 7. Family Circle & Emergency Shield Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7">
          <FamilyCircleSection />
        </div>
        <div className="lg:col-span-5">
          <EmergencySOSWidget />
        </div>
      </div>

      {/* 8. Recent Activity Audit Trail */}
      <RecentActivitySection />
    </div>
  );
};
