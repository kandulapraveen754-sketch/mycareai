// ==========================================
// MYCARE AI - MY HEALTH & VITALS RECORD PAGE
// Patient health records, vitals logging, condition summaries
// ==========================================

import React, { useState } from 'react';
import {
  HeartPulse,
  Activity,
  Droplet,
  Plus,
  Calendar,
  User,
  ShieldCheck,
  FileText,
  AlertTriangle,
  Clock,
  X
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { HealthVital } from '../types';
import { triggerConfetti } from '../utils/confetti';

export const HealthPage: React.FC = () => {
  const { currentUser, vitals, addVitalRecord, t } = useApp();

  const [showLogModal, setShowLogModal] = useState(false);
  const [systolic, setSystolic] = useState(124);
  const [diastolic, setDiastolic] = useState(82);
  const [pulse, setPulse] = useState(72);
  const [glucose, setGlucose] = useState(115);
  const [spo2, setSpo2] = useState(98);

  const handleVitalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addVitalRecord({
      bloodPressureSystolic: Number(systolic),
      bloodPressureDiastolic: Number(diastolic),
      heartRate: Number(pulse),
      bloodGlucose: Number(glucose),
      spo2: Number(spo2)
    });
    setShowLogModal(false);
    triggerConfetti(2000);
  };

  const latestVital = vitals[0] || {
    bloodPressureSystolic: 126,
    bloodPressureDiastolic: 82,
    heartRate: 72,
    bloodGlucose: 118,
    spo2: 98,
    date: "Today"
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-display font-extrabold text-charcoal-900">
              {t.myHealth} & Medical Records
            </h1>
            <span className="text-xs bg-sage-100 text-teal-850 font-bold px-2.5 py-0.5 rounded-full">
              Patient: Ramesh Sharma (74 yrs)
            </span>
          </div>
          <p className="text-xs text-charcoal-500 mt-1">
            Clinical history, vital parameters, chronic conditions, and allergy registry
          </p>
        </div>

        <button
          onClick={() => setShowLogModal(true)}
          className="px-4 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Log New Vitals</span>
        </button>
      </div>

      {/* Clinical Profile Summary Card */}
      <div className="rounded-3xl bg-cream-50 border border-cream-300 p-6 shadow-sm space-y-4">
        <h2 className="text-sm font-bold text-charcoal-700 uppercase tracking-wider">
          Patient Clinical Profile:
        </h2>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div className="p-3 bg-white rounded-2xl border border-cream-200">
            <span className="text-charcoal-400 block">Full Name:</span>
            <p className="font-bold text-sm text-charcoal-900 mt-0.5">{currentUser.name}</p>
            <p className="text-charcoal-500 mt-0.5">Age: {currentUser.age || 74} yrs • {currentUser.gender || 'Male'}</p>
          </div>

          <div className="p-3 bg-white rounded-2xl border border-cream-200">
            <span className="text-charcoal-400 block">Blood Group:</span>
            <p className="font-bold text-sm text-peach-600 mt-0.5">{currentUser.bloodGroup || 'O+'}</p>
            <p className="text-charcoal-500 mt-0.5">RH Positive</p>
          </div>

          <div className="p-3 bg-white rounded-2xl border border-cream-200">
            <span className="text-charcoal-400 block">Location:</span>
            <p className="font-bold text-sm text-charcoal-900 mt-0.5">{currentUser.city || 'Hyderabad'}</p>
            <p className="text-charcoal-500 mt-0.5">Banjara Hills</p>
          </div>

          <div className="p-3 bg-white rounded-2xl border border-cream-200">
            <span className="text-charcoal-400 block">Primary Physician:</span>
            <p className="font-bold text-sm text-teal-850 mt-0.5">{currentUser.primaryDoctor || 'Dr. Vikram Patel'}</p>
            <p className="text-charcoal-500 mt-0.5">Geriatrician (Apollo)</p>
          </div>
        </div>

        {/* Conditions and Allergies */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div className="p-4 bg-white rounded-2xl border border-cream-200 space-y-2">
            <span className="text-xs font-bold text-charcoal-700 uppercase block">
              Active Medical Conditions:
            </span>
            <div className="flex flex-wrap gap-2">
              {(currentUser.conditions || []).map((c, i) => (
                <span key={i} className="px-3 py-1 rounded-xl bg-cream-100 text-charcoal-800 text-xs font-semibold">
                  {c}
                </span>
              ))}
            </div>
          </div>

          <div className="p-4 bg-white rounded-2xl border border-cream-200 space-y-2">
            <span className="text-xs font-bold text-red-700 uppercase block">
              Drug & Food Allergies:
            </span>
            <div className="flex flex-wrap gap-2">
              {(currentUser.allergies || []).map((a, i) => (
                <span key={i} className="px-3 py-1 rounded-xl bg-red-50 text-red-700 text-xs font-bold border border-red-200">
                  ⚠ {a}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Latest Vitals Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-3xl bg-sage-100 border border-sage-200">
          <div className="flex justify-between items-center text-xs font-bold text-teal-900">
            <span>Blood Pressure</span>
            <HeartPulse className="w-4 h-4 text-teal-700" />
          </div>
          <p className="text-2xl font-display font-black text-teal-900 mt-1">
            {latestVital.bloodPressureSystolic}/{latestVital.bloodPressureDiastolic}
            <span className="text-xs font-medium ml-1">mmHg</span>
          </p>
          <p className="text-xs text-teal-800 mt-1">Status: Stable</p>
        </div>

        <div className="p-5 rounded-3xl bg-peach-100 border border-peach-200">
          <div className="flex justify-between items-center text-xs font-bold text-peach-700">
            <span>Pulse / Heart Rate</span>
            <Activity className="w-4 h-4 text-peach-500" />
          </div>
          <p className="text-2xl font-display font-black text-charcoal-900 mt-1">
            {latestVital.heartRate}
            <span className="text-xs font-medium ml-1">bpm</span>
          </p>
          <p className="text-xs text-charcoal-700 mt-1">Rhythm: Regular</p>
        </div>

        <div className="p-5 rounded-3xl bg-mustard-100 border border-mustard-200">
          <div className="flex justify-between items-center text-xs font-bold text-mustard-600">
            <span>Fasting Blood Sugar</span>
            <Droplet className="w-4 h-4 text-mustard-500" />
          </div>
          <p className="text-2xl font-display font-black text-charcoal-900 mt-1">
            {latestVital.bloodGlucose}
            <span className="text-xs font-medium ml-1">mg/dL</span>
          </p>
          <p className="text-xs text-charcoal-700 mt-1">HbA1c Target: &lt; 7.0%</p>
        </div>

        <div className="p-5 rounded-3xl bg-lavender-100 border border-lavender-200">
          <div className="flex justify-between items-center text-xs font-bold text-lavender-700">
            <span>Oxygen Saturation</span>
            <ShieldCheck className="w-4 h-4 text-lavender-700" />
          </div>
          <p className="text-2xl font-display font-black text-charcoal-900 mt-1">
            {latestVital.spo2}%
          </p>
          <p className="text-xs text-charcoal-700 mt-1">Pulse Oximeter Verified</p>
        </div>
      </div>

      {/* Log New Vitals Modal */}
      {showLogModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-cream-300 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-cream-200">
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Log New Health Vital Readings
              </h3>
              <button
                onClick={() => setShowLogModal(false)}
                className="p-1 rounded-full text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleVitalSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">
                    Systolic BP (mmHg)
                  </label>
                  <input
                    type="number"
                    required
                    value={systolic}
                    onChange={(e) => setSystolic(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">
                    Diastolic BP (mmHg)
                  </label>
                  <input
                    type="number"
                    required
                    value={diastolic}
                    onChange={(e) => setDiastolic(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">
                    Pulse (bpm)
                  </label>
                  <input
                    type="number"
                    required
                    value={pulse}
                    onChange={(e) => setPulse(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">
                    Glucose (mg/dL)
                  </label>
                  <input
                    type="number"
                    required
                    value={glucose}
                    onChange={(e) => setGlucose(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">
                    SpO2 (%)
                  </label>
                  <input
                    type="number"
                    required
                    value={spo2}
                    onChange={(e) => setSpo2(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  />
                </div>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs shadow-md transition-colors"
                >
                  Save Readings
                </button>
                <button
                  type="button"
                  onClick={() => setShowLogModal(false)}
                  className="px-4 py-3 rounded-xl bg-cream-200 text-charcoal-700 font-semibold text-xs"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
