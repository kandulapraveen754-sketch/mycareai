// ==========================================
// MYCARE AI - SETTINGS, ACCESSIBILITY & PROFILE PAGE
// Manage personal profile details, medical conditions,
// senior display modes, voice readout, language & roles
// ==========================================

import React, { useState, useEffect } from 'react';
import {
  Settings,
  Eye,
  Volume2,
  Globe,
  ShieldCheck,
  User,
  CheckCircle2,
  Lock,
  Smartphone,
  Save,
  Activity,
  Heart,
  Stethoscope,
  MapPin,
  Phone,
  Mail,
  LogOut,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { LanguageCode, UserRole } from '../types';
import { triggerConfetti } from '../utils/confetti';

export const SettingsPage: React.FC = () => {
  const {
    currentUser,
    currentRole,
    switchRole,
    updateUserProfile,
    language,
    setLanguage,
    isElderlyMode,
    setIsElderlyMode,
    fontSize,
    setFontSize,
    autoVoiceEnabled,
    setAutoVoiceEnabled,
    isDemoMode,
    logout,
    t
  } = useApp();

  const [savedSuccess, setSavedSuccess] = useState(false);

  // Profile Form State
  const [profileName, setProfileName] = useState(currentUser?.name || '');
  const [profilePhone, setProfilePhone] = useState(currentUser?.phone || '');
  const [profileAge, setProfileAge] = useState(currentUser?.age || 70);
  const [profileGender, setProfileGender] = useState(currentUser?.gender || 'Male');
  const [profileCity, setProfileCity] = useState(currentUser?.city || '');
  const [profileBloodGroup, setProfileBloodGroup] = useState(currentUser?.bloodGroup || 'O+');
  const [profileDoctor, setProfileDoctor] = useState(currentUser?.primaryDoctor || '');
  const [profileConditions, setProfileConditions] = useState(
    (currentUser?.conditions || []).join(', ')
  );
  const [profileAllergies, setProfileAllergies] = useState(
    (currentUser?.allergies || []).join(', ')
  );

  useEffect(() => {
    if (currentUser) {
      setProfileName(currentUser.name);
      setProfilePhone(currentUser.phone);
      setProfileAge(currentUser.age || 70);
      setProfileGender(currentUser.gender || 'Male');
      setProfileCity(currentUser.city || '');
      setProfileBloodGroup(currentUser.bloodGroup || 'O+');
      setProfileDoctor(currentUser.primaryDoctor || '');
      setProfileConditions((currentUser.conditions || []).join(', '));
      setProfileAllergies((currentUser.allergies || []).join(', '));
    }
  }, [currentUser]);

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const conditionsArr = profileConditions
      .split(',')
      .map((c) => c.trim())
      .filter(Boolean);
    const allergiesArr = profileAllergies
      .split(',')
      .map((a) => a.trim())
      .filter(Boolean);

    await updateUserProfile({
      name: profileName.trim(),
      phone: profilePhone.trim(),
      age: Number(profileAge) || 70,
      gender: profileGender,
      city: profileCity.trim(),
      bloodGroup: profileBloodGroup,
      primaryDoctor: profileDoctor.trim(),
      conditions: conditionsArr,
      allergies: allergiesArr
    });

    setSavedSuccess(true);
    triggerConfetti(1500);
    setTimeout(() => setSavedSuccess(false), 3500);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-display font-extrabold text-charcoal-900">
              {t.settings} & Profile Management
            </h1>
            <span className="text-xs bg-teal-100 text-teal-850 font-bold px-2.5 py-0.5 rounded-full">
              Personalized Care
            </span>
          </div>
          <p className="text-xs text-charcoal-500 mt-1">
            Manage your personal profile, medical conditions, elderly accessibility, and language preferences
          </p>
        </div>

        <button
          onClick={handleProfileSave}
          className="px-5 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-all"
        >
          <Save className="w-4 h-4" />
          <span>Save Changes</span>
        </button>
      </div>

      {savedSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Your profile information and settings have been successfully updated in your account.</span>
        </div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* 1. Personal Profile & Health Details Card */}
        <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-cream-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-peach-100 text-peach-600 flex items-center justify-center">
                <User className="w-5 h-5 text-peach-600" />
              </div>
              <div>
                <h2 className="font-display font-bold text-base text-charcoal-900">
                  Profile & Health Information
                </h2>
                <p className="text-xs text-charcoal-500">Stored in your authenticated personal database account</p>
              </div>
            </div>

            {isDemoMode && (
              <span className="text-[10px] bg-sage-200 text-sage-800 font-extrabold px-2 py-0.5 rounded-full uppercase">
                DEMO PROFILE
              </span>
            )}
          </div>

          <form onSubmit={handleProfileSave} className="space-y-3.5 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-charcoal-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs focus:ring-2 focus:ring-teal-700/30"
                />
              </div>

              <div>
                <label className="block font-bold text-charcoal-700 mb-1">Email Address</label>
                <input
                  type="email"
                  disabled
                  value={currentUser.email}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-cream-200/50 border border-cream-300 text-charcoal-600 text-xs cursor-not-allowed"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block font-bold text-charcoal-700 mb-1">Phone</label>
                <input
                  type="tel"
                  value={profilePhone}
                  onChange={(e) => setProfilePhone(e.target.value)}
                  placeholder="+91..."
                  className="w-full px-3 py-2 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs"
                />
              </div>
              <div>
                <label className="block font-bold text-charcoal-700 mb-1">Age</label>
                <input
                  type="number"
                  value={profileAge}
                  onChange={(e) => setProfileAge(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs"
                />
              </div>
              <div>
                <label className="block font-bold text-charcoal-700 mb-1">Blood Group</label>
                <select
                  value={profileBloodGroup}
                  onChange={(e) => setProfileBloodGroup(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs"
                >
                  {['O+', 'O-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-'].map((bg) => (
                    <option key={bg} value={bg}>
                      {bg}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block font-bold text-charcoal-700 mb-1">City / Residential Area</label>
              <input
                type="text"
                value={profileCity}
                onChange={(e) => setProfileCity(e.target.value)}
                placeholder="e.g. Jubilee Hills, Hyderabad"
                className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs"
              />
            </div>

            <div>
              <label className="block font-bold text-charcoal-700 mb-1">Primary Treating Doctor / Clinic</label>
              <input
                type="text"
                value={profileDoctor}
                onChange={(e) => setProfileDoctor(e.target.value)}
                placeholder="e.g. Dr. Arvind Rao, MD (Cardiologist)"
                className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs"
              />
            </div>

            <div>
              <label className="block font-bold text-charcoal-700 mb-1">
                Medical Conditions (comma-separated)
              </label>
              <input
                type="text"
                value={profileConditions}
                onChange={(e) => setProfileConditions(e.target.value)}
                placeholder="e.g. Hypertension, Type 2 Diabetes, Arthritis"
                className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs"
              />
            </div>

            <div>
              <label className="block font-bold text-charcoal-700 mb-1">
                Drug Allergies & Sensitivities
              </label>
              <input
                type="text"
                value={profileAllergies}
                onChange={(e) => setProfileAllergies(e.target.value)}
                placeholder="e.g. Penicillin, Sulfa drugs"
                className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
            >
              <Save className="w-4 h-4" />
              <span>Update Profile & Clinical Records</span>
            </button>
          </form>
        </div>

        {/* 2. Senior Accessibility & Display Modes */}
        <div className="space-y-6">
          <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-5">
            <div className="flex items-center gap-3 pb-3 border-b border-cream-200">
              <div className="w-10 h-10 rounded-2xl bg-sage-100 text-teal-850 flex items-center justify-center">
                <Eye className="w-5 h-5 text-teal-700" />
              </div>
              <div>
                <h2 className="font-display font-bold text-base text-charcoal-900">
                  Elderly-Friendly Accessibility
                </h2>
                <p className="text-xs text-charcoal-500">Optimized for vision, touch, and audio clarity</p>
              </div>
            </div>

            {/* Toggle Elderly Mode */}
            <div className="p-4 rounded-2xl bg-cream-50 border border-cream-200 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-charcoal-900">Elderly-Friendly Display Mode</p>
                <p className="text-[11px] text-charcoal-500">
                  Enlarges primary touch targets, high contrast borders, and simplified navigation
                </p>
              </div>
              <button
                onClick={() => setIsElderlyMode(!isElderlyMode)}
                className={`w-14 h-8 rounded-full transition-colors p-1 ${
                  isElderlyMode ? 'bg-teal-700' : 'bg-charcoal-300'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full bg-white shadow-md transform transition-transform ${
                    isElderlyMode ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Font Size Selector */}
            <div>
              <label className="text-xs font-bold text-charcoal-700 block mb-2">
                Font Scale / Text Size:
              </label>
              <div className="grid grid-cols-3 gap-2 text-xs">
                {(['normal', 'large', 'xlarge'] as const).map((size) => (
                  <button
                    key={size}
                    onClick={() => setFontSize(size)}
                    className={`p-3 rounded-2xl border font-bold capitalize transition-colors ${
                      fontSize === size
                        ? 'border-teal-700 bg-teal-50 text-teal-850 ring-2 ring-teal-700/30'
                        : 'border-cream-300 bg-white text-charcoal-700 hover:bg-cream-50'
                    }`}
                  >
                    {size === 'normal' ? 'Normal' : size === 'large' ? 'Large (Default)' : 'Extra Large'}
                  </button>
                ))}
              </div>
            </div>

            {/* Voice Response Auto-Speak */}
            <div className="p-4 rounded-2xl bg-cream-50 border border-cream-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Volume2 className="w-5 h-5 text-teal-700" />
                <div>
                  <p className="text-xs font-bold text-charcoal-900">AI Guardian Voice Readout</p>
                  <p className="text-[11px] text-charcoal-500">
                    Automatically read aloud AI Guardian replies in clear speech
                  </p>
                </div>
              </div>
              <button
                onClick={() => setAutoVoiceEnabled(!autoVoiceEnabled)}
                className={`w-14 h-8 rounded-full transition-colors p-1 ${
                  autoVoiceEnabled ? 'bg-teal-700' : 'bg-charcoal-300'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full bg-white shadow-md transform transition-transform ${
                    autoVoiceEnabled ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Multilingual & Language */}
          <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-cream-200">
              <div className="w-10 h-10 rounded-2xl bg-mustard-100 text-mustard-700 flex items-center justify-center">
                <Globe className="w-5 h-5 text-mustard-600" />
              </div>
              <div>
                <h2 className="font-display font-bold text-base text-charcoal-900">
                  Language & Speech Region
                </h2>
                <p className="text-xs text-charcoal-500">Supports English, Telugu (తెలుగు), and Hindi (हिन्दी)</p>
              </div>
            </div>

            <div className="space-y-2">
              {[
                { code: 'en' as LanguageCode, label: 'English (Indian English)', sub: 'Default interface & speech' },
                { code: 'te' as LanguageCode, label: 'తెలుగు (Telugu)', sub: 'పూర్తి తెలుగు అనువాదం మరియు వాయిస్' },
                { code: 'hi' as LanguageCode, label: 'हिन्दी (Hindi)', sub: 'संपूर्ण हिंदी इंटरफ़ेस और वॉइस' }
              ].map((l) => (
                <label
                  key={l.code}
                  onClick={() => setLanguage(l.code)}
                  className={`flex items-center justify-between p-3 rounded-2xl border cursor-pointer transition-all ${
                    language === l.code
                      ? 'border-teal-700 bg-teal-50/60 ring-2 ring-teal-700/30 font-bold'
                      : 'border-cream-300 bg-white hover:bg-cream-50'
                  }`}
                >
                  <div>
                    <p className="text-xs font-bold text-charcoal-900">{l.label}</p>
                    <p className="text-[11px] text-charcoal-500">{l.sub}</p>
                  </div>
                  {language === l.code && <CheckCircle2 className="w-4 h-4 text-teal-700" />}
                </label>
              ))}
            </div>

            {/* Logout / Session Exit Button */}
            <div className="pt-3 border-t border-cream-200">
              <button
                onClick={() => {
                  if (window.confirm('Are you sure you want to sign out of MyCare AI?')) {
                    logout();
                  }
                }}
                className="w-full py-2.5 px-4 rounded-xl border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
              >
                <LogOut className="w-4 h-4 text-red-600" />
                <span>{isDemoMode ? 'Exit Demo Session & Return to Login' : 'Log Out of MyCare AI'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};