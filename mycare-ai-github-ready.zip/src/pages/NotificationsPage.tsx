// ==========================================
// MYCARE AI - CENTRAL NOTIFICATION SYSTEM
// Reminders, Alerts, Mark Read, Filters
// ==========================================

import React, { useState } from 'react';
import {
  Bell,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Pill,
  Calendar,
  ShoppingBag,
  ShieldAlert,
  Trash2,
  Filter
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { NotificationItem } from '../types';

export const NotificationsPage: React.FC = () => {
  const {
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    unreadNotificationCount,
    t
  } = useApp();

  const [filterType, setFilterType] = useState<string>('all');

  const filteredNotifs = notifications.filter((n) => {
    if (filterType === 'all') return true;
    if (filterType === 'unread') return !n.read;
    return n.type === filterType;
  });

  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'medicine':
        return <Pill className="w-5 h-5 text-emerald-600" />;
      case 'appointment':
        return <Calendar className="w-5 h-5 text-teal-700" />;
      case 'emergency':
        return <ShieldAlert className="w-5 h-5 text-red-600" />;
      case 'order':
        return <ShoppingBag className="w-5 h-5 text-peach-600" />;
      case 'caregiver':
        return <CheckCircle2 className="w-5 h-5 text-mustard-600" />;
      default:
        return <Bell className="w-5 h-5 text-teal-700" />;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-display font-extrabold text-charcoal-900">
              {t.notifications} & Reminders
            </h1>
            {unreadNotificationCount > 0 && (
              <span className="text-xs bg-peach-500 text-white font-bold px-2.5 py-0.5 rounded-full">
                {unreadNotificationCount} Unread
              </span>
            )}
          </div>
          <p className="text-xs text-charcoal-500 mt-1">
            Medicine schedules, caregiver notes, appointment reminders, and safety alerts
          </p>
        </div>

        {unreadNotificationCount > 0 && (
          <button
            onClick={markAllNotificationsRead}
            className="px-4 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs shadow-sm transition-colors"
          >
            Mark All as Read
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'all', label: 'All Notifications' },
          { id: 'unread', label: 'Unread Only' },
          { id: 'medicine', label: 'Medicine Reminders' },
          { id: 'appointment', label: 'Appointments' },
          { id: 'caregiver', label: 'Caregiver Updates' },
          { id: 'order', label: 'Orders' },
          { id: 'emergency', label: 'Emergency Alerts' }
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setFilterType(f.id)}
            className={`px-4 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-colors ${
              filterType === f.id
                ? 'bg-teal-850 text-white shadow-sm'
                : 'bg-white border border-cream-300 text-charcoal-700 hover:bg-cream-100'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Notifications List */}
      <div className="space-y-3">
        {filteredNotifs.length === 0 ? (
          <div className="p-12 rounded-3xl bg-white border border-cream-300 text-center space-y-2">
            <Bell className="w-10 h-10 text-charcoal-300 mx-auto" />
            <p className="text-sm font-bold text-charcoal-700">No notifications in this category</p>
            <p className="text-xs text-charcoal-500">You are all caught up!</p>
          </div>
        ) : (
          filteredNotifs.map((n) => (
            <div
              key={n.id}
              onClick={() => markNotificationRead(n.id)}
              className={`p-4 rounded-3xl border transition-all cursor-pointer flex items-start gap-4 ${
                !n.read
                  ? 'bg-white border-teal-700/40 shadow-sm ring-1 ring-teal-700/20'
                  : 'bg-cream-50/60 border-cream-200 opacity-80'
              }`}
            >
              <div className="w-12 h-12 rounded-2xl bg-cream-100 flex items-center justify-center shrink-0 shadow-sm">
                {getIcon(n.type)}
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <h3 className={`font-bold text-sm ${!n.read ? 'text-charcoal-900 font-extrabold' : 'text-charcoal-800'}`}>
                    {n.title}
                  </h3>
                  <span className="text-[10px] text-charcoal-400 whitespace-nowrap">{n.timestamp}</span>
                </div>
                <p className="text-xs text-charcoal-600 mt-1">{n.message}</p>
              </div>

              {!n.read && (
                <div className="w-2.5 h-2.5 rounded-full bg-peach-500 shrink-0 mt-1.5" />
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
