// ==========================================
// MYCARE AI - FAMILY CIRCLE & CAREGIVER COORDINATION
// Invite members, assign care tasks, permission management
// ==========================================

import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  CheckCircle2,
  Circle,
  Plus,
  ShieldCheck,
  Key,
  Clock,
  Send,
  PhoneCall,
  Mail,
  AlertCircle,
  X,
  UserCheck,
  Trash2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { FamilyMember, CareTask } from '../types';
import { triggerConfetti } from '../utils/confetti';

export const FamilyPage: React.FC = () => {
  const {
    familyMembers,
    careTasks,
    toggleCareTask,
    addCareTask,
    inviteFamilyMember,
    deleteFamilyMember,
    currentUser,
    t
  } = useApp();

  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showTaskModal, setShowTaskModal] = useState(false);

  // Invite Form
  const [inviteName, setInviteName] = useState('');
  const [inviteRelation, setInviteRelation] = useState('Relative');
  const [invitePhone, setInvitePhone] = useState('');
  const [inviteRole, setInviteRole] = useState<'Family Member' | 'Care Coordinator'>('Family Member');

  // Task Form
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDescription, setTaskDescription] = useState('');
  const [taskCategory, setTaskCategory] = useState<CareTask['category']>('General');
  const [taskAssignedTo, setTaskAssignedTo] = useState('Sister Anjali Rao');
  const [taskDueDate, setTaskDueDate] = useState('Today');
  const [taskUrgent, setTaskUrgent] = useState(false);

  const handleInviteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteName.trim()) return;

    inviteFamilyMember({
      name: inviteName,
      relation: inviteRelation,
      phone: invitePhone,
      role: inviteRole
    });

    setShowInviteModal(false);
    setInviteName('');
    setInvitePhone('');
    triggerConfetti(2000);
  };

  const handleTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;

    addCareTask({
      title: taskTitle,
      description: taskDescription,
      category: taskCategory,
      assignedTo: taskAssignedTo,
      assignedToRole: taskAssignedTo.includes('Anjali') ? 'Caregiver' : 'Family',
      dueDate: taskDueDate,
      urgent: taskUrgent
    });

    setShowTaskModal(false);
    setTaskTitle('');
    setTaskDescription('');
    triggerConfetti(2000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-display font-extrabold text-charcoal-900">
              {t.familyCircle} & Care Coordination
            </h1>
            <span className="text-xs bg-lavender-100 text-lavender-700 font-bold px-2.5 py-0.5 rounded-full">
              {familyMembers.length} Members Connected
            </span>
          </div>
          <p className="text-xs text-charcoal-500 mt-1">
            Collaborative eldercare: shared schedules, task delegation, and permission-controlled health sharing
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowTaskModal(true)}
            className="px-4 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Assign Care Task</span>
          </button>

          <button
            onClick={() => setShowInviteModal(true)}
            className="px-4 py-2.5 rounded-xl bg-peach-500 hover:bg-peach-600 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-all"
          >
            <UserPlus className="w-4 h-4" />
            <span>Invite Member / Nurse</span>
          </button>
        </div>
      </div>

      {/* Grid: Connected Members vs Tasks Board */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Connected Family Members & Permissions */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-4">
            <h2 className="text-base font-display font-bold text-charcoal-900 pb-2 border-b border-cream-200">
              Care Circle Members & Access Rights
            </h2>

            <div className="space-y-3">
              {familyMembers.map((member) => (
                <div
                  key={member.id}
                  className="p-4 rounded-2xl bg-cream-50 border border-cream-200 space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={member.avatar}
                        alt={member.name}
                        className="w-12 h-12 rounded-full object-cover ring-2 ring-peach-300 shrink-0"
                      />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h3 className="font-bold text-sm text-charcoal-900">{member.name}</h3>
                          {member.isDemoData && (
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-sage-200 text-sage-800">
                              DEMO
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-peach-600 font-semibold">{member.relation}</p>
                        <p className="text-[11px] text-charcoal-500">{member.role}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                          member.status === 'Active'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {member.status}
                      </span>
                      <button
                        onClick={() => {
                          if (window.confirm(`Remove ${member.name} from your care circle?`)) {
                            deleteFamilyMember(member.id);
                          }
                        }}
                        className="p-1 rounded-lg text-charcoal-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                        title="Remove member"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Permissions matrix */}
                  <div className="p-2.5 rounded-xl bg-white border border-cream-200 text-[11px] space-y-1">
                    <span className="font-bold text-charcoal-600 uppercase text-[10px] block">
                      Granted Permissions:
                    </span>
                    <div className="grid grid-cols-2 gap-1 text-charcoal-700">
                      <span className={member.permissions.canViewVitals ? 'text-teal-850 font-bold' : 'text-charcoal-400 line-through'}>
                        ✓ View Health Vitals
                      </span>
                      <span className={member.permissions.canManageMedicines ? 'text-teal-850 font-bold' : 'text-charcoal-400 line-through'}>
                        ✓ Manage Medicines
                      </span>
                      <span className={member.permissions.canBookAppointments ? 'text-teal-850 font-bold' : 'text-charcoal-400 line-through'}>
                        ✓ Book Appointments
                      </span>
                      <span className={member.permissions.canReceiveSOS ? 'text-red-700 font-bold' : 'text-charcoal-400 line-through'}>
                        ✓ Receive SOS Alerts
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1">
                    <a
                      href={`tel:${member.phone}`}
                      className="text-teal-850 hover:underline font-bold flex items-center gap-1"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>{member.phone}</span>
                    </a>
                    <span className="text-[10px] text-charcoal-400">{member.lastActive}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Coordinated Care Tasks Board */}
        <div className="lg:col-span-7 space-y-4">
          <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-cream-200">
              <div>
                <h2 className="text-base font-display font-bold text-charcoal-900">
                  Care Tasks & Delegated Activities
                </h2>
                <p className="text-xs text-charcoal-500">
                  Tasks assigned to professional nurse Sister Anjali and daughter Priya
                </p>
              </div>

              <span className="text-xs font-bold text-teal-850 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
                {careTasks.filter(t => t.completed).length} / {careTasks.length} Completed
              </span>
            </div>

            <div className="space-y-3">
              {careTasks.map((task) => (
                <div
                  key={task.id}
                  onClick={() => {
                    toggleCareTask(task.id);
                    triggerConfetti(1500);
                  }}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                    task.completed
                      ? 'bg-cream-100/60 border-cream-300 opacity-75'
                      : 'bg-white border-cream-300 hover:border-teal-700/50 shadow-sm'
                  }`}
                >
                  <div className="mt-0.5 shrink-0 text-teal-700">
                    {task.completed ? (
                      <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                    ) : (
                      <Circle className="w-6 h-6 text-charcoal-400 hover:text-teal-700" />
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <h3
                        className={`text-sm font-bold ${
                          task.completed ? 'line-through text-charcoal-500' : 'text-charcoal-900'
                        }`}
                      >
                        {task.title}
                      </h3>
                      {task.urgent && !task.completed && (
                        <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-peach-500 text-white">
                          Urgent
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-charcoal-600 mt-1">{task.description}</p>

                    <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-charcoal-500">
                      <span className="text-teal-850 font-bold flex items-center gap-1">
                        <UserCheck className="w-3.5 h-3.5 text-teal-700" />
                        <span>Assigned to: {task.assignedTo}</span>
                      </span>
                      <span>• Due: {task.dueDate}</span>
                      {task.completedAt && (
                        <span className="text-emerald-700 font-bold">
                          ✓ Completed at {task.completedAt} by {task.completedBy}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Invite Member Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-cream-300 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-cream-200">
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Invite to MyCare Circle
              </h3>
              <button
                onClick={() => setShowInviteModal(false)}
                className="p-1 rounded-full text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleInviteSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul Sharma"
                  value={inviteName}
                  onChange={(e) => setInviteName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">Relationship</label>
                <input
                  type="text"
                  placeholder="e.g. Son, Daughter, Private Nurse"
                  value={inviteRelation}
                  onChange={(e) => setInviteRelation(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">Mobile Phone (for SMS Invite)</label>
                <input
                  type="tel"
                  placeholder="+91 90000 00000"
                  value={invitePhone}
                  onChange={(e) => setInvitePhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">Access Role</label>
                <select
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                >
                  <option value="Family Member">Family Member</option>
                  <option value="Care Coordinator">Care Coordinator / Certified Nurse</option>
                </select>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-peach-500 hover:bg-peach-600 text-white font-bold text-xs shadow-md transition-colors"
                >
                  Send Invitation Code
                </button>
                <button
                  type="button"
                  onClick={() => setShowInviteModal(false)}
                  className="px-4 py-3 rounded-xl bg-cream-200 text-charcoal-700 font-semibold text-xs"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Assign Task Modal */}
      {showTaskModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-cream-300 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-cream-200">
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Assign New Care Task
              </h3>
              <button
                onClick={() => setShowTaskModal(false)}
                className="p-1 rounded-full text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleTaskSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">Task Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Check evening blood glucose"
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">Description</label>
                <input
                  type="text"
                  placeholder="e.g. Before dinner, record reading in app"
                  value={taskDescription}
                  onChange={(e) => setTaskDescription(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">Assignee</label>
                  <select
                    value={taskAssignedTo}
                    onChange={(e) => setTaskAssignedTo(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  >
                    <option value="Sister Anjali Rao">Sister Anjali Rao (Nurse)</option>
                    <option value="Priya Sharma">Priya Sharma (Daughter)</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">Due Date</label>
                  <select
                    value={taskDueDate}
                    onChange={(e) => setTaskDueDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  >
                    <option value="Today">Today</option>
                    <option value="Tomorrow">Tomorrow</option>
                    <option value="This Week">This Week</option>
                  </select>
                </div>
              </div>

              <label className="flex items-center gap-2 text-xs font-bold text-peach-600 pt-1">
                <input
                  type="checkbox"
                  checked={taskUrgent}
                  onChange={(e) => setTaskUrgent(e.target.checked)}
                  className="text-peach-500 rounded"
                />
                <span>Mark as High Priority / Urgent</span>
              </label>

              <div className="pt-2 flex gap-3">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs shadow-md transition-colors"
                >
                  Create Care Task
                </button>
                <button
                  type="button"
                  onClick={() => setShowTaskModal(false)}
                  className="px-4 py-3 rounded-xl bg-cream-200 text-charcoal-700 font-semibold text-xs"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
