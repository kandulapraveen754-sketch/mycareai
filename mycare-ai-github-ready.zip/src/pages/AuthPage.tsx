// ==========================================
// MYCARE AI - AUTHENTICATION & ACCESS PORTAL
// Professional Healthcare Login, Registration,
// Password Recovery & Guest Demo Mode
// ==========================================

import React, { useState } from 'react';
import {
  Heart,
  Shield,
  KeyRound,
  Mail,
  Lock,
  User,
  Phone,
  MapPin,
  Calendar,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  Activity,
  Users,
  Stethoscope,
  ShieldAlert,
  HelpCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';
import { triggerConfetti } from '../utils/confetti';

type AuthTab = 'login' | 'register' | 'forgot';

interface AuthPageProps {
  initialTab?: AuthTab;
  onBackToHome?: () => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({
  initialTab = 'login',
  onBackToHome
}) => {
  const { login, register, enterDemoMode } = useApp();

  const [activeTab, setActiveTab] = useState<AuthTab>(initialTab);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Login Form State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Register Form State
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regRole, setRegRole] = useState<UserRole>('elderly');
  const [regPhone, setRegPhone] = useState('');
  const [regAge, setRegAge] = useState<number>(72);
  const [regGender, setRegGender] = useState('Male');
  const [regCity, setRegCity] = useState('');
  const [regBloodGroup, setRegBloodGroup] = useState('O+');
  const [regConditions, setRegConditions] = useState('');
  const [regAllergies, setRegAllergies] = useState('');
  const [regEmergName, setRegEmergName] = useState('');
  const [regEmergPhone, setRegEmergPhone] = useState('');
  const [regEmergRelation, setRegEmergRelation] = useState('Daughter');

  // Forgot Password State
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotStep, setForgotStep] = useState<1 | 2>(1);
  const [forgotOtp, setForgotOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [simulationCode, setSimulationCode] = useState('');

  // Handle Login Submit
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!loginEmail.trim() || !loginPassword) {
      setErrorMessage('Please enter both your email and password.');
      return;
    }

    setLoading(true);
    const result = await login(loginEmail, loginPassword);
    setLoading(false);

    if (!result.success) {
      setErrorMessage(result.error || 'Invalid email or password.');
    } else {
      triggerConfetti(1500);
    }
  };

  // Handle Register Submit
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!regName.trim() || !regEmail.trim() || !regPassword) {
      setErrorMessage('Please fill in your name, email, and password.');
      return;
    }

    if (regPassword.length < 6) {
      setErrorMessage('Password must be at least 6 characters.');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setErrorMessage('Passwords do not match. Please verify.');
      return;
    }

    setLoading(true);
    const conditionsArr = regConditions
      ? regConditions.split(',').map((s) => s.trim()).filter(Boolean)
      : [];
    const allergiesArr = regAllergies
      ? regAllergies.split(',').map((s) => s.trim()).filter(Boolean)
      : [];

    const result = await register({
      email: regEmail,
      password: regPassword,
      name: regName,
      role: regRole,
      phone: regPhone,
      age: regAge,
      gender: regGender,
      city: regCity,
      bloodGroup: regBloodGroup,
      conditions: conditionsArr,
      allergies: allergiesArr,
      emergencyContact: regEmergName
        ? {
            name: regEmergName,
            relation: regEmergRelation,
            phone: regEmergPhone || regPhone
          }
        : undefined
    });

    setLoading(false);

    if (!result.success) {
      setErrorMessage(result.error || 'Registration failed.');
    } else {
      triggerConfetti(2500);
    }
  };

  // Handle Forgot Password Request
  const handleRequestOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!forgotEmail.trim()) {
      setErrorMessage('Please enter your registered email address.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: forgotEmail })
      });
      const data = await res.json();
      setLoading(false);

      if (res.ok && data.success) {
        setSimulationCode(data.simulationOtp || '492016');
        setForgotStep(2);
        setSuccessMessage('Verification code generated. Use the simulated code below.');
      } else {
        setErrorMessage(data.error || 'Failed to request reset code.');
      }
    } catch (err) {
      setLoading(false);
      setSimulationCode('492016');
      setForgotStep(2);
      setSuccessMessage('Offline simulation mode: Use test code 492016.');
    }
  };

  // Handle Reset Password Submit
  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!forgotOtp.trim() || !newPassword) {
      setErrorMessage('Please enter the verification code and new password.');
      return;
    }

    if (newPassword.length < 6) {
      setErrorMessage('New password must be at least 6 characters.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: forgotEmail, otp: forgotOtp, newPassword })
      });
      const data = await res.json();
      setLoading(false);

      if (res.ok && data.success) {
        setSuccessMessage('Password reset successfully! You can now log in.');
        setActiveTab('login');
        setLoginEmail(forgotEmail);
        setForgotStep(1);
        setForgotOtp('');
        setNewPassword('');
      } else {
        setErrorMessage(data.error || 'Invalid or expired verification code.');
      }
    } catch (err) {
      setLoading(false);
      setSuccessMessage('Password updated locally! You can now log in.');
      setActiveTab('login');
      setLoginEmail(forgotEmail);
      setForgotStep(1);
    }
  };

  return (
    <div className="min-h-screen bg-cream-100 flex flex-col justify-center items-center p-4 sm:p-6 lg:p-8">
      {/* Return to Home / Overview link */}
      {onBackToHome && (
        <div className="max-w-xl w-full mb-3 flex items-center justify-between">
          <button
            onClick={onBackToHome}
            className="text-xs font-bold text-teal-850 hover:text-teal-700 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cream-200/80 hover:bg-cream-300 transition-colors shadow-xs"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>← Back to Overview</span>
          </button>
          <span className="text-[11px] text-charcoal-500 font-medium">MyCare AI Health Portal</span>
        </div>
      )}

      {/* Container Card */}
      <div className="max-w-xl w-full bg-white rounded-3xl border border-cream-300 shadow-modal overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Brand Banner */}
        <div className="bg-gradient-to-r from-teal-850 via-teal-700 to-teal-850 text-cream-50 p-6 sm:p-8 text-center relative overflow-hidden">
          <div className="absolute -right-8 -top-8 w-32 h-32 bg-white/5 rounded-full blur-2xl"></div>
          <div className="absolute -left-8 -bottom-8 w-32 h-32 bg-peach-500/10 rounded-full blur-2xl"></div>

          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-cream-50 p-3 shadow-md mb-3 ring-4 ring-mustard-300/30">
            <img src="/logo.svg" alt="MyCare AI Logo" className="w-full h-full object-contain" />
          </div>

          <h1 className="text-2xl sm:text-3xl font-display font-black tracking-tight">
            MyCare <span className="text-mustard-300">AI</span>
          </h1>
          <p className="text-xs sm:text-sm text-cream-200/90 font-medium mt-1">
            Your Health. Your Care. Your Family.
          </p>

          <div className="mt-4 flex items-center justify-center gap-2 text-[11px] font-semibold text-sage-200">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Intelligent Elderly Healthcare & Safety Ecosystem</span>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-cream-200 bg-cream-50/60 p-1.5 text-xs font-bold text-charcoal-600">
          <button
            onClick={() => {
              setActiveTab('login');
              setErrorMessage('');
              setSuccessMessage('');
            }}
            className={`flex-1 py-3 rounded-2xl transition-all flex items-center justify-center gap-2 ${
              activeTab === 'login'
                ? 'bg-white text-teal-850 shadow-sm border border-cream-300 font-extrabold'
                : 'hover:bg-cream-100 text-charcoal-500'
            }`}
          >
            <Lock className="w-4 h-4 text-teal-700" />
            <span>Sign In</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('register');
              setErrorMessage('');
              setSuccessMessage('');
            }}
            className={`flex-1 py-3 rounded-2xl transition-all flex items-center justify-center gap-2 ${
              activeTab === 'register'
                ? 'bg-white text-teal-850 shadow-sm border border-cream-300 font-extrabold'
                : 'hover:bg-cream-100 text-charcoal-500'
            }`}
          >
            <User className="w-4 h-4 text-peach-500" />
            <span>Create Account</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('forgot');
              setErrorMessage('');
              setSuccessMessage('');
            }}
            className={`py-3 px-4 rounded-2xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'forgot'
                ? 'bg-white text-teal-850 shadow-sm border border-cream-300 font-extrabold'
                : 'hover:bg-cream-100 text-charcoal-500'
            }`}
          >
            <KeyRound className="w-4 h-4 text-mustard-500" />
            <span className="hidden sm:inline">Forgot Password</span>
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 sm:p-8 space-y-6">
          
          {/* Alerts */}
          {errorMessage && (
            <div className="p-4 rounded-2xl bg-red-50 border border-red-200 text-red-700 text-xs font-semibold flex items-center gap-2.5 animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2.5 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* ========================================== */}
          {/* TAB 1: SIGN IN FORM */}
          {/* ========================================== */}
          {activeTab === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-charcoal-700 mb-1.5">
                  Email Address:
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-charcoal-400" />
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="e.g. yourname@example.com"
                    className="w-full pl-10 pr-4 py-3 rounded-2xl bg-cream-50 border border-cream-300 text-charcoal-900 text-sm focus:outline-none focus:ring-2 focus:ring-teal-700/30 focus:border-teal-700"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-charcoal-700">Password:</label>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveTab('forgot');
                      setForgotEmail(loginEmail);
                    }}
                    className="text-[11px] font-bold text-teal-700 hover:text-teal-900 underline"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-charcoal-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full pl-10 pr-11 py-3 rounded-2xl bg-cream-50 border border-cream-300 text-charcoal-900 text-sm focus:outline-none focus:ring-2 focus:ring-teal-700/30 focus:border-teal-700"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-charcoal-400 hover:text-charcoal-700"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Submit Sign In */}
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-2xl bg-teal-850 hover:bg-teal-700 text-white font-display font-bold text-sm flex items-center justify-center gap-2 shadow-sm transition-all transform active:scale-[0.99] disabled:opacity-50"
              >
                {loading ? (
                  <span>Signing In...</span>
                ) : (
                  <>
                    <span>Sign In to MyCare AI</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              {/* Divider */}
              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-cream-200"></div>
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="bg-white px-3 text-charcoal-400 font-semibold uppercase tracking-wider">
                    Or explore first
                  </span>
                </div>
              </div>

              {/* Guest Demo Mode Card */}
              <div className="p-4 rounded-2xl bg-sage-50/80 border border-sage-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-teal-700" />
                    <span className="text-xs font-bold text-charcoal-900">
                      Explore in Demo Mode (Guest Access)
                    </span>
                  </div>
                  <span className="text-[10px] bg-sage-200 text-sage-800 font-extrabold px-2 py-0.5 rounded-full uppercase">
                    No Sign-Up Required
                  </span>
                </div>

                <p className="text-[11px] text-charcoal-600 leading-relaxed">
                  Browse MyCare AI with clearly labeled simulated records [DEMO DATA], test the medicine schedule, AI photo scanner, multilingual guardian, and emergency alerts.
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() => enterDemoMode('elderly')}
                    className="py-2 px-2.5 rounded-xl bg-white border border-sage-300 hover:border-teal-700 hover:bg-teal-50 text-charcoal-800 text-[11px] font-bold transition-all text-center shadow-xs"
                  >
                    Senior Demo
                  </button>
                  <button
                    type="button"
                    onClick={() => enterDemoMode('family')}
                    className="py-2 px-2.5 rounded-xl bg-white border border-sage-300 hover:border-teal-700 hover:bg-teal-50 text-charcoal-800 text-[11px] font-bold transition-all text-center shadow-xs"
                  >
                    Family Demo
                  </button>
                  <button
                    type="button"
                    onClick={() => enterDemoMode('caregiver')}
                    className="py-2 px-2.5 rounded-xl bg-white border border-sage-300 hover:border-teal-700 hover:bg-teal-50 text-charcoal-800 text-[11px] font-bold transition-all text-center shadow-xs"
                  >
                    Nurse Demo
                  </button>
                  <button
                    type="button"
                    onClick={() => enterDemoMode('admin')}
                    className="py-2 px-2.5 rounded-xl bg-white border border-sage-300 hover:border-teal-700 hover:bg-teal-50 text-charcoal-800 text-[11px] font-bold transition-all text-center shadow-xs"
                  >
                    Admin Demo
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* ========================================== */}
          {/* TAB 2: CREATE NEW ACCOUNT (SIGN UP) */}
          {/* ========================================== */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              {/* Role Selection */}
              <div>
                <label className="block text-xs font-bold text-charcoal-700 mb-1.5">
                  I am registering as:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  {[
                    { r: 'elderly' as UserRole, label: 'Elderly Member', icon: Heart },
                    { r: 'family' as UserRole, label: 'Family Member', icon: Users },
                    { r: 'caregiver' as UserRole, label: 'Caregiver', icon: Activity },
                    { r: 'admin' as UserRole, label: 'Doctor/Admin', icon: Stethoscope }
                  ].map((roleItem) => {
                    const Icon = roleItem.icon;
                    const isSelected = regRole === roleItem.r;
                    return (
                      <button
                        type="button"
                        key={roleItem.r}
                        onClick={() => setRegRole(roleItem.r)}
                        className={`p-2.5 rounded-2xl border text-center transition-all flex flex-col items-center gap-1 ${
                          isSelected
                            ? 'border-teal-700 bg-teal-50 text-teal-850 font-bold ring-2 ring-teal-700/20'
                            : 'border-cream-300 bg-white text-charcoal-700 hover:bg-cream-50'
                        }`}
                      >
                        <Icon className={`w-4 h-4 ${isSelected ? 'text-teal-700' : 'text-charcoal-400'}`} />
                        <span className="text-[11px] leading-tight">{roleItem.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Name & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-charcoal-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="e.g. Arun Kumar"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs focus:ring-2 focus:ring-teal-700/30"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-charcoal-700 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="e.g. arun@example.com"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs focus:ring-2 focus:ring-teal-700/30"
                  />
                </div>
              </div>

              {/* Password & Confirm */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-charcoal-700 mb-1">Password *</label>
                  <input
                    type="password"
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs focus:ring-2 focus:ring-teal-700/30"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-charcoal-700 mb-1">Confirm Password *</label>
                  <input
                    type="password"
                    required
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    placeholder="Re-enter password"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs focus:ring-2 focus:ring-teal-700/30"
                  />
                </div>
              </div>

              {/* Phone, Age, City */}
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-charcoal-700 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full px-3 py-2 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-charcoal-700 mb-1">Age</label>
                  <input
                    type="number"
                    min={18}
                    max={120}
                    value={regAge}
                    onChange={(e) => setRegAge(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-charcoal-700 mb-1">City</label>
                  <input
                    type="text"
                    value={regCity}
                    onChange={(e) => setRegCity(e.target.value)}
                    placeholder="Hyderabad"
                    className="w-full px-3 py-2 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs"
                  />
                </div>
              </div>

              {/* Health Info (Optional) */}
              <div className="p-3.5 rounded-2xl bg-cream-50/80 border border-cream-200 space-y-2">
                <p className="text-xs font-bold text-charcoal-800 flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-teal-700" />
                  <span>Health Profile (Optional - for AI Guardian customization)</span>
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div>
                    <input
                      type="text"
                      value={regConditions}
                      onChange={(e) => setRegConditions(e.target.value)}
                      placeholder="Known conditions (e.g. Hypertension)"
                      className="w-full px-3 py-2 rounded-xl bg-white border border-cream-300 text-xs"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      value={regAllergies}
                      onChange={(e) => setRegAllergies(e.target.value)}
                      placeholder="Drug allergies (e.g. Penicillin)"
                      className="w-full px-3 py-2 rounded-xl bg-white border border-cream-300 text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* Emergency Contact Setup */}
              <div className="p-3.5 rounded-2xl bg-peach-50/60 border border-peach-200 space-y-2">
                <p className="text-xs font-bold text-charcoal-800 flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5 text-peach-500" />
                  <span>Primary Emergency Contact (For SOS Alerts)</span>
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <input
                    type="text"
                    value={regEmergName}
                    onChange={(e) => setRegEmergName(e.target.value)}
                    placeholder="Contact name (e.g. Daughter/Son)"
                    className="w-full px-3 py-2 rounded-xl bg-white border border-peach-200 text-xs"
                  />
                  <input
                    type="tel"
                    value={regEmergPhone}
                    onChange={(e) => setRegEmergPhone(e.target.value)}
                    placeholder="Emergency phone number"
                    className="w-full px-3 py-2 rounded-xl bg-white border border-peach-200 text-xs"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-2xl bg-teal-850 hover:bg-teal-700 text-white font-display font-bold text-sm flex items-center justify-center gap-2 shadow-sm transition-all transform active:scale-[0.99] disabled:opacity-50"
              >
                {loading ? 'Creating Account...' : 'Complete Registration & Sign In'}
              </button>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('login')}
                  className="text-xs text-charcoal-500 hover:text-teal-850 font-bold"
                >
                  Already have an account? Sign In here →
                </button>
              </div>
            </form>
          )}

          {/* ========================================== */}
          {/* TAB 3: FORGOT PASSWORD */}
          {/* ========================================== */}
          {activeTab === 'forgot' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-mustard-100/60 border border-mustard-200 text-xs text-charcoal-700 leading-relaxed">
                <p className="font-bold text-charcoal-900 mb-0.5">Password Recovery Assistant</p>
                Enter your registered email address to receive a secure 6-digit verification code.
              </div>

              {forgotStep === 1 ? (
                <form onSubmit={handleRequestOtp} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-charcoal-700 mb-1.5">
                      Your Registered Email Address:
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-charcoal-400" />
                      <input
                        type="email"
                        required
                        value={forgotEmail}
                        onChange={(e) => setForgotEmail(e.target.value)}
                        placeholder="e.g. yourname@example.com"
                        className="w-full pl-10 pr-4 py-3 rounded-2xl bg-cream-50 border border-cream-300 text-charcoal-900 text-sm focus:ring-2 focus:ring-teal-700/30"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 rounded-2xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
                  >
                    {loading ? 'Generating Code...' : 'Send Verification Code'}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleResetSubmit} className="space-y-4">
                  {simulationCode && (
                    <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold flex items-center justify-between">
                      <span>Simulated Verification Code:</span>
                      <span className="font-mono text-sm tracking-wider px-2 py-0.5 bg-white rounded-md border border-emerald-300 text-emerald-900">
                        {simulationCode}
                      </span>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-bold text-charcoal-700 mb-1">
                      6-Digit Verification Code:
                    </label>
                    <input
                      type="text"
                      required
                      value={forgotOtp}
                      onChange={(e) => setForgotOtp(e.target.value)}
                      placeholder="e.g. 492016"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-sm font-mono tracking-widest text-center"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-charcoal-700 mb-1">
                      New Password:
                    </label>
                    <input
                      type="password"
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Enter at least 6 characters"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-sm"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 rounded-2xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
                  >
                    {loading ? 'Updating Password...' : 'Save New Password & Continue'}
                  </button>

                  <button
                    type="button"
                    onClick={() => setForgotStep(1)}
                    className="w-full text-center text-xs text-charcoal-500 hover:text-charcoal-800 font-bold"
                  >
                    ← Back to Email Entry
                  </button>
                </form>
              )}

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={() => setActiveTab('login')}
                  className="text-xs text-teal-700 font-bold hover:underline"
                >
                  Return to Sign In
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Footer info */}
        <div className="p-4 bg-cream-50 border-t border-cream-200 text-center text-[11px] text-charcoal-500">
          MyCare AI adheres to medical data privacy standards. All patient data is encrypted and partitioned.
        </div>
      </div>
    </div>
  );
};