// ==========================================
// MYCARE AI - EMERGENCY SHIELD SOS PAGE
// Massive SOS trigger, multi-contact emergency alert,
// GPS location dispatch, direct dialing shortcuts,
// Contact management (Add / Edit / Remove)
// ==========================================

import React, { useState } from 'react';
import {
  ShieldAlert,
  PhoneCall,
  MapPin,
  AlertTriangle,
  Send,
  Users,
  Check,
  CheckCircle2,
  Clock,
  Navigation,
  FileWarning,
  Plus,
  Trash2,
  X,
  Edit2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EmergencyContact } from '../types';

export const EmergencyPage: React.FC = () => {
  const {
    triggerSOS,
    resolveSOS,
    cancelSOS,
    isSOSActive,
    emergencyAlert,
    emergencyContacts,
    addEmergencyContact,
    deleteEmergencyContact,
    updateEmergencyContact,
    t
  } = useApp();

  const [locationConsent, setLocationConsent] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);

  // New Contact State
  const [contactName, setContactName] = useState('');
  const [contactRelation, setContactRelation] = useState('Family');
  const [contactPhone, setContactPhone] = useState('');
  const [contactPrimary, setContactPrimary] = useState(false);

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName.trim() || !contactPhone.trim()) return;

    addEmergencyContact({
      name: contactName.trim(),
      relation: contactRelation.trim(),
      phone: contactPhone.trim(),
      isPrimary: contactPrimary,
      notifyOnSOS: true
    });

    setShowAddModal(false);
    setContactName('');
    setContactRelation('Family');
    setContactPhone('');
    setContactPrimary(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="rounded-3xl bg-peach-50 border border-peach-200 p-6 shadow-card flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-display font-extrabold text-charcoal-900">
              {t.emergencyShield} & Immediate Assistance
            </h1>
            <span
              className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                isSOSActive ? 'bg-red-600 text-white animate-pulse' : 'bg-emerald-100 text-emerald-800'
              }`}
            >
              {isSOSActive ? "SOS ACTIVE NOW" : "Shield Armed & Ready"}
            </span>
          </div>
          <p className="text-xs text-charcoal-600 mt-1">
            One-touch multi-contact emergency broadcast with GPS coordinates and urgent phone shortcuts
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-all self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Emergency Contact</span>
        </button>
      </div>

      {/* Massive SOS Trigger Section */}
      <div className="rounded-3xl bg-white border border-cream-300 p-8 shadow-card flex flex-col items-center justify-center text-center space-y-6">
        <div className="max-w-md space-y-2">
          <h2 className="text-xl font-display font-black text-charcoal-900">
            Emergency Assistance Trigger
          </h2>
          <p className="text-xs text-charcoal-600">
            Pressing this button sends an immediate high-priority SMS, automated phone alert, and push notification with live location to all designated emergency contacts.
          </p>
        </div>

        {/* Large SOS Button */}
        <button
          onClick={() => triggerSOS(locationConsent)}
          className={`w-48 h-48 sm:w-56 sm:h-56 rounded-full flex flex-col items-center justify-center text-white shadow-2xl transition-all transform hover:scale-105 active:scale-95 ${
            isSOSActive
              ? 'bg-red-600 ring-8 ring-red-300 shadow-sos animate-pulse'
              : 'bg-gradient-to-tr from-peach-600 via-peach-500 to-terracotta ring-8 ring-peach-200 hover:ring-peach-300'
          }`}
        >
          <ShieldAlert className="w-16 h-16 sm:w-20 sm:h-20 mb-2" />
          <span className="font-display font-black text-2xl sm:text-3xl tracking-widest">
            {isSOSActive ? "ALERTING" : "EMERGENCY SOS"}
          </span>
          <span className="text-xs font-bold text-peach-100 mt-1">
            {isSOSActive ? "BROADCAST ACTIVE" : "TAP TO SEND HELP"}
          </span>
        </button>

        {/* GPS Consent checkbox */}
        <label className="flex items-center gap-2 text-xs font-bold text-charcoal-700 cursor-pointer">
          <input
            type="checkbox"
            checked={locationConsent}
            onChange={(e) => setLocationConsent(e.target.checked)}
            className="text-teal-700 rounded"
          />
          <MapPin className="w-4 h-4 text-peach-500" />
          <span>Include live GPS location in alert broadcast</span>
        </label>

        {isSOSActive && (
          <div className="w-full max-w-lg p-5 rounded-2xl bg-red-50 border border-red-300 text-left space-y-3 animate-in fade-in">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold text-red-800 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-red-600 animate-ping"></span>
                Emergency Broadcast Dispatched
              </span>
              <span className="text-xs font-mono font-bold text-red-700">{emergencyAlert?.timestamp}</span>
            </div>

            <p className="text-xs text-red-900 leading-relaxed">
              High-priority alerts sent to all configured contacts. Standby for callback or press below if safe.
            </p>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => resolveSOS()}
                className="flex-1 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs transition-colors text-center"
              >
                Mark as Safe & Resolve
              </button>
              <button
                onClick={cancelSOS}
                className="px-4 py-2.5 rounded-xl bg-white border border-red-300 text-red-700 hover:bg-red-100 font-bold text-xs transition-colors"
              >
                Cancel Alert
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Emergency Contacts List */}
      <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-cream-200">
          <div>
            <h3 className="font-display font-bold text-base text-charcoal-900">
              Emergency Response Contacts & Hotlines
            </h3>
            <p className="text-xs text-charcoal-500">
              Contacts automatically notified during SOS broadcasts
            </p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="text-xs font-bold text-teal-850 hover:text-teal-700 flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Contact</span>
          </button>
        </div>

        {emergencyContacts.length === 0 ? (
          <div className="p-8 text-center rounded-2xl bg-cream-50 border border-dashed border-cream-300">
            <Users className="w-8 h-8 text-charcoal-400 mx-auto mb-2" />
            <p className="text-sm font-bold text-charcoal-700">No emergency contacts added yet</p>
            <p className="text-xs text-charcoal-500 mt-1 mb-4">
              Add family members, doctors, or neighbors who should receive your SOS alerts.
            </p>
            <button
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2 rounded-xl bg-teal-850 text-white font-bold text-xs"
            >
              Add Your First Emergency Contact
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {emergencyContacts.map((contact) => (
              <div
                key={contact.id}
                className="p-4 rounded-2xl bg-cream-50 border border-cream-200 flex items-center justify-between gap-3 group"
              >
                <div className="min-w-0 pr-2">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-sm text-charcoal-900 truncate">{contact.name}</h4>
                    {contact.isPrimary && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-peach-100 text-peach-700">
                        Primary
                      </span>
                    )}
                    {contact.isDemoData && (
                      <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-sage-200 text-sage-800">
                        DEMO
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-charcoal-500 mt-0.5">{contact.relation} • {contact.phone}</p>
                  <span className="text-[10px] text-sage-700 font-semibold block mt-1">
                    ✓ Configured for Instant SOS Alert
                  </span>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <a
                    href={`tel:${contact.phone}`}
                    className="px-3.5 py-2 rounded-xl bg-teal-850 hover:bg-teal-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>Call</span>
                  </a>

                  <button
                    onClick={() => {
                      if (window.confirm(`Remove ${contact.name} from emergency contacts?`)) {
                        deleteEmergencyContact(contact.id);
                      }
                    }}
                    className="p-2 rounded-xl text-charcoal-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                    title="Delete Contact"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* National Hotlines in India */}
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
            <div>
              <p className="font-bold text-amber-900">National Emergency Ambulances & Medical Support</p>
              <p className="text-amber-800">
                112 (National Unified Emergency) • 108 (Free Emergency Ambulance) • 1066 (Apollo Emergency)
              </p>
            </div>
          </div>
          <a
            href="tel:112"
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold self-start sm:self-center"
          >
            Call 112
          </a>
        </div>
      </div>

      {/* Add Contact Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="max-w-md w-full bg-white rounded-3xl p-6 border border-cream-300 shadow-modal space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-cream-200">
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Add Emergency Contact
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-charcoal-400 hover:text-charcoal-700 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddContact} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-charcoal-700 mb-1">Contact Name *</label>
                <input
                  type="text"
                  required
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder="e.g. Priya (Daughter)"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs focus:ring-2 focus:ring-teal-700/30"
                />
              </div>

              <div>
                <label className="block font-bold text-charcoal-700 mb-1">Relationship *</label>
                <select
                  value={contactRelation}
                  onChange={(e) => setContactRelation(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs"
                >
                  <option value="Daughter">Daughter</option>
                  <option value="Son">Son</option>
                  <option value="Spouse">Spouse</option>
                  <option value="Caregiver / Nurse">Caregiver / Nurse</option>
                  <option value="Primary Doctor">Primary Doctor</option>
                  <option value="Neighbor">Neighbor</option>
                  <option value="Hospital Ambulance">Hospital Ambulance</option>
                  <option value="Other Relative">Other Relative</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-charcoal-700 mb-1">Phone Number *</label>
                <input
                  type="tel"
                  required
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-900 text-xs focus:ring-2 focus:ring-teal-700/30"
                />
              </div>

              <label className="flex items-center gap-2 cursor-pointer pt-1 font-semibold text-charcoal-700">
                <input
                  type="checkbox"
                  checked={contactPrimary}
                  onChange={(e) => setContactPrimary(e.target.checked)}
                  className="rounded text-teal-700"
                />
                <span>Set as Primary Contact (Called first during SOS)</span>
              </label>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-cream-200">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-cream-100 hover:bg-cream-200 text-charcoal-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold"
                >
                  Save Emergency Contact
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};