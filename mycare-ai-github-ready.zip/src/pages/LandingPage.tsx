// ==========================================
// MYCARE AI - PREMIUM INTRODUCTORY LANDING PAGE
// "Care That Connects Generations."
// Comprehensive Healthcare Startup Presentation
// ==========================================

import React, { useState } from 'react';
import {
  Heart,
  Shield,
  Sparkles,
  Pill,
  Calendar,
  Users,
  BarChart3,
  ShieldAlert,
  PhoneCall,
  CheckCircle2,
  ArrowRight,
  Camera,
  ShoppingBag,
  Activity,
  Eye,
  Volume2,
  Globe,
  Clock,
  Lock,
  Check,
  ChevronRight,
  ChevronDown,
  Star,
  HelpCircle,
  FileText,
  MapPin,
  X,
  Menu,
  Stethoscope,
  Smile,
  AlertTriangle,
  Play
} from 'lucide-react';
import { UserRole } from '../types';

interface LandingPageProps {
  onGetStarted: () => void;
  onSignIn: () => void;
  onExploreDemo: (role?: UserRole) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onGetStarted,
  onSignIn,
  onExploreDemo
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeFeatureTab, setActiveFeatureTab] = useState<'guardian' | 'catalogue' | 'scanner' | 'emergency' | 'family'>('guardian');
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  // Footer Modals
  const [activeModal, setActiveModal] = useState<'about' | 'privacy' | 'terms' | null>(null);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-cream-100 text-charcoal-800 font-sans selection:bg-teal-700 selection:text-white">
      
      {/* ========================================== */}
      {/* 1. TOP STICKY HEADER & BRANDING */}
      {/* ========================================== */}
      <header className="sticky top-0 z-50 bg-cream-100/90 backdrop-blur-md border-b border-cream-300/80 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
          
          {/* Logo & Tagline */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div className="w-11 h-11 rounded-2xl bg-white p-2 shadow-sm border border-cream-300 ring-2 ring-mustard-300/40 flex items-center justify-center">
              <img src="/logo.svg" alt="MyCare AI" className="w-full h-full object-contain" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-display font-black text-xl tracking-tight text-teal-850">
                  MyCare <span className="text-peach-500">AI</span>
                </span>
                <span className="hidden sm:inline text-[10px] bg-teal-100 text-teal-850 font-bold px-2 py-0.5 rounded-full">
                  Elderly Care
                </span>
              </div>
              <p className="text-[11px] text-charcoal-500 font-medium tracking-wide">
                Your Health. Your Care. Your Family.
              </p>
            </div>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-7 text-xs font-bold text-charcoal-700">
            <button onClick={() => scrollToSection('features')} className="hover:text-teal-850 transition-colors">
              Platform Features
            </button>
            <button onClick={() => scrollToSection('catalogue')} className="hover:text-teal-850 transition-colors">
              500+ Pharmacy
            </button>
            <button onClick={() => scrollToSection('guardian')} className="hover:text-teal-850 transition-colors flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-mustard-500" />
              <span>AI Guardian</span>
            </button>
            <button onClick={() => scrollToSection('how-it-works')} className="hover:text-teal-850 transition-colors">
              How It Works
            </button>
            <button onClick={() => scrollToSection('faq')} className="hover:text-teal-850 transition-colors">
              FAQ
            </button>
          </nav>

          {/* Action CTAs */}
          <div className="hidden sm:flex items-center gap-2.5">
            <button
              onClick={() => onExploreDemo('elderly')}
              className="px-3.5 py-2 rounded-xl bg-sage-100 hover:bg-sage-200 text-teal-900 border border-sage-300 font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-teal-700" />
              <span>Explore Demo</span>
            </button>

            <button
              onClick={onSignIn}
              className="px-4 py-2 rounded-xl bg-white hover:bg-cream-200 text-charcoal-800 border border-cream-300 font-bold text-xs transition-all shadow-xs"
            >
              Sign In
            </button>

            <button
              onClick={onGetStarted}
              className="px-5 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all transform active:scale-95"
            >
              <span>Get Started</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mobile Hamburger Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl bg-cream-200 text-charcoal-700 lg:hidden"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-cream-300 bg-cream-50 p-4 space-y-3 animate-in slide-in-from-top-2">
            <nav className="flex flex-col space-y-2 text-sm font-bold text-charcoal-700">
              <button onClick={() => scrollToSection('features')} className="text-left py-1.5 hover:text-teal-850">
                Platform Features
              </button>
              <button onClick={() => scrollToSection('catalogue')} className="text-left py-1.5 hover:text-teal-850">
                500+ Pharmacy Catalogue
              </button>
              <button onClick={() => scrollToSection('guardian')} className="text-left py-1.5 hover:text-teal-850">
                AI Guardian Voice Assistant
              </button>
              <button onClick={() => scrollToSection('how-it-works')} className="text-left py-1.5 hover:text-teal-850">
                How It Works
              </button>
              <button onClick={() => scrollToSection('faq')} className="text-left py-1.5 hover:text-teal-850">
                Frequently Asked Questions
              </button>
            </nav>

            <div className="pt-3 border-t border-cream-200 flex flex-col gap-2">
              <button
                onClick={() => onExploreDemo('elderly')}
                className="w-full py-2.5 rounded-xl bg-sage-100 text-teal-900 border border-sage-300 font-bold text-xs flex items-center justify-center gap-1.5"
              >
                <Sparkles className="w-4 h-4 text-teal-700" />
                <span>Explore Demo (No Account Required)</span>
              </button>
              <button
                onClick={onSignIn}
                className="w-full py-2.5 rounded-xl bg-white border border-cream-300 text-charcoal-800 font-bold text-xs"
              >
                Sign In to MyCare AI
              </button>
              <button
                onClick={onGetStarted}
                className="w-full py-2.5 rounded-xl bg-teal-850 text-white font-bold text-xs"
              >
                Get Started Free
              </button>
            </div>
          </div>
        )}
      </header>

      {/* ========================================== */}
      {/* 2. HERO SECTION */}
      {/* ========================================== */}
      <section className="relative pt-10 pb-16 lg:pt-16 lg:pb-24 overflow-hidden">
        {/* Decorative background glows */}
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-sage-100/50 via-peach-100/30 to-transparent blur-3xl -z-10 rounded-full pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Content Column */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-sage-300 shadow-xs text-xs font-bold text-teal-850">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>AI-Powered Elderly Healthcare & Safety Ecosystem</span>
              </div>

              {/* Main Headline */}
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-black text-charcoal-900 leading-[1.1] tracking-tight">
                Care That Connects <br className="hidden sm:inline" />
                <span className="text-teal-850 underline decoration-peach-400 decoration-wavy decoration-2">
                  Generations.
                </span>
              </h1>

              {/* Subheading Description */}
              <p className="text-base sm:text-lg text-charcoal-600 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
                MyCare AI bridges elderly parents, caring families, assigned nurses, and verified doctors into one intuitive platform. Empowering seniors with effortless medicine reminders, multilingual AI voice guidance, 500+ verified medications, and instant GPS emergency safety.
              </p>

              {/* Primary Call to Actions */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-2">
                <button
                  onClick={onGetStarted}
                  className="w-full sm:w-auto px-7 py-4 rounded-2xl bg-teal-850 hover:bg-teal-700 text-white font-display font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-teal-900/15 transition-all transform active:scale-95"
                >
                  <span>Get Started Free</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => onExploreDemo('elderly')}
                  className="w-full sm:w-auto px-6 py-4 rounded-2xl bg-white hover:bg-cream-50 text-charcoal-800 border-2 border-cream-300 font-display font-bold text-sm flex items-center justify-center gap-2 shadow-card hover:border-teal-700 transition-all"
                >
                  <Sparkles className="w-4 h-4 text-mustard-500" />
                  <span>Explore Demo Mode</span>
                </button>
              </div>

              {/* Quick Persona Pills */}
              <div className="pt-2 text-xs text-charcoal-500 flex flex-wrap items-center justify-center lg:justify-start gap-2">
                <span className="font-semibold text-charcoal-700">Instant Demo Access:</span>
                <button
                  onClick={() => onExploreDemo('elderly')}
                  className="px-2.5 py-1 rounded-lg bg-cream-200/80 hover:bg-cream-300 text-charcoal-800 font-bold transition-colors"
                >
                  Senior View
                </button>
                <button
                  onClick={() => onExploreDemo('family')}
                  className="px-2.5 py-1 rounded-lg bg-cream-200/80 hover:bg-cream-300 text-charcoal-800 font-bold transition-colors"
                >
                  Family Daughter
                </button>
                <button
                  onClick={() => onExploreDemo('caregiver')}
                  className="px-2.5 py-1 rounded-lg bg-cream-200/80 hover:bg-cream-300 text-charcoal-800 font-bold transition-colors"
                >
                  Staff Nurse
                </button>
                <button
                  onClick={() => onExploreDemo('admin')}
                  className="px-2.5 py-1 rounded-lg bg-cream-200/80 hover:bg-cream-300 text-charcoal-800 font-bold transition-colors"
                >
                  Doctor Admin
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="pt-6 border-t border-cream-300/80 grid grid-cols-2 sm:grid-cols-4 gap-4 text-left">
                <div>
                  <p className="font-display font-black text-2xl text-teal-850">99.4%</p>
                  <p className="text-xs text-charcoal-500 font-medium">Dose Adherence</p>
                </div>
                <div>
                  <p className="font-display font-black text-2xl text-peach-500">500+</p>
                  <p className="text-xs text-charcoal-500 font-medium">Verified Medicines</p>
                </div>
                <div>
                  <p className="font-display font-black text-2xl text-teal-850">&lt; 3 Sec</p>
                  <p className="text-xs text-charcoal-500 font-medium">GPS SOS Dispatch</p>
                </div>
                <div>
                  <p className="font-display font-black text-2xl text-mustard-500">3 Lang</p>
                  <p className="text-xs text-charcoal-500 font-medium">EN • తెలుగు • हिन्दी</p>
                </div>
              </div>
            </div>

            {/* Right Visual Hero Column */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none">
                
                {/* Main Photo Card */}
                <div className="rounded-3xl overflow-hidden border-4 border-white shadow-2xl bg-white relative">
                  <img
                    src="https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?auto=format&fit=crop&w=800&q=80"
                    alt="Elderly Indian grandfather smiling with caring daughter and digital health monitoring"
                    className="w-full h-96 sm:h-[450px] object-cover object-center"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-charcoal-900/70 via-transparent to-transparent flex flex-col justify-end p-6 text-white">
                    <p className="text-xs uppercase tracking-wider font-extrabold text-mustard-300 mb-1">
                      Live Family Caregiver Sync
                    </p>
                    <p className="text-base font-bold font-display leading-tight">
                      Ramesh Sharma (74 yrs) with daughter Priya
                    </p>
                    <p className="text-xs text-cream-200 mt-0.5">
                      Medication schedule, vitals and appointments tracked together
                    </p>
                  </div>
                </div>

                {/* Floating Card 1: Morning Dose Taken */}
                <div className="absolute -top-4 -left-4 sm:-left-6 bg-white p-3.5 rounded-2xl border border-cream-300 shadow-modal flex items-center gap-3 animate-in fade-in duration-500 max-w-[220px]">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div>
                    <span className="text-[10px] font-extrabold text-emerald-700 uppercase tracking-wider block">
                      Dose Confirmed
                    </span>
                    <p className="text-xs font-bold text-charcoal-900 leading-tight">Telmikind 40</p>
                    <p className="text-[10px] text-charcoal-400">Taken at 08:12 AM ✓</p>
                  </div>
                </div>

                {/* Floating Card 2: AI Guardian Voice */}
                <div className="absolute top-1/3 -right-4 sm:-right-6 bg-teal-850 text-white p-3.5 rounded-2xl shadow-modal flex items-center gap-3 animate-in fade-in duration-700 max-w-[230px]">
                  <div className="w-10 h-10 rounded-xl bg-teal-700 text-mustard-300 flex items-center justify-center shrink-0">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-extrabold text-mustard-300 uppercase tracking-wider block">
                      AI Guardian
                    </span>
                    <p className="text-xs font-bold leading-tight">BP 126/82 mmHg</p>
                    <p className="text-[10px] text-cream-200">Stable & normal reading</p>
                  </div>
                </div>

                {/* Floating Card 3: Emergency Shield Armed */}
                <div className="absolute -bottom-4 -left-3 sm:-left-5 bg-white p-3.5 rounded-2xl border border-peach-200 shadow-modal flex items-center gap-3 animate-in fade-in duration-900 max-w-[230px]">
                  <div className="w-10 h-10 rounded-xl bg-peach-100 text-peach-600 flex items-center justify-center shrink-0">
                    <ShieldAlert className="w-5 h-5 text-peach-500" />
                  </div>
                  <div>
                    <span className="text-[10px] font-extrabold text-peach-600 uppercase tracking-wider block">
                      Emergency SOS
                    </span>
                    <p className="text-xs font-bold text-charcoal-900 leading-tight">Shield Armed & Ready</p>
                    <p className="text-[10px] text-charcoal-400">1-Touch GPS Alert</p>
                  </div>
                </div>

              </div>
            </div>

          </div>
        </div>
      </section>

      {/* ========================================== */}
      {/* 3. COMPREHENSIVE FEATURES GRID */}
      {/* ========================================== */}
      <section id="features" className="py-16 bg-cream-50 border-y border-cream-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs bg-peach-100 text-peach-700 font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">
              Comprehensive Senior Healthcare Hub
            </span>
            <h2 className="text-3xl sm:text-4xl font-display font-black text-charcoal-900">
              Everything Your Family Needs For Compassionate Elder Care
            </h2>
            <p className="text-sm sm:text-base text-charcoal-600 leading-relaxed">
              Engineered with geriatric specialists to address every aspect of senior health, safety, medication management, and family coordination.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            
            {/* Feature 1 */}
            <div className="p-6 rounded-3xl bg-white border border-cream-300 shadow-card hover:shadow-card-hover transition-all space-y-3.5">
              <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-850 flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-teal-700" />
              </div>
              <h3 className="font-display font-bold text-base text-charcoal-900">
                AI Guardian Voice Companion
              </h3>
              <p className="text-xs text-charcoal-600 leading-relaxed">
                Empathetic health assistant with speech recognition in English, Telugu (తెలుగు), and Hindi. Knows patient conditions and daily doses.
              </p>
              <span className="inline-block text-[11px] font-bold text-teal-700">
                Natural speech & advice →
              </span>
            </div>

            {/* Feature 2 */}
            <div className="p-6 rounded-3xl bg-white border border-cream-300 shadow-card hover:shadow-card-hover transition-all space-y-3.5">
              <div className="w-12 h-12 rounded-2xl bg-peach-100 text-peach-600 flex items-center justify-center">
                <ShoppingBag className="w-6 h-6 text-peach-500" />
              </div>
              <h3 className="font-display font-bold text-base text-charcoal-900">
                500+ Medicine Catalogue
              </h3>
              <p className="text-xs text-charcoal-600 leading-relaxed">
                Apollo Pharmacy & PharmEasy style catalogue across 12 categories. Search by brand or salt, and save up to 75% with genuine generic alternatives.
              </p>
              <span className="inline-block text-[11px] font-bold text-peach-600">
                7-Stage live tracking →
              </span>
            </div>

            {/* Feature 3 */}
            <div className="p-6 rounded-3xl bg-white border border-cream-300 shadow-card hover:shadow-card-hover transition-all space-y-3.5">
              <div className="w-12 h-12 rounded-2xl bg-sage-100 text-teal-900 flex items-center justify-center">
                <Camera className="w-6 h-6 text-teal-700" />
              </div>
              <h3 className="font-display font-bold text-base text-charcoal-900">
                AI Medicine Packaging Scanner
              </h3>
              <p className="text-xs text-charcoal-600 leading-relaxed">
                Take a quick webcam or phone photo of any blister strip. AI extracts salt composition, strength, and matches catalog inventory with safety warnings.
              </p>
              <span className="inline-block text-[11px] font-bold text-teal-700">
                Instant packaging OCR →
              </span>
            </div>

            {/* Feature 4 */}
            <div className="p-6 rounded-3xl bg-white border border-cream-300 shadow-card hover:shadow-card-hover transition-all space-y-3.5">
              <div className="w-12 h-12 rounded-2xl bg-mustard-100 text-mustard-700 flex items-center justify-center">
                <Pill className="w-6 h-6 text-mustard-600" />
              </div>
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Smart Dose Scheduling
              </h3>
              <p className="text-xs text-charcoal-600 leading-relaxed">
                Morning, afternoon, evening, and bedtime dosage schedules. Includes one-touch taken logging with celebratory confetti and reason tracking for skips.
              </p>
              <span className="inline-block text-[11px] font-bold text-mustard-700">
                Zero missed doses →
              </span>
            </div>

            {/* Feature 5 */}
            <div className="p-6 rounded-3xl bg-white border border-cream-300 shadow-card hover:shadow-card-hover transition-all space-y-3.5">
              <div className="w-12 h-12 rounded-2xl bg-lavender-100 text-lavender-700 flex items-center justify-center">
                <Calendar className="w-6 h-6 text-lavender-700" />
              </div>
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Doctor Appointments
              </h3>
              <p className="text-xs text-charcoal-600 leading-relaxed">
                Book verified geriatricians, cardiologists, and endocrinologists. Prevents double bookings and supports in-person clinic visits or video consults.
              </p>
              <span className="inline-block text-[11px] font-bold text-lavender-700">
                Verified specialists →
              </span>
            </div>

            {/* Feature 6 */}
            <div className="p-6 rounded-3xl bg-white border border-cream-300 shadow-card hover:shadow-card-hover transition-all space-y-3.5">
              <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-850 flex items-center justify-center">
                <Users className="w-6 h-6 text-teal-700" />
              </div>
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Family & Caregiver Circle
              </h3>
              <p className="text-xs text-charcoal-600 leading-relaxed">
                Connect family members in Bengaluru or overseas with assigned nurses in Hyderabad. Assign care tasks, manage permissions, and track daily vitals.
              </p>
              <span className="inline-block text-[11px] font-bold text-teal-700">
                Cross-city coordination →
              </span>
            </div>

            {/* Feature 7 */}
            <div className="p-6 rounded-3xl bg-white border border-cream-300 shadow-card hover:shadow-card-hover transition-all space-y-3.5">
              <div className="w-12 h-12 rounded-2xl bg-peach-100 text-peach-600 flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-peach-500" />
              </div>
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Health Insights & Charts
              </h3>
              <p className="text-xs text-charcoal-600 leading-relaxed">
                Visual adherence curves, blood pressure trends (systolic/diastolic), pulse, and blood glucose tracking powered by interactive charts.
              </p>
              <span className="inline-block text-[11px] font-bold text-peach-600">
                Clinical trend analysis →
              </span>
            </div>

            {/* Feature 8 */}
            <div className="p-6 rounded-3xl bg-white border border-cream-300 shadow-card hover:shadow-card-hover transition-all space-y-3.5">
              <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center">
                <ShieldAlert className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Emergency SOS Shield
              </h3>
              <p className="text-xs text-charcoal-600 leading-relaxed">
                Massive panic button that immediately broadcasts live GPS coordinates and automated alerts to family, caregivers, and national emergency lines (112 / 108).
              </p>
              <span className="inline-block text-[11px] font-bold text-red-600">
                Instant SOS dispatch →
              </span>
            </div>

          </div>
        </div>
      </section>

      {/* ========================================== */}
      {/* 4. INTERACTIVE MODULE SHOWCASE TABS */}
      {/* ========================================== */}
      <section id="guardian" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs bg-teal-100 text-teal-850 font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">
              Experience the Interface
            </span>
            <h2 className="text-3xl font-display font-black text-charcoal-900">
              Built for Ease of Use, Tested by Seniors
            </h2>
            <p className="text-sm text-charcoal-600">
              Explore how each core module helps seniors navigate their day with dignity and confidence.
            </p>
          </div>

          {/* Interactive Tab Selectors */}
          <div className="flex flex-wrap justify-center gap-2 p-1.5 rounded-2xl bg-cream-100 max-w-3xl mx-auto text-xs font-bold">
            {[
              { id: 'guardian', label: 'AI Guardian Voice', icon: Sparkles },
              { id: 'catalogue', label: '500+ Pharmacy Catalogue', icon: ShoppingBag },
              { id: 'scanner', label: 'AI Packaging Scanner', icon: Camera },
              { id: 'emergency', label: 'Emergency SOS Shield', icon: ShieldAlert },
              { id: 'family', label: 'Family Coordination', icon: Users },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeFeatureTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveFeatureTab(tab.id as any)}
                  className={`px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all ${
                    isActive
                      ? 'bg-teal-850 text-white shadow-sm'
                      : 'text-charcoal-600 hover:text-charcoal-900 hover:bg-cream-200/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Tab Content Display Card */}
          <div className="rounded-3xl bg-cream-50 border border-cream-300 p-6 sm:p-10 shadow-card max-w-5xl mx-auto">
            
            {activeFeatureTab === 'guardian' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-teal-100 text-teal-850 text-xs font-bold">
                    <Volume2 className="w-4 h-4" />
                    <span>Multilingual Voice & Speech Recognition</span>
                  </div>
                  <h3 className="text-2xl font-display font-extrabold text-charcoal-900">
                    Always-On Companion for Health Routines
                  </h3>
                  <p className="text-xs sm:text-sm text-charcoal-600 leading-relaxed">
                    Seniors simply speak or tap suggested questions. AI Guardian monitors their active medications, today's blood pressure, and upcoming appointments without complex menus.
                  </p>
                  <div className="space-y-2 text-xs text-charcoal-700">
                    <p className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>Speaks English, Telugu (తెలుగు), and Hindi (हिन्दी)</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>Contextually aware of patient's medical history & allergies</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>Strict medical safety safeguards prevent unverified advice</span>
                    </p>
                  </div>
                  <button
                    onClick={() => onExploreDemo('elderly')}
                    className="mt-2 px-5 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-2"
                  >
                    <span>Test AI Guardian Live</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Simulated Chat Interface */}
                <div className="rounded-2xl bg-white border border-cream-300 p-4 shadow-sm space-y-3 text-xs">
                  <div className="flex items-center gap-2 pb-2 border-b border-cream-200">
                    <div className="w-8 h-8 rounded-full bg-teal-850 text-white flex items-center justify-center font-bold">
                      <Sparkles className="w-4 h-4 text-mustard-300" />
                    </div>
                    <div>
                      <p className="font-bold text-charcoal-900">AI Guardian</p>
                      <p className="text-[10px] text-emerald-600 font-semibold">Active & Listening (Telugu / Hindi / English)</p>
                    </div>
                  </div>

                  <div className="space-y-2.5">
                    <div className="bg-cream-100 p-3 rounded-2xl max-w-[85%] text-charcoal-800">
                      Hello Ramesh ji! I noticed you took all 3 morning doses (Telmikind 40, Glycomet 500, Pan 40). Your blood pressure is stable at 126/82 mmHg. Would you like to review your afternoon schedule?
                    </div>
                    <div className="bg-teal-850 text-white p-3 rounded-2xl max-w-[85%] ml-auto text-right">
                      What medicine should I take after lunch?
                    </div>
                    <div className="bg-cream-100 p-3 rounded-2xl max-w-[85%] text-charcoal-800">
                      You have <strong>Ecosprin 75 mg</strong> scheduled at 01:30 PM with your meal and water.
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeFeatureTab === 'catalogue' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-peach-100 text-peach-700 text-xs font-bold">
                    <ShoppingBag className="w-4 h-4" />
                    <span>Apollo & PharmEasy Style Pharmacy</span>
                  </div>
                  <h3 className="text-2xl font-display font-extrabold text-charcoal-900">
                    500+ Verified Medicines with Salt Composition
                  </h3>
                  <p className="text-xs sm:text-sm text-charcoal-600 leading-relaxed">
                    Browse 12 healthcare categories including Blood Pressure, Diabetes, Heart Care, Fever & Pain, Thyroid, and Senior Mobility. Compare genuine generic equivalents with instant savings up to 75-80%.
                  </p>
                  <div className="space-y-2 text-xs text-charcoal-700">
                    <p className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>Multi-attribute search: Brand, Salt Name, Strength, Manufacturer</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>7-stage live order tracking with prescription upload</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>CSV Bulk Inventory Import & Export for pharmacies</span>
                    </p>
                  </div>
                  <button
                    onClick={() => onExploreDemo('elderly')}
                    className="mt-2 px-5 py-2.5 rounded-xl bg-peach-600 hover:bg-peach-700 text-white font-bold text-xs flex items-center gap-2"
                  >
                    <span>Browse Medicine Catalogue</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Simulated Product Card */}
                <div className="rounded-2xl bg-white border border-cream-300 p-5 shadow-sm space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-700">
                      Schedule H Prescription
                    </span>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                      In Stock (120 units)
                    </span>
                  </div>
                  <div className="flex gap-3">
                    <img
                      src="https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=150&q=80"
                      alt="Telmikind 40"
                      className="w-16 h-16 rounded-xl object-cover"
                    />
                    <div>
                      <h4 className="font-bold text-sm text-charcoal-900">Telmikind 40 Tablet</h4>
                      <p className="text-[11px] text-teal-800 font-semibold">Mankind Pharma Ltd.</p>
                      <p className="text-[10px] text-charcoal-500">Salt: Telmisartan (40 mg)</p>
                    </div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-sage-50 border border-sage-200 text-[11px] text-sage-900 flex items-center justify-between">
                    <span>Generic Equivalent Available:</span>
                    <span className="font-bold text-emerald-700">Save 74% (₹22 vs ₹85)</span>
                  </div>
                </div>
              </div>
            )}

            {activeFeatureTab === 'scanner' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-sage-100 text-teal-900 text-xs font-bold">
                    <Camera className="w-4 h-4" />
                    <span>AI Vision & Packaging OCR</span>
                  </div>
                  <h3 className="text-2xl font-display font-extrabold text-charcoal-900">
                    Snap a Photo, Instantly Identify
                  </h3>
                  <p className="text-xs sm:text-sm text-charcoal-600 leading-relaxed">
                    Seniors often get confused by medicine packaging or font size. The AI Medicine Photo Scanner reads the text directly from blister strips, verifies dosage strengths, and searches the pharmacy catalogue with confidence scores.
                  </p>
                  <button
                    onClick={() => onExploreDemo('elderly')}
                    className="mt-2 px-5 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-2"
                  >
                    <span>Launch Scanner Demo</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="rounded-2xl bg-white border border-cream-300 p-5 shadow-sm space-y-3 text-xs">
                  <div className="aspect-video bg-charcoal-900 rounded-xl overflow-hidden relative flex items-center justify-center text-white">
                    <img
                      src="https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=400&q=80"
                      alt="Packaging Scanner Demo"
                      className="w-full h-full object-cover opacity-70"
                    />
                    <div className="absolute inset-0 border-2 border-emerald-400 rounded-xl m-4 animate-pulse"></div>
                    <span className="absolute bottom-2 bg-emerald-600 px-3 py-0.5 rounded-full text-[10px] font-bold">
                      OCR Detected: Telmikind 40 (96% Confidence)
                    </span>
                  </div>
                  <p className="text-[11px] text-charcoal-500 italic">
                    Includes clinical safety disclaimers: Always verify packaging and consult your pharmacist.
                  </p>
                </div>
              </div>
            )}

            {activeFeatureTab === 'emergency' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-red-100 text-red-700 text-xs font-bold">
                    <ShieldAlert className="w-4 h-4" />
                    <span>Emergency SOS Shield</span>
                  </div>
                  <h3 className="text-2xl font-display font-extrabold text-charcoal-900">
                    Immediate Multi-Contact GPS Broadcast
                  </h3>
                  <p className="text-xs sm:text-sm text-charcoal-600 leading-relaxed">
                    In moments of acute distress, one press alerts all configured family members, neighbors, and caregivers with live GPS coordinates, while offering one-touch dialing for 112, 108, and hospital ambulances.
                  </p>
                  <button
                    onClick={() => onExploreDemo('elderly')}
                    className="mt-2 px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center gap-2"
                  >
                    <span>View Emergency Shield</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="rounded-2xl bg-white border border-red-200 p-6 shadow-sm flex flex-col items-center justify-center text-center space-y-3">
                  <div className="w-24 h-24 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg ring-4 ring-red-200">
                    <ShieldAlert className="w-12 h-12" />
                  </div>
                  <p className="font-bold text-sm text-charcoal-900">One-Touch Emergency Assistance</p>
                  <p className="text-xs text-charcoal-500 max-w-xs">
                    Dispatches high-priority SMS, automated calls, and location coordinates to designated contacts.
                  </p>
                </div>
              </div>
            )}

            {activeFeatureTab === 'family' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-lavender-100 text-lavender-700 text-xs font-bold">
                    <Users className="w-4 h-4" />
                    <span>Cross-Generational Care</span>
                  </div>
                  <h3 className="text-2xl font-display font-extrabold text-charcoal-900">
                    Connect Family, Caregivers & Doctors
                  </h3>
                  <p className="text-xs sm:text-sm text-charcoal-600 leading-relaxed">
                    Whether living in the next room or across oceans, family members can monitor dose adherence, view blood pressure trends, schedule doctor visits, and coordinate daily tasks with assigned caregivers.
                  </p>
                  <button
                    onClick={() => onExploreDemo('family')}
                    className="mt-2 px-5 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-2"
                  >
                    <span>Test Family Portal</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="rounded-2xl bg-white border border-cream-300 p-4 shadow-sm space-y-2 text-xs">
                  <div className="p-3 rounded-xl bg-cream-50 flex items-center justify-between">
                    <div>
                      <p className="font-bold text-charcoal-900">Priya Sharma (Daughter)</p>
                      <p className="text-[10px] text-charcoal-500">Primary Guardian • Bengaluru</p>
                    </div>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                      Active
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-cream-50 flex items-center justify-between">
                    <div>
                      <p className="font-bold text-charcoal-900">Sister Anjali (Care Nurse)</p>
                      <p className="text-[10px] text-charcoal-500">Assigned Nurse • Hyderabad</p>
                    </div>
                    <span className="text-[10px] font-bold text-teal-800 bg-teal-100 px-2 py-0.5 rounded-full">
                      Active
                    </span>
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>
      </section>

      {/* ========================================== */}
      {/* 5. HOW IT WORKS SECTION */}
      {/* ========================================== */}
      <section id="how-it-works" className="py-16 bg-cream-50 border-t border-cream-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs bg-sage-200 text-sage-900 font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">
              Simple 3-Step Setup
            </span>
            <h2 className="text-3xl font-display font-black text-charcoal-900">
              How MyCare AI Works For You
            </h2>
            <p className="text-sm text-charcoal-600">
              Designed for non-tech-savvy seniors and busy family members alike.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Step 1 */}
            <div className="p-6 rounded-3xl bg-white border border-cream-300 shadow-card text-center space-y-3 relative">
              <div className="w-12 h-12 rounded-2xl bg-teal-850 text-white font-display font-black text-lg flex items-center justify-center mx-auto shadow-sm">
                1
              </div>
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Create Account & Add Family
              </h3>
              <p className="text-xs text-charcoal-600 leading-relaxed">
                Add senior member profile, health conditions, daily medication schedule, and connect emergency family contacts in under 3 minutes.
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-6 rounded-3xl bg-white border border-cream-300 shadow-card text-center space-y-3 relative">
              <div className="w-12 h-12 rounded-2xl bg-peach-500 text-white font-display font-black text-lg flex items-center justify-center mx-auto shadow-sm">
                2
              </div>
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Receive Voice & Visual Reminders
              </h3>
              <p className="text-xs text-charcoal-600 leading-relaxed">
                Seniors receive gentle reminders in their preferred language (English, Telugu, Hindi). Tap 'Mark Taken' to record with celebration confetti.
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-6 rounded-3xl bg-white border border-cream-300 shadow-card text-center space-y-3 relative">
              <div className="w-12 h-12 rounded-2xl bg-mustard-500 text-white font-display font-black text-lg flex items-center justify-center mx-auto shadow-sm">
                3
              </div>
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Enjoy Complete Peace of Mind
              </h3>
              <p className="text-xs text-charcoal-600 leading-relaxed">
                Families get live updates, order pharmacy refills with verified prescriptions, and rest assured with always-armed emergency SOS safety.
              </p>
            </div>

          </div>
        </div>
      </section>

      {/* ========================================== */}
      {/* 6. FREQUENTLY ASKED QUESTIONS */}
      {/* ========================================== */}
      <section id="faq" className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          
          <div className="text-center space-y-2">
            <span className="text-xs bg-teal-100 text-teal-850 font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">
              Got Questions?
            </span>
            <h2 className="text-3xl font-display font-black text-charcoal-900">
              Frequently Asked Questions
            </h2>
            <p className="text-sm text-charcoal-600">
              Clear answers to help you get the best experience from MyCare AI.
            </p>
          </div>

          <div className="space-y-3">
            {[
              {
                q: "Is MyCare AI suitable for seniors who are not comfortable with technology?",
                a: "Yes! MyCare AI was specifically designed with elderly accessibility in mind: extra-large buttons, high contrast colors, simple navigation, and voice interaction in English, Telugu (తెలుగు), and Hindi (हिन्दी) so seniors can easily talk to AI Guardian."
              },
              {
                q: "Can I explore and test all features without creating an account?",
                a: "Absolutely. Click 'Explore Demo' on any page to immediately experience MyCare AI in Demo Guest Mode. You can test medicine scheduling, the 500+ pharmacy catalogue, packaging scanner, and appointment booking with simulated demo data."
              },
              {
                q: "How does the 500+ Medicine Catalogue and generic savings work?",
                a: "Our catalogue covers major therapeutic categories based on verified formulations in India. For branded medications, MyCare AI displays verified generic equivalents with up to 75-80% cost savings for elderly patients on fixed pensions, with clear safety advice."
              },
              {
                q: "How does the Emergency SOS button work?",
                a: "When pressed, the Emergency SOS button immediately dispatches high-priority alerts with real-time GPS coordinates to all configured emergency family contacts, while presenting 1-click speed dials for 112 (National Emergency) and 108 (Ambulance)."
              },
              {
                q: "Is my personal healthcare data kept private and secure?",
                a: "Yes. Every registered user's health records, prescriptions, and contacts are strictly partitioned in their own private database account. One user's data is never visible to or accessible by any other user."
              }
            ].map((faq, index) => (
              <div
                key={index}
                className="rounded-2xl border border-cream-300 bg-cream-50/70 overflow-hidden transition-all"
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full p-4 sm:p-5 text-left font-bold text-sm text-charcoal-900 flex items-center justify-between gap-4"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-teal-700 transition-transform ${
                      openFaqIndex === index ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {openFaqIndex === index && (
                  <div className="px-4 pb-4 sm:px-5 sm:pb-5 text-xs sm:text-sm text-charcoal-600 leading-relaxed border-t border-cream-200 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================== */}
      {/* 7. BOTTOM CALL TO ACTION BANNER */}
      {/* ========================================== */}
      <section className="py-16 bg-gradient-to-r from-teal-850 via-teal-700 to-teal-850 text-white relative overflow-hidden">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6 relative z-10">
          <span className="text-xs bg-mustard-300/20 text-mustard-300 font-extrabold px-3 py-1 rounded-full uppercase tracking-wider inline-block">
            Start Your Family Health Journey Today
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-black leading-tight">
            Give Your Loved Ones The Gift of Connected Care
          </h2>
          <p className="text-sm sm:text-base text-cream-200 max-w-2xl mx-auto leading-relaxed">
            Join thousands of caring families who trust MyCare AI for medication adherence, doctor appointments, and round-the-clock emergency peace of mind.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              onClick={onGetStarted}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-peach-500 hover:bg-peach-600 text-white font-display font-bold text-sm shadow-xl transition-all transform active:scale-95"
            >
              Create Free Account
            </button>
            <button
              onClick={() => onExploreDemo('elderly')}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-white/10 hover:bg-white/20 text-white border border-white/20 font-display font-bold text-sm backdrop-blur-sm transition-all"
            >
              Explore Live Demo
            </button>
          </div>
        </div>
      </section>

      {/* ========================================== */}
      {/* 8. PROFESSIONAL FOOTER */}
      {/* ========================================== */}
      <footer className="bg-charcoal-900 text-cream-100/90 pt-12 pb-8 border-t border-charcoal-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            
            {/* Col 1: Brand Info */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-white p-1.5 flex items-center justify-center">
                  <img src="/logo.svg" alt="MyCare AI" className="w-full h-full object-contain" />
                </div>
                <div>
                  <span className="font-display font-black text-xl text-white">
                    MyCare <span className="text-peach-400">AI</span>
                  </span>
                  <p className="text-[11px] text-cream-300">Your Health. Your Care. Your Family.</p>
                </div>
              </div>
              <p className="text-xs text-cream-300/80 leading-relaxed max-w-sm">
                MyCare AI is a comprehensive elderly healthcare ecosystem designed to connect seniors, family members, caregivers, and medical professionals through intelligent care coordination.
              </p>
              <div className="text-xs text-sage-300 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>System Operational • 24/7 Monitoring Active</span>
              </div>
            </div>

            {/* Col 2: Platform Links */}
            <div className="space-y-3 text-xs">
              <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider">Platform</h4>
              <ul className="space-y-2 text-cream-300/80">
                <li><button onClick={() => onExploreDemo('elderly')} className="hover:text-white transition-colors">Medicine Tracker</button></li>
                <li><button onClick={() => onExploreDemo('elderly')} className="hover:text-white transition-colors">500+ Pharmacy Catalogue</button></li>
                <li><button onClick={() => onExploreDemo('elderly')} className="hover:text-white transition-colors">AI Medicine Photo Scanner</button></li>
                <li><button onClick={() => onExploreDemo('elderly')} className="hover:text-white transition-colors">AI Guardian Voice</button></li>
                <li><button onClick={() => onExploreDemo('elderly')} className="hover:text-white transition-colors">Doctor Appointments</button></li>
                <li><button onClick={() => onExploreDemo('elderly')} className="hover:text-white transition-colors">Emergency SOS Shield</button></li>
              </ul>
            </div>

            {/* Col 3: Personas */}
            <div className="space-y-3 text-xs">
              <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider">Role Portals</h4>
              <ul className="space-y-2 text-cream-300/80">
                <li><button onClick={() => onExploreDemo('elderly')} className="hover:text-white transition-colors">Senior Member Portal</button></li>
                <li><button onClick={() => onExploreDemo('family')} className="hover:text-white transition-colors">Family Guardian View</button></li>
                <li><button onClick={() => onExploreDemo('caregiver')} className="hover:text-white transition-colors">Healthcare Nurse View</button></li>
                <li><button onClick={() => onExploreDemo('admin')} className="hover:text-white transition-colors">Doctor / Admin Console</button></li>
                <li><button onClick={onGetStarted} className="hover:text-white transition-colors text-peach-300 font-bold">Register New Account</button></li>
              </ul>
            </div>

            {/* Col 4: Contact & Support */}
            <div className="space-y-3 text-xs">
              <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider">Contact & Support</h4>
              <div className="space-y-2 text-cream-300/80">
                <p className="flex items-start gap-2">
                  <MapPin className="w-3.5 h-3.5 text-peach-400 shrink-0 mt-0.5" />
                  <span>Road No. 12, Banjara Hills, Hyderabad, Telangana, India</span>
                </p>
                <p className="flex items-center gap-2">
                  <PhoneCall className="w-3.5 h-3.5 text-peach-400 shrink-0" />
                  <span>+91 40 4000 8899</span>
                </p>
                <p className="flex items-center gap-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-mustard-300 shrink-0" />
                  <span>National Emergency: 112 / 108</span>
                </p>
              </div>
            </div>

          </div>

          {/* Legal Bar & Modals */}
          <div className="pt-6 border-t border-charcoal-700/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-cream-300/70">
            <p>© 2026 MyCare AI Inc. All rights reserved.</p>
            
            <div className="flex items-center gap-6">
              <button
                onClick={() => setActiveModal('about')}
                className="hover:text-white underline transition-colors"
              >
                About MyCare AI
              </button>
              <button
                onClick={() => setActiveModal('privacy')}
                className="hover:text-white underline transition-colors"
              >
                Privacy Policy
              </button>
              <button
                onClick={() => setActiveModal('terms')}
                className="hover:text-white underline transition-colors"
              >
                Terms of Service
              </button>
            </div>
          </div>

          <p className="text-[10px] text-charcoal-500 text-center leading-relaxed">
            Medical Disclaimer: MyCare AI assists elderly patients and caregivers in managing medication routines and appointments. It does not provide medical diagnoses or replace consultations with licensed physicians. Schedule H medicines require verified prescription review.
          </p>

        </div>
      </footer>

      {/* ========================================== */}
      {/* 9. MODALS: ABOUT, PRIVACY, TERMS */}
      {/* ========================================== */}
      {activeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/70 backdrop-blur-sm animate-in fade-in">
          <div className="max-w-2xl w-full bg-white rounded-3xl p-6 sm:p-8 border border-cream-300 shadow-modal max-h-[85vh] overflow-y-auto space-y-4 text-charcoal-800 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-cream-200">
              <h3 className="font-display font-bold text-lg text-charcoal-900">
                {activeModal === 'about' && 'About MyCare AI'}
                {activeModal === 'privacy' && 'Privacy Policy & Patient Data Security'}
                {activeModal === 'terms' && 'Terms of Service & Usage Guidelines'}
              </h3>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-xl text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {activeModal === 'about' && (
              <div className="space-y-3 leading-relaxed">
                <p>
                  <strong>MyCare AI</strong> was founded with a singular purpose: to ensure every elderly parent experiences the highest quality of healthcare, dignity, and family closeness regardless of physical distance.
                </p>
                <p>
                  Our platform combines intelligent daily medication adherence, a comprehensive catalogue of 500+ Indian medications, packaging OCR vision analysis, multilingual voice guidance, and instant GPS emergency safety.
                </p>
                <p>
                  Built by senior healthcare architects, product designers, and AI engineers in Hyderabad, MyCare AI connects generations across India and the globe.
                </p>
              </div>
            )}

            {activeModal === 'privacy' && (
              <div className="space-y-3 leading-relaxed">
                <p>
                  <strong>Patient Data Confidentiality:</strong> Your health records, vitals, prescriptions, and contacts are strictly encrypted and partitioned under your authenticated account.
                </p>
                <p>
                  <strong>Zero Data Cross-Contamination:</strong> One user's medical information is never accessible to or shared with another user. Family members and caregivers can only view records explicitly authorized by the patient.
                </p>
                <p>
                  <strong>Emergency Location Services:</strong> GPS location coordinates are captured strictly upon emergency SOS activation with your consent to assist rapid ambulance and family dispatch.
                </p>
              </div>
            )}

            {activeModal === 'terms' && (
              <div className="space-y-3 leading-relaxed">
                <p>
                  <strong>Clinical Usage:</strong> MyCare AI is a care coordination platform. It does not replace professional emergency medical services, clinical diagnosis, or hospital triage.
                </p>
                <p>
                  <strong>Prescriptions:</strong> Schedule H medications ordered through MyCare AI pharmacy require upload and review of a valid prescription issued by a registered medical practitioner.
                </p>
                <p>
                  <strong>Service Availability:</strong> While we maintain continuous uptime and offline local backups, in critical emergencies always dial 112 or 108 directly.
                </p>
              </div>
            )}

            <div className="pt-3 border-t border-cream-200 text-right">
              <button
                onClick={() => setActiveModal(null)}
                className="px-5 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold"
              >
                Close Window
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};