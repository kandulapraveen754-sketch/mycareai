// ==========================================
// MYCARE AI - COMPLETE MEDICATION MANAGEMENT PAGE
// Add/Edit, Morning/Afternoon/Evening/Night tabs,
// Stock counts, Adherence & Refill alerts
// ==========================================

import React, { useState } from 'react';
import {
  Pill,
  Plus,
  Clock,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Filter,
  Trash2,
  Edit3,
  Check,
  ShieldCheck,
  Camera,
  X,
  AlertTriangle
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Medicine, ScheduledDose } from '../types';
import { triggerConfetti } from '../utils/confetti';

export const MedicinesPage: React.FC = () => {
  const {
    medicines,
    todayDoses,
    markDoseTaken,
    skipDose,
    addMedicine,
    deleteMedicine,
    openScanner,
    isElderlyMode,
    t
  } = useApp();

  const [activeSlotFilter, setActiveSlotFilter] = useState<'All' | 'Morning' | 'Afternoon' | 'Evening' | 'Night'>('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [skipModalDose, setSkipModalDose] = useState<ScheduledDose | null>(null);
  const [skipReason, setSkipReason] = useState('Nausea / Stomach discomfort');

  // New Medicine Form State
  const [formData, setFormData] = useState({
    name: '',
    brand: '',
    strength: '',
    dosageForm: 'Tablet',
    frequency: 'Once daily morning',
    scheduleTimes: ['Morning'] as ('Morning' | 'Afternoon' | 'Evening' | 'Night')[],
    exactTimes: ['08:00 AM'],
    dosage: '1 tablet',
    instructions: 'Take after food with water.',
    prescribedBy: 'Dr. Vikram Patel',
    category: 'General',
    remainingPills: 30,
    isPrescriptionRequired: true
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    addMedicine({
      name: formData.name,
      brand: formData.brand || formData.name,
      strength: formData.strength || '500 mg',
      dosageForm: formData.dosageForm,
      frequency: formData.frequency,
      scheduleTimes: formData.scheduleTimes,
      exactTimes: formData.exactTimes,
      dosage: formData.dosage,
      instructions: formData.instructions,
      prescribedBy: formData.prescribedBy,
      category: formData.category,
      remainingPills: Number(formData.remainingPills),
      isPrescriptionRequired: formData.isPrescriptionRequired
    });

    setShowAddModal(false);
    triggerConfetti(2500);

    // Reset form
    setFormData({
      name: '',
      brand: '',
      strength: '',
      dosageForm: 'Tablet',
      frequency: 'Once daily morning',
      scheduleTimes: ['Morning'],
      exactTimes: ['08:00 AM'],
      dosage: '1 tablet',
      instructions: 'Take after food with water.',
      prescribedBy: 'Dr. Vikram Patel',
      category: 'General',
      remainingPills: 30,
      isPrescriptionRequired: true
    });
  };

  const filteredDoses = todayDoses.filter(dose => {
    if (activeSlotFilter === 'All') return true;
    return dose.timeSlot === activeSlotFilter;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Page Title & Action Bar */}
      <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-display font-extrabold text-charcoal-900">
              {t.medicines} & Daily Schedule
            </h1>
            <span className="text-xs bg-sage-100 text-teal-850 font-bold px-2.5 py-0.5 rounded-full border border-sage-300">
              {medicines.length} Prescriptions Active
            </span>
          </div>
          <p className="text-xs text-charcoal-500 mt-1">
            Track daily doses, schedule times, pill inventory, and refill requirements
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={openScanner}
            className="px-4 py-2.5 rounded-xl bg-mustard-300 hover:bg-mustard-200 text-charcoal-900 font-display font-bold text-xs flex items-center gap-2 shadow-sm transition-all"
          >
            <Camera className="w-4 h-4 text-teal-850" />
            <span>Scan Packaging</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Medicine</span>
          </button>
        </div>
      </div>

      {/* Daily Schedule Slot Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {(['All', 'Morning', 'Afternoon', 'Evening', 'Night'] as const).map((slot) => (
          <button
            key={slot}
            onClick={() => setActiveSlotFilter(slot)}
            className={`px-4 py-2 rounded-2xl font-bold text-xs transition-all whitespace-nowrap ${
              activeSlotFilter === slot
                ? 'bg-teal-850 text-cream-50 shadow-md ring-2 ring-teal-700/30'
                : 'bg-white border border-cream-300 text-charcoal-700 hover:bg-cream-100'
            }`}
          >
            {slot === 'All' ? 'All Daily Doses' : `${slot} Routine`}
          </button>
        ))}
      </div>

      {/* Doses Grid */}
      <div className="space-y-3">
        <h2 className="text-sm font-bold text-charcoal-700 uppercase tracking-wider">
          Scheduled Doses for Today:
        </h2>

        {filteredDoses.map((dose) => (
          <div
            key={dose.id}
            className={`p-5 rounded-3xl border transition-all ${
              dose.status === 'taken'
                ? 'bg-white border-emerald-300/80 shadow-sm'
                : dose.status === 'pending'
                ? 'bg-cream-50 border-cream-300 hover:border-teal-700/50 shadow-card'
                : 'bg-cream-100/50 border-cream-300 opacity-75'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <div
                  className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-sm"
                  style={{ backgroundColor: dose.colorTag || '#DDE8D7' }}
                >
                  <Pill className="w-6 h-6 text-charcoal-900" />
                </div>

                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className={`font-bold text-charcoal-900 ${isElderlyMode ? 'text-lg' : 'text-base'}`}>
                      {dose.medicineName}
                    </h3>
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-cream-200 text-charcoal-700">
                      {dose.strength} • {dose.dosage}
                    </span>
                    <span className="text-xs font-bold text-teal-850 bg-teal-50 px-2 py-0.5 rounded-full">
                      {dose.timeSlot}
                    </span>
                  </div>

                  <p className="text-xs text-charcoal-600 mt-1">{dose.instructions}</p>

                  <div className="flex items-center gap-3 mt-2 text-xs text-charcoal-500">
                    <span className="flex items-center gap-1 font-bold text-teal-850">
                      <Clock className="w-3.5 h-3.5 text-teal-700" />
                      <span>{dose.scheduledTime}</span>
                    </span>
                    {dose.takenAt && (
                      <span className="text-emerald-700 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Confirmed at {dose.takenAt}</span>
                      </span>
                    )}
                    {dose.skippedReason && (
                      <span className="text-charcoal-600 italic">
                        Skipped: {dose.skippedReason}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 self-end sm:self-center">
                {dose.status === 'taken' ? (
                  <span className="px-4 py-2 rounded-xl bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center gap-1.5 border border-emerald-300">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Dose Taken</span>
                  </span>
                ) : dose.status === 'pending' ? (
                  <>
                    <button
                      onClick={() => markDoseTaken(dose.id)}
                      className="px-5 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-md transition-all hover:scale-105"
                    >
                      <Check className="w-4 h-4" />
                      <span>{t.markAsTaken}</span>
                    </button>
                    <button
                      onClick={() => setSkipModalDose(dose)}
                      className="px-3.5 py-2.5 rounded-xl bg-cream-200 hover:bg-cream-300 text-charcoal-700 font-semibold text-xs"
                    >
                      <span>Skip</span>
                    </button>
                  </>
                ) : (
                  <span className="px-3 py-1.5 rounded-xl bg-charcoal-200 text-charcoal-700 font-bold text-xs">
                    {dose.status.toUpperCase()}
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Active Prescription Cards & Inventory */}
      <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-cream-200">
          <div>
            <h2 className="text-lg font-display font-bold text-charcoal-900">
              Active Prescriptions & Stock Inventory
            </h2>
            <p className="text-xs text-charcoal-500">
              Full list of prescribed medications, doctor orders, and refill levels
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {medicines.map((med) => (
            <div
              key={med.id}
              className="p-4 rounded-2xl border border-cream-300 bg-cream-50/60 hover:bg-cream-50 hover:shadow-card-hover transition-all flex flex-col justify-between space-y-3"
            >
              <div className="flex items-start gap-3">
                <img
                  src={med.image}
                  alt={med.name}
                  className="w-14 h-14 rounded-2xl object-cover ring-1 ring-cream-300 shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-charcoal-900 truncate">{med.name}</h3>
                    <button
                      onClick={() => deleteMedicine(med.id)}
                      className="text-charcoal-400 hover:text-red-600 transition-colors p-1"
                      title="Remove medicine"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-xs text-teal-850 font-semibold">{med.brand} • {med.strength}</p>
                  <p className="text-[11px] text-charcoal-500 mt-0.5">{med.frequency}</p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-white border border-cream-200 text-xs space-y-1">
                <p className="text-charcoal-600 font-medium">
                  <span className="text-charcoal-400">Prescribed by:</span> {med.prescribedBy}
                </p>
                <div className="flex items-center justify-between pt-1 border-t border-cream-100">
                  <span className="text-charcoal-500">Pills Remaining:</span>
                  <span
                    className={`font-bold ${
                      med.remainingPills <= med.refillThreshold
                        ? 'text-red-600 font-extrabold flex items-center gap-1'
                        : 'text-charcoal-800'
                    }`}
                  >
                    {med.remainingPills <= med.refillThreshold && <AlertTriangle className="w-3 h-3 text-red-500" />}
                    {med.remainingPills} pills {med.remainingPills <= med.refillThreshold ? '(Refill Now)' : ''}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Medicine Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-cream-300 max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-cream-200">
              <div className="flex items-center gap-2">
                <Pill className="w-5 h-5 text-teal-700" />
                <h3 className="font-display font-bold text-lg text-charcoal-900">
                  Add New Medication
                </h3>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-full text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">
                    Medicine Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Telmisartan"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">
                    Brand Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Telmikind 40"
                    value={formData.brand}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">
                    Dosage Strength
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 40 mg"
                    value={formData.strength}
                    onChange={(e) => setFormData({ ...formData, strength: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">
                    Dosage Form
                  </label>
                  <select
                    value={formData.dosageForm}
                    onChange={(e) => setFormData({ ...formData, dosageForm: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
                  >
                    <option value="Tablet">Tablet</option>
                    <option value="Capsule">Capsule</option>
                    <option value="Syrup">Syrup</option>
                    <option value="Injection">Injection</option>
                    <option value="Drops">Eye/Ear Drops</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">
                    Time Slot
                  </label>
                  <select
                    value={formData.scheduleTimes[0]}
                    onChange={(e) => {
                      const slot = e.target.value as any;
                      const defaultTimes: Record<string, string> = {
                        Morning: '08:00 AM',
                        Afternoon: '01:30 PM',
                        Evening: '05:30 PM',
                        Night: '09:00 PM'
                      };
                      setFormData({
                        ...formData,
                        scheduleTimes: [slot],
                        exactTimes: [defaultTimes[slot] || '08:00 AM']
                      });
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  >
                    <option value="Morning">Morning</option>
                    <option value="Afternoon">Afternoon</option>
                    <option value="Evening">Evening</option>
                    <option value="Night">Night</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">
                    Scheduled Time
                  </label>
                  <input
                    type="text"
                    value={formData.exactTimes[0]}
                    onChange={(e) => setFormData({ ...formData, exactTimes: [e.target.value] })}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">
                  Instructions for Patient
                </label>
                <input
                  type="text"
                  placeholder="e.g. Take after breakfast with warm water"
                  value={formData.instructions}
                  onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">
                    Prescribed By
                  </label>
                  <input
                    type="text"
                    value={formData.prescribedBy}
                    onChange={(e) => setFormData({ ...formData, prescribedBy: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">
                    Remaining Pills
                  </label>
                  <input
                    type="number"
                    value={formData.remainingPills}
                    onChange={(e) => setFormData({ ...formData, remainingPills: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  />
                </div>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs shadow-md transition-colors"
                >
                  Save Medication
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-5 py-3 rounded-xl bg-cream-200 text-charcoal-700 font-semibold text-xs"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Skip Dose Modal */}
      {skipModalDose && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-cream-300 space-y-4">
            <h3 className="font-display font-bold text-base text-charcoal-900">
              Skip Dose: {skipModalDose.medicineName}
            </h3>
            <p className="text-xs text-charcoal-600">
              Record clinical reason for skipping this dose. Caregivers and daughter Priya will be notified.
            </p>
            <div className="space-y-2">
              {[
                "Nausea / Stomach discomfort",
                "Fast or empty stomach required",
                "Doctor advised temporary pause",
                "Forgot / delayed past window"
              ].map((r) => (
                <label key={r} className="flex items-center gap-2 text-xs">
                  <input
                    type="radio"
                    name="skipReason"
                    checked={skipReason === r}
                    onChange={() => setSkipReason(r)}
                  />
                  <span>{r}</span>
                </label>
              ))}
            </div>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => {
                  skipDose(skipModalDose.id, skipReason);
                  setSkipModalDose(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-peach-500 hover:bg-peach-600 text-white font-bold text-xs"
              >
                Confirm Skip
              </button>
              <button
                onClick={() => setSkipModalDose(null)}
                className="px-4 py-2.5 rounded-xl bg-cream-200 text-charcoal-700 font-semibold text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
