// =========================================================================
// MYCARE AI — COMPLETE MEDICINE CATALOGUE (APOLLO & PHARMEASY GRADE)
// Full-scale pharmacy catalogue, salt search, generic alternatives,
// multi-filters, sorting, CSV import/export, and prescription checkout.
// =========================================================================

import React, { useState, useMemo } from 'react';
import {
  ShoppingBag,
  Search,
  Filter,
  Camera,
  Plus,
  Minus,
  Trash2,
  CheckCircle2,
  Clock,
  Truck,
  Package,
  FileText,
  Upload,
  ShieldCheck,
  ChevronRight,
  X,
  CreditCard,
  MapPin,
  Sparkles,
  AlertCircle,
  Star,
  ArrowUpDown,
  Download,
  FileSpreadsheet,
  RefreshCw,
  Info,
  Check,
  TrendingDown,
  Layers,
  HelpCircle,
  Eye
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { MedicineCatalogueItem, Order, OrderStatus, MedicineCategory } from '../types';
import { medicineCategoriesList, topPharmaBrandsList } from '../data/medicineCatalogueExpanded';
import { triggerConfetti } from '../utils/confetti';

export const PharmacyPage: React.FC = () => {
  const {
    catalogue,
    addCatalogueItem,
    importCatalogueCSV,
    resetCatalogue,
    cart,
    cartTotal,
    addToCart,
    removeFromCart,
    updateCartQuantity,
    placeOrder,
    orders,
    openScanner,
    searchQuery,
    setSearchQuery,
    isElderlyMode,
    t
  } = useApp();

  // Navigation tabs
  const [activeTab, setActiveTab] = useState<'catalogue' | 'orders'>('catalogue');

  // Search & Filtering State
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedBrand, setSelectedBrand] = useState<string>('All Brands');
  const [prescriptionFilter, setPrescriptionFilter] = useState<'all' | 'rx' | 'otc'>('all');
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [priceRange, setPriceRange] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'relevance' | 'price-asc' | 'price-desc' | 'rating' | 'name'>('relevance');

  // Modal states
  const [selectedProduct, setSelectedProduct] = useState<MedicineCatalogueItem | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState<boolean>(false);
  const [isAddProductModalOpen, setIsAddProductModalOpen] = useState<boolean>(false);

  // CSV Import State
  const [csvInput, setCsvInput] = useState<string>('');
  const [importNotice, setImportNotice] = useState<string | null>(null);

  // New Product Manual Form State
  const [newProdName, setNewProdName] = useState('');
  const [newProdBrand, setNewProdBrand] = useState('');
  const [newProdStrength, setNewProdStrength] = useState('');
  const [newProdSalt, setNewProdSalt] = useState('');
  const [newProdCat, setNewProdCat] = useState<MedicineCategory>('General Healthcare');
  const [newProdPrice, setNewProdPrice] = useState(120);
  const [newProdIsRx, setNewProdIsRx] = useState(true);

  // Checkout State
  const [deliveryAddress, setDeliveryAddress] = useState(
    "Flat 402, Sai Nilayam, Road No. 12, Banjara Hills, Hyderabad - 500034"
  );
  const [paymentMethod, setPaymentMethod] = useState("Cash on Delivery (Senior Pay)");
  const [prescriptionUploaded, setPrescriptionUploaded] = useState(true);

  // Sample CSV Template for 1-Click Import
  const sampleCSVTemplate = `name,brand,strength,salt,category,price,isRx
Amlong 10 Tablet,Micro Labs,10 mg,Amlodipine (10mg),Blood Pressure,85.00,true
Januvia 100mg Tablet,MSD India,100 mg,Sitagliptin (100mg),Diabetes Care,1450.00,true
Jan Aushadhi Sitagliptin,PMBJP Generic,100 mg,Sitagliptin (100mg),Diabetes Care,190.00,true
Cetirizine 10mg,Cipla,10 mg,Cetirizine Hydrochloride (10mg),Cold & Cough,35.00,false
Hot Water Bag Deluxe,Flamingo,Standard,Rubber heating bag,Senior Care & Devices,240.00,false`;

  // Advanced Multi-Attribute Search & Filter Pipeline
  const filteredAndSortedCatalogue = useMemo(() => {
    return catalogue
      .filter((item) => {
        // 1. Text Search across 5 fields
        const query = searchQuery.trim().toLowerCase();
        const matchesSearch =
          !query ||
          item.name.toLowerCase().includes(query) ||
          item.brand.toLowerCase().includes(query) ||
          item.activeIngredients.toLowerCase().includes(query) ||
          item.manufacturer.toLowerCase().includes(query) ||
          item.strength.toLowerCase().includes(query) ||
          item.category.toLowerCase().includes(query);

        // 2. Category Filter
        const matchesCategory =
          selectedCategory === 'All' || item.category === selectedCategory;

        // 3. Brand Filter
        const matchesBrand =
          selectedBrand === 'All Brands' ||
          item.brand.toLowerCase().includes(selectedBrand.toLowerCase()) ||
          item.manufacturer.toLowerCase().includes(selectedBrand.toLowerCase());

        // 4. Prescription Filter
        const matchesRx =
          prescriptionFilter === 'all'
            ? true
            : prescriptionFilter === 'rx'
            ? item.prescriptionRequired
            : !item.prescriptionRequired;

        // 5. In-Stock Filter
        const matchesStock = !inStockOnly || (item.inStock && item.stockCount > 0);

        // 6. Price Range
        const currentPrice = item.discountPrice || item.price;
        let matchesPrice = true;
        if (priceRange === 'under-50') matchesPrice = currentPrice < 50;
        else if (priceRange === '50-200') matchesPrice = currentPrice >= 50 && currentPrice <= 200;
        else if (priceRange === '200-500') matchesPrice = currentPrice > 200 && currentPrice <= 500;
        else if (priceRange === 'above-500') matchesPrice = currentPrice > 500;

        return matchesSearch && matchesCategory && matchesBrand && matchesRx && matchesStock && matchesPrice;
      })
      .sort((a, b) => {
        const priceA = a.discountPrice || a.price;
        const priceB = b.discountPrice || b.price;

        switch (sortBy) {
          case 'price-asc':
            return priceA - priceB;
          case 'price-desc':
            return priceB - priceA;
          case 'rating':
            return (b.rating || 0) - (a.rating || 0);
          case 'name':
            return a.name.localeCompare(b.name);
          case 'relevance':
          default:
            return 0;
        }
      });
  }, [
    catalogue,
    searchQuery,
    selectedCategory,
    selectedBrand,
    prescriptionFilter,
    inStockOnly,
    priceRange,
    sortBy
  ]);

  // Quick category counts for badges
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { All: catalogue.length };
    catalogue.forEach((item) => {
      counts[item.category] = (counts[item.category] || 0) + 1;
    });
    return counts;
  }, [catalogue]);

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    placeOrder({
      address: deliveryAddress,
      paymentMethod,
      prescriptionFile: prescriptionUploaded
        ? "https://mycare.ai/prescriptions/verified_dr_patel.pdf"
        : undefined
    });
    setIsCheckoutOpen(false);
    setIsCartOpen(false);
    setActiveTab('orders');
  };

  const handleImportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!csvInput.trim()) return;

    const count = importCatalogueCSV(csvInput);
    if (count > 0) {
      setImportNotice(`Successfully imported ${count} verified medications into catalogue!`);
      setTimeout(() => {
        setImportNotice(null);
        setIsImportModalOpen(false);
        setCsvInput('');
      }, 2000);
      triggerConfetti(2000);
    } else {
      setImportNotice("Invalid CSV format. Please verify columns.");
    }
  };

  const handleAddSingleProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim()) return;

    addCatalogueItem({
      name: newProdName,
      brand: newProdBrand || newProdName,
      strength: newProdStrength || "500 mg",
      activeIngredients: newProdSalt || newProdName,
      category: newProdCat,
      price: Number(newProdPrice),
      prescriptionRequired: newProdIsRx
    });

    setIsAddProductModalOpen(false);
    setNewProdName('');
    setNewProdBrand('');
    setNewProdStrength('');
    setNewProdSalt('');
    triggerConfetti(2000);
  };

  const handleExportCSV = () => {
    const headers = "id,name,brand,strength,salt,dosageForm,packSize,manufacturer,category,price,discountPrice,isPrescriptionRequired,stock\n";
    const rows = catalogue
      .map(
        (m) =>
          `"${m.id}","${m.name}","${m.brand}","${m.strength}","${m.activeIngredients}","${m.dosageForm}","${m.packSize}","${m.manufacturer}","${m.category}",${m.price},${m.discountPrice || m.price},${m.prescriptionRequired},${m.stockCount}`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mycare_pharmacy_catalogue_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const getOrderStatusStep = (status: OrderStatus) => {
    const stages: OrderStatus[] = [
      'Confirmed',
      'Prescription Verification',
      'Packed',
      'Shipped',
      'Out for Delivery',
      'Delivered'
    ];
    return stages.indexOf(status);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* 1. Header Banner & Pharmacy Brand Identity */}
      <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <h1 className="text-2xl sm:text-3xl font-display font-extrabold text-charcoal-900">
              {t.medicineOrdering} & Senior Pharmacy
            </h1>
            <span className="text-xs bg-teal-850 text-white font-bold px-3 py-1 rounded-full shadow-sm">
              Apollo & PharmEasy Grade
            </span>
            <span className="text-xs bg-sage-100 text-teal-850 font-bold px-2.5 py-1 rounded-full border border-sage-300">
              {catalogue.length} Verified Products
            </span>
          </div>
          <p className="text-xs text-charcoal-500 mt-1 max-w-2xl">
            Browse genuine Indian prescription medicines, OTC drugs, generic substitutes with price savings, and senior healthcare devices with verified pharmacist review.
          </p>
        </div>

        {/* Action Buttons: Scan, Cart, CSV Import */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={openScanner}
            className="px-4 py-2.5 rounded-2xl bg-mustard-300 hover:bg-mustard-200 text-charcoal-900 font-display font-bold text-xs flex items-center gap-2 shadow-sm transition-all hover:scale-105"
          >
            <Camera className="w-4 h-4 text-teal-850" />
            <span>Scan Medicine Photo</span>
          </button>

          <button
            onClick={() => setIsImportModalOpen(true)}
            className="px-3.5 py-2.5 rounded-2xl bg-cream-100 hover:bg-cream-200 text-charcoal-800 font-bold text-xs flex items-center gap-1.5 border border-cream-300 shadow-sm transition-colors"
            title="Import / Manage Database via CSV"
          >
            <FileSpreadsheet className="w-4 h-4 text-teal-700" />
            <span>Import CSV</span>
          </button>

          <button
            onClick={() => setIsCartOpen(true)}
            className="relative px-5 py-2.5 rounded-2xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-2 shadow-md transition-all"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>View Cart ({cart.reduce((s, i) => s + i.quantity, 0)})</span>
            {cartTotal > 0 && (
              <span className="text-mustard-300 ml-1">₹{cartTotal.toFixed(0)}</span>
            )}
          </button>
        </div>
      </div>

      {/* 2. Top-level Tab Switcher: Catalogue vs My Orders */}
      <div className="flex items-center justify-between border-b border-cream-300 pb-2">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('catalogue')}
            className={`px-4 py-2 rounded-2xl font-bold text-sm transition-all ${
              activeTab === 'catalogue'
                ? 'bg-teal-850 text-cream-50 shadow-sm'
                : 'text-charcoal-600 hover:text-teal-850'
            }`}
          >
            All Medicines & Healthcare ({catalogue.length})
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2 rounded-2xl font-bold text-sm transition-all ${
              activeTab === 'orders'
                ? 'bg-teal-850 text-cream-50 shadow-sm'
                : 'text-charcoal-600 hover:text-teal-850'
            }`}
          >
            My Orders & Tracking ({orders.length})
          </button>
        </div>

        {activeTab === 'catalogue' && (
          <div className="hidden sm:flex items-center gap-2 text-xs">
            <button
              onClick={handleExportCSV}
              className="text-teal-850 hover:underline font-bold flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
            <span className="text-charcoal-300">•</span>
            <button
              onClick={() => setIsAddProductModalOpen(true)}
              className="text-peach-700 hover:underline font-bold flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Custom Medicine</span>
            </button>
          </div>
        )}
      </div>

      {activeTab === 'catalogue' ? (
        <div className="space-y-5">
          
          {/* 3. Search Bar, Category Horizontal Scroller, Filters, and Sorters */}
          <div className="rounded-3xl bg-white border border-cream-300 p-5 shadow-sm space-y-4">
            
            {/* Primary Search Bar */}
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-charcoal-400" />
              <input
                type="text"
                placeholder="Search by medicine name, brand (e.g. Telmikind, Dolo, Glycomet), salt composition (e.g. Metformin, Telmisartan, Paracetamol), or manufacturer..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-10 py-3.5 rounded-2xl bg-cream-50 border border-cream-300 text-charcoal-800 placeholder-charcoal-400 text-sm focus:ring-2 focus:ring-teal-700 focus:outline-none shadow-inner"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1 text-charcoal-400 hover:text-charcoal-700"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Horizontal Category Scroller with Badges */}
            <div>
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
                {medicineCategoriesList.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-4 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all flex items-center gap-1.5 ${
                      selectedCategory === cat
                        ? 'bg-teal-850 text-cream-50 shadow-md ring-2 ring-teal-700/30'
                        : 'bg-cream-100/80 text-charcoal-700 hover:bg-cream-200'
                    }`}
                  >
                    <span>{cat}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full font-semibold ${
                        selectedCategory === cat ? 'bg-white/20 text-cream-50' : 'bg-charcoal-200 text-charcoal-700'
                      }`}
                    >
                      {categoryCounts[cat] || 0}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Filter Toolbar: Brand, Prescription, Stock, Price, and Sorter */}
            <div className="pt-3 border-t border-cream-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
              
              {/* Manufacturer / Brand Filter */}
              <div>
                <label className="text-[11px] font-bold text-charcoal-500 uppercase block mb-1">
                  Manufacturer / Brand:
                </label>
                <select
                  value={selectedBrand}
                  onChange={(e) => setSelectedBrand(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-800 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
                >
                  {topPharmaBrandsList.map((b) => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </div>

              {/* Prescription (Rx vs OTC) Filter */}
              <div>
                <label className="text-[11px] font-bold text-charcoal-500 uppercase block mb-1">
                  Prescription Status:
                </label>
                <select
                  value={prescriptionFilter}
                  onChange={(e) => setPrescriptionFilter(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-800 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
                >
                  <option value="all">All Products (Rx + OTC)</option>
                  <option value="rx">Prescription Only (Rx Required)</option>
                  <option value="otc">Over-the-Counter (OTC Only)</option>
                </select>
              </div>

              {/* Price Range Filter */}
              <div>
                <label className="text-[11px] font-bold text-charcoal-500 uppercase block mb-1">
                  Price Filter:
                </label>
                <select
                  value={priceRange}
                  onChange={(e) => setPriceRange(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-800 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
                >
                  <option value="all">All Prices</option>
                  <option value="under-50">Under ₹50</option>
                  <option value="50-200">₹50 – ₹200</option>
                  <option value="200-500">₹200 – ₹500</option>
                  <option value="above-500">Above ₹500</option>
                </select>
              </div>

              {/* Sort By Dropdown */}
              <div>
                <label className="text-[11px] font-bold text-charcoal-500 uppercase block mb-1 flex items-center gap-1">
                  <ArrowUpDown className="w-3 h-3 text-teal-700" />
                  <span>Sort By:</span>
                </label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-cream-50 border border-cream-300 text-charcoal-800 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
                >
                  <option value="relevance">Featured & Relevant</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                  <option value="rating">Customer Rating</option>
                  <option value="name">Alphabetical (A - Z)</option>
                </select>
              </div>

              {/* Availability Toggle */}
              <div className="flex items-end">
                <label className="w-full flex items-center justify-between p-2 rounded-xl bg-cream-50 border border-cream-300 cursor-pointer h-[38px]">
                  <span className="font-bold text-charcoal-700">In Stock Only</span>
                  <input
                    type="checkbox"
                    checked={inStockOnly}
                    onChange={(e) => setInStockOnly(e.target.checked)}
                    className="w-4 h-4 text-teal-700 rounded focus:ring-teal-700"
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Results Summary Bar */}
          <div className="flex items-center justify-between text-xs text-charcoal-600 px-2">
            <span>
              Showing <strong>{filteredAndSortedCatalogue.length}</strong> matching medicines & healthcare items
            </span>
            {(selectedCategory !== 'All' || selectedBrand !== 'All Brands' || prescriptionFilter !== 'all' || priceRange !== 'all' || searchQuery) && (
              <button
                onClick={() => {
                  setSelectedCategory('All');
                  setSelectedBrand('All Brands');
                  setPrescriptionFilter('all');
                  setPriceRange('all');
                  setInStockOnly(false);
                  setSearchQuery('');
                }}
                className="text-peach-700 font-bold hover:underline"
              >
                Reset All Filters
              </button>
            )}
          </div>

          {/* 4. Apollo / PharmEasy Style Product Grid */}
          {filteredAndSortedCatalogue.length === 0 ? (
            <div className="p-12 rounded-3xl bg-white border border-cream-300 text-center space-y-3">
              <ShoppingBag className="w-12 h-12 text-charcoal-300 mx-auto" />
              <h3 className="font-display font-bold text-base text-charcoal-900">
                No matching medications found
              </h3>
              <p className="text-xs text-charcoal-500 max-w-md mx-auto">
                We could not find products matching "{searchQuery}". Try searching by generic salt composition or browsing by category.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                }}
                className="mt-2 px-5 py-2.5 rounded-xl bg-teal-850 text-white font-bold text-xs"
              >
                Browse All Medicines
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {filteredAndSortedCatalogue.map((item) => {
                const inCart = cart.find((c) => c.medicine.id === item.id);
                const savingsAmount = item.discountPrice ? item.price - item.discountPrice : 0;
                const savingsPercent = item.discountPrice ? Math.round((savingsAmount / item.price) * 100) : 0;

                return (
                  <div
                    key={item.id}
                    className="p-4 rounded-3xl border border-cream-300 bg-white hover:border-teal-700/50 hover:shadow-card-hover transition-all flex flex-col justify-between group"
                  >
                    <div>
                      {/* Product Image & Badges */}
                      <div
                        onClick={() => setSelectedProduct(item)}
                        className="relative w-full h-44 rounded-2xl overflow-hidden bg-cream-100 cursor-pointer mb-3.5"
                      >
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-300"
                        />

                        {/* Rx vs OTC Tag */}
                        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1">
                          {item.prescriptionRequired ? (
                            <span className="bg-peach-500 text-white text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-md shadow-sm">
                              Rx Required
                            </span>
                          ) : (
                            <span className="bg-emerald-600 text-white text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-md shadow-sm">
                              OTC Care
                            </span>
                          )}
                        </div>

                        {/* Savings Badge */}
                        {savingsPercent > 0 && (
                          <span className="absolute top-2.5 right-2.5 bg-mustard-300 text-charcoal-900 text-[10px] font-black px-2 py-0.5 rounded-md shadow-sm">
                            {savingsPercent}% OFF
                          </span>
                        )}

                        {/* Pack size pill */}
                        <span className="absolute bottom-2.5 right-2.5 bg-charcoal-900/80 backdrop-blur-sm text-white text-[10px] font-medium px-2 py-0.5 rounded-md">
                          {item.packSize || item.dosageForm}
                        </span>
                      </div>

                      {/* Title & Salt Info */}
                      <div onClick={() => setSelectedProduct(item)} className="cursor-pointer space-y-1">
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-[10px] font-bold text-teal-850 uppercase tracking-wider bg-teal-50 px-2 py-0.5 rounded-md">
                            {item.category}
                          </span>
                          {item.rating && (
                            <div className="flex items-center gap-1 text-[11px] font-bold text-mustard-600 bg-mustard-50 px-1.5 py-0.5 rounded">
                              <Star className="w-3 h-3 fill-mustard-500 text-mustard-500" />
                              <span>{item.rating}</span>
                            </div>
                          )}
                        </div>

                        <h3 className="font-bold text-sm text-charcoal-900 group-hover:text-teal-850 transition-colors line-clamp-1 mt-1">
                          {item.name}
                        </h3>

                        {/* Exact Salt Composition */}
                        <p className="text-[11px] text-charcoal-500 line-clamp-1">
                          <strong className="text-charcoal-700">Salt:</strong> {item.activeIngredients}
                        </p>

                        <p className="text-[11px] text-charcoal-400 truncate">
                          By: {item.manufacturer}
                        </p>
                      </div>
                    </div>

                    {/* Bottom Pricing & Add to Cart */}
                    <div className="pt-3 mt-3 border-t border-cream-200">
                      <div className="flex items-baseline justify-between mb-2">
                        <div>
                          <div className="flex items-baseline gap-1.5">
                            <span className="text-base font-display font-extrabold text-teal-850">
                              ₹{item.discountPrice || item.price}
                            </span>
                            {item.discountPrice && (
                              <span className="text-[11px] text-charcoal-400 line-through">
                                ₹{item.price}
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-emerald-700 font-semibold block">
                            ✓ In Stock ({item.stockCount} left)
                          </span>
                        </div>

                        {item.alternatives && item.alternatives.length > 0 && (
                          <button
                            onClick={() => setSelectedProduct(item)}
                            className="text-[10px] text-peach-700 font-bold bg-peach-50 px-2 py-1 rounded-lg hover:bg-peach-100 flex items-center gap-1"
                          >
                            <TrendingDown className="w-3 h-3" />
                            <span>Generic Available</span>
                          </button>
                        )}
                      </div>

                      {/* Direct Add to Cart / Quantity controls */}
                      <div className="flex items-center gap-2">
                        {inCart ? (
                          <div className="w-full flex items-center justify-between bg-cream-100 p-1.5 rounded-xl border border-cream-300">
                            <button
                              onClick={() => updateCartQuantity(item.id, inCart.quantity - 1)}
                              className="p-1 rounded-lg bg-white text-charcoal-800 hover:bg-cream-200 shadow-sm"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="text-xs font-bold text-charcoal-900 px-2">
                              {inCart.quantity} in cart
                            </span>
                            <button
                              onClick={() => updateCartQuantity(item.id, inCart.quantity + 1)}
                              className="p-1 rounded-lg bg-teal-850 text-white hover:bg-teal-700 shadow-sm"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              addToCart(item, 1);
                              triggerConfetti(1500);
                            }}
                            className="w-full py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all hover:scale-[1.02]"
                          >
                            <Plus className="w-4 h-4" />
                            <span>Add to Cart</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* Orders & Live Tracking View */
        <div className="space-y-4">
          {orders.map((order) => {
            const stepIdx = getOrderStatusStep(order.status);
            return (
              <div
                key={order.id}
                className="p-6 rounded-3xl bg-white border border-cream-300 shadow-card space-y-5"
              >
                {/* Order Top Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-cream-200">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-display font-extrabold text-base text-charcoal-900">
                        Order #{order.orderNumber}
                      </h3>
                      <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                        {order.status}
                      </span>
                    </div>
                    <p className="text-xs text-charcoal-500 mt-0.5">
                      Placed on {order.date} • {order.items.length} items • Total: ₹{order.total}
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-bold text-teal-850 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
                      {order.estimatedDelivery}
                    </span>
                  </div>
                </div>

                {/* 7-Stage Order Status Stepper */}
                <div className="p-4 rounded-2xl bg-cream-50 border border-cream-200">
                  <p className="text-xs font-bold text-charcoal-600 uppercase mb-3">Live Order Tracking:</p>
                  <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 text-center text-xs">
                    {[
                      'Confirmed',
                      'Prescription Verification',
                      'Packed',
                      'Shipped',
                      'Out for Delivery',
                      'Delivered'
                    ].map((stepName, sIdx) => {
                      const isDone = sIdx <= stepIdx;
                      const isCurrent = sIdx === stepIdx;
                      return (
                        <div
                          key={stepName}
                          className={`p-2.5 rounded-xl border flex flex-col items-center justify-center transition-all ${
                            isCurrent
                              ? 'bg-teal-850 text-white font-bold border-teal-850 ring-2 ring-teal-700/30'
                              : isDone
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300 font-semibold'
                              : 'bg-white text-charcoal-400 border-cream-300'
                          }`}
                        >
                          <span className="text-[10px] uppercase font-bold">{`Step ${sIdx + 1}`}</span>
                          <span className="text-[11px] mt-1 leading-tight">{stepName}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Items in order */}
                <div className="space-y-2">
                  <p className="text-xs font-bold text-charcoal-600 uppercase">Items:</p>
                  <div className="divide-y divide-cream-100">
                    {order.items.map((ci) => (
                      <div key={ci.medicine.id} className="py-2 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-3">
                          <img
                            src={ci.medicine.image}
                            alt={ci.medicine.name}
                            className="w-10 h-10 rounded-xl object-cover ring-1 ring-cream-300"
                          />
                          <div>
                            <p className="font-bold text-charcoal-900">{ci.medicine.name}</p>
                            <p className="text-charcoal-500">{ci.medicine.dosageForm} • Qty: {ci.quantity}</p>
                          </div>
                        </div>
                        <span className="font-extrabold text-teal-850">
                          ₹{(ci.medicine.discountPrice || ci.medicine.price) * ci.quantity}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Delivery address & Reorder button */}
                <div className="pt-3 border-t border-cream-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2 text-charcoal-600">
                    <MapPin className="w-4 h-4 text-peach-500 shrink-0" />
                    <span>Delivering to: {order.deliveryAddress}</span>
                  </div>

                  <button
                    onClick={() => {
                      order.items.forEach(i => addToCart(i.medicine, i.quantity));
                      setIsCartOpen(true);
                      triggerConfetti(2000);
                    }}
                    className="px-4 py-2 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-1.5 self-end sm:self-center transition-colors"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Reorder All Items</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 5. Comprehensive Product Detail & Generic Substitutes Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-charcoal-900/70 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-3xl bg-white rounded-3xl p-6 shadow-2xl border border-cream-300 max-h-[92vh] overflow-y-auto space-y-5">
            
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-3 border-b border-cream-200">
              <div className="flex items-center gap-2.5">
                <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-teal-100 text-teal-850">
                  {selectedProduct.category}
                </span>
                {selectedProduct.prescriptionRequired ? (
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-peach-100 text-peach-700">
                    Schedule H Prescription Drug
                  </span>
                ) : (
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    OTC Product
                  </span>
                )}
              </div>
              <button
                onClick={() => setSelectedProduct(null)}
                className="p-1 rounded-full text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Product Hero Info */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-start">
              <div className="md:col-span-5 rounded-2xl overflow-hidden bg-cream-100 border border-cream-200 aspect-square">
                <img
                  src={selectedProduct.image}
                  alt={selectedProduct.name}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="md:col-span-7 space-y-3">
                <h2 className="text-xl font-display font-extrabold text-charcoal-900">
                  {selectedProduct.name}
                </h2>
                <p className="text-xs font-semibold text-charcoal-600">
                  Brand: <span className="text-teal-850">{selectedProduct.brand}</span> • Mfr: {selectedProduct.manufacturer}
                </p>

                {/* Salt composition banner */}
                <div className="p-3 rounded-xl bg-cream-100 border border-cream-200 text-xs">
                  <span className="text-charcoal-500 font-bold block mb-0.5">ACTIVE SALT COMPOSITION:</span>
                  <p className="font-extrabold text-charcoal-900">{selectedProduct.activeIngredients}</p>
                  <p className="text-[11px] text-charcoal-500 mt-1">{selectedProduct.packagingInfo}</p>
                </div>

                {/* Price Display */}
                <div className="flex items-baseline gap-3 pt-1">
                  <span className="text-2xl font-display font-black text-teal-850">
                    ₹{selectedProduct.discountPrice || selectedProduct.price}
                  </span>
                  {selectedProduct.discountPrice && (
                    <>
                      <span className="text-sm text-charcoal-400 line-through">
                        ₹{selectedProduct.price}
                      </span>
                      <span className="text-xs font-bold text-peach-600 bg-peach-50 px-2 py-0.5 rounded-full">
                        Senior Discount Applied
                      </span>
                    </>
                  )}
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    onClick={() => {
                      addToCart(selectedProduct, 1);
                      triggerConfetti(1500);
                    }}
                    className="flex-1 py-3 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-colors"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Add to Pharmacy Cart</span>
                  </button>
                  <button
                    onClick={() => {
                      addToCart(selectedProduct, 1);
                      setSelectedProduct(null);
                      setIsCartOpen(true);
                    }}
                    className="px-4 py-3 rounded-xl bg-mustard-300 hover:bg-mustard-200 text-charcoal-900 font-bold text-xs transition-colors"
                  >
                    Buy Now
                  </button>
                </div>
              </div>
            </div>

            {/* Description & Clinical Uses */}
            <div className="space-y-2 pt-2 border-t border-cream-200">
              <h4 className="text-xs font-bold text-charcoal-700 uppercase">Description & Benefits:</h4>
              <p className="text-xs text-charcoal-600 leading-relaxed">{selectedProduct.description}</p>
            </div>

            {selectedProduct.uses && selectedProduct.uses.length > 0 && (
              <div>
                <h4 className="text-xs font-bold text-charcoal-700 uppercase mb-1.5">Therapeutic Uses:</h4>
                <div className="flex flex-wrap gap-1.5">
                  {selectedProduct.uses.map((u, i) => (
                    <span key={i} className="text-xs px-2.5 py-1 rounded-xl bg-cream-100 text-charcoal-800 font-medium">
                      ✓ {u}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Generic / Alternative Substitutes Table (Apollo / Jan Aushadhi Savings) */}
            {selectedProduct.alternatives && selectedProduct.alternatives.length > 0 && (
              <div className="p-4 rounded-2xl bg-sage-50 border border-sage-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-teal-900">
                    <TrendingDown className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs font-bold uppercase tracking-wider">
                      Generic & Equivalent Salt Substitutes Available
                    </span>
                  </div>
                  <span className="text-[10px] text-emerald-800 font-bold bg-emerald-100 px-2 py-0.5 rounded-full">
                    Save up to 80%
                  </span>
                </div>

                <div className="space-y-2">
                  {selectedProduct.alternatives.map((alt) => (
                    <div
                      key={alt.id}
                      className="p-3 rounded-xl bg-white border border-sage-300 flex items-center justify-between text-xs"
                    >
                      <div>
                        <p className="font-bold text-charcoal-900">{alt.name}</p>
                        <p className="text-[11px] text-charcoal-500">{alt.brand} • {alt.manufacturer}</p>
                        <span className="text-[10px] text-emerald-700 font-semibold">
                          Same active salt: {selectedProduct.activeIngredients}
                        </span>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <span className="font-extrabold text-teal-850 text-sm">
                            ₹{alt.discountPrice || alt.price}
                          </span>
                          {alt.savingsPercent > 0 && (
                            <span className="text-[10px] text-emerald-600 font-bold block">
                              Save {alt.savingsPercent}%
                            </span>
                          )}
                        </div>

                        <button
                          onClick={() => {
                            // Add generic alternative
                            addToCart({
                              ...selectedProduct,
                              id: alt.id,
                              name: alt.name,
                              brand: alt.brand,
                              manufacturer: alt.manufacturer,
                              price: alt.price,
                              discountPrice: alt.discountPrice
                            }, 1);
                            triggerConfetti(1500);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs"
                        >
                          Switch & Add
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <p className="text-[10px] text-charcoal-500 italic">
                  *Generic medicines have the identical active chemical salt, strength, and therapeutic bioequivalence as the branded version. Always check with your doctor or pharmacist.
                </p>
              </div>
            )}

            {/* Safety Advice */}
            {selectedProduct.safetyAdvice && (
              <div className="p-4 rounded-2xl bg-cream-50 border border-cream-200 space-y-2 text-xs">
                <span className="font-bold text-charcoal-700 uppercase flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-teal-700" />
                  <span>Clinical Safety Advice:</span>
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-charcoal-600 text-[11px]">
                  {selectedProduct.safetyAdvice.alcohol && (
                    <p>• <strong>Alcohol:</strong> {selectedProduct.safetyAdvice.alcohol}</p>
                  )}
                  {selectedProduct.safetyAdvice.driving && (
                    <p>• <strong>Driving:</strong> {selectedProduct.safetyAdvice.driving}</p>
                  )}
                  {selectedProduct.safetyAdvice.kidney && (
                    <p>• <strong>Kidney:</strong> {selectedProduct.safetyAdvice.kidney}</p>
                  )}
                  {selectedProduct.safetyAdvice.liver && (
                    <p>• <strong>Liver:</strong> {selectedProduct.safetyAdvice.liver}</p>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 6. Cart Slide-Over Drawer */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-charcoal-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between">
            {/* Drawer Header */}
            <div className="p-5 border-b border-cream-200 flex items-center justify-between bg-cream-100">
              <div className="flex items-center gap-2.5">
                <ShoppingBag className="w-5 h-5 text-teal-850" />
                <h3 className="font-display font-extrabold text-lg text-charcoal-900">
                  Pharmacy Cart ({cart.reduce((s, i) => s + i.quantity, 0)})
                </h3>
              </div>
              <button
                onClick={() => setIsCartOpen(false)}
                className="p-1 rounded-full text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cart Items List */}
            <div className="flex-1 overflow-y-auto p-5 space-y-3">
              {cart.length === 0 ? (
                <div className="text-center py-16 space-y-3">
                  <ShoppingBag className="w-12 h-12 text-charcoal-300 mx-auto" />
                  <p className="font-bold text-charcoal-700 text-sm">Your medicine cart is empty</p>
                  <p className="text-xs text-charcoal-500">
                    Browse the catalogue or scan packaging to add items
                  </p>
                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      openScanner();
                    }}
                    className="mt-3 px-4 py-2 rounded-xl bg-mustard-300 text-charcoal-900 font-bold text-xs"
                  >
                    Scan Medicine Photo
                  </button>
                </div>
              ) : (
                cart.map((ci) => (
                  <div
                    key={ci.medicine.id}
                    className="p-3.5 rounded-2xl bg-cream-50 border border-cream-200 flex items-center justify-between gap-3"
                  >
                    <img
                      src={ci.medicine.image}
                      alt={ci.medicine.name}
                      className="w-12 h-12 rounded-xl object-cover ring-1 ring-cream-300"
                    />

                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold text-charcoal-900 truncate">{ci.medicine.name}</p>
                      <p className="text-[11px] text-teal-850 font-semibold">
                        ₹{ci.medicine.discountPrice || ci.medicine.price} each
                      </p>
                      {ci.medicine.prescriptionRequired && (
                        <span className="text-[9px] text-peach-600 font-bold block">
                          Rx Verification Required
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => updateCartQuantity(ci.medicine.id, ci.quantity - 1)}
                        className="p-1 rounded-md bg-white border text-charcoal-700"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-bold">{ci.quantity}</span>
                      <button
                        onClick={() => updateCartQuantity(ci.medicine.id, ci.quantity + 1)}
                        className="p-1 rounded-md bg-teal-850 text-white"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => removeFromCart(ci.medicine.id)}
                        className="text-charcoal-400 hover:text-red-600 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Cart Footer */}
            {cart.length > 0 && (
              <div className="p-5 border-t border-cream-200 bg-cream-50 space-y-3">
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between text-charcoal-600">
                    <span>Subtotal:</span>
                    <span>₹{cartTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span>Senior Doorstep Delivery:</span>
                    <span className="font-bold">FREE</span>
                  </div>
                  {cartTotal > 300 && (
                    <div className="flex justify-between text-peach-600 font-bold">
                      <span>Caregiver Senior Discount:</span>
                      <span>-₹30.00</span>
                    </div>
                  )}
                  <div className="flex justify-between text-sm font-extrabold text-charcoal-900 pt-2 border-t border-cream-200">
                    <span>Total Amount:</span>
                    <span className="text-teal-850">
                      ₹{Math.max(0, cartTotal - (cartTotal > 300 ? 30 : 0)).toFixed(2)}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => setIsCheckoutOpen(true)}
                  className="w-full py-3.5 rounded-2xl bg-teal-850 hover:bg-teal-700 text-white font-display font-bold text-sm shadow-md transition-colors"
                >
                  Proceed to Checkout →
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 7. Checkout & Prescription Upload Modal */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/70 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-cream-300 max-h-[92vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-cream-200">
              <h3 className="font-display font-bold text-lg text-charcoal-900">
                Confirm Medicine Order
              </h3>
              <button
                onClick={() => setIsCheckoutOpen(false)}
                className="p-1 rounded-full text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCheckoutSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">
                  Delivery Address (Home Delivery):
                </label>
                <textarea
                  rows={2}
                  required
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
                />
              </div>

              {/* Prescription Check & Upload */}
              {cart.some((ci) => ci.medicine.prescriptionRequired) && (
                <div className="p-4 rounded-2xl bg-peach-50 border border-peach-200 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-peach-700 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-peach-500" />
                      <span>Doctor Prescription Required (Schedule H):</span>
                    </span>
                    <span className="text-[10px] bg-peach-500 text-white font-bold px-2 py-0.5 rounded-full">
                      Verified On File
                    </span>
                  </div>
                  <p className="text-[11px] text-charcoal-600">
                    Valid prescription by Dr. Arvind Rao / Dr. Vikram Patel is linked from your MyCare medical record.
                  </p>
                </div>
              )}

              {/* Payment Method */}
              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">
                  Payment Method:
                </label>
                <div className="space-y-2">
                  {[
                    "Cash on Delivery (Senior Pay)",
                    "UPI / QR on Delivery",
                    "Family Circle Prepaid Account"
                  ].map((method) => (
                    <label
                      key={method}
                      className={`flex items-center gap-2 p-2.5 rounded-xl border cursor-pointer text-xs ${
                        paymentMethod === method
                          ? 'border-teal-700 bg-teal-50 font-bold'
                          : 'border-cream-300'
                      }`}
                    >
                      <input
                        type="radio"
                        name="paymentMethod"
                        checked={paymentMethod === method}
                        onChange={() => setPaymentMethod(method)}
                      />
                      <span>{method}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Indian Pharmacy Regulations Notice */}
              <div className="p-3 rounded-xl bg-cream-100 text-[11px] text-charcoal-600 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-teal-850 shrink-0 mt-0.5" />
                <span>
                  All orders are verified by certified clinical pharmacists before dispatch in compliance with the Drugs and Cosmetics Act.
                </span>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="submit"
                  className="flex-1 py-3.5 rounded-2xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-sm shadow-md transition-colors"
                >
                  Place Order (₹{Math.max(0, cartTotal - (cartTotal > 300 ? 30 : 0)).toFixed(2)})
                </button>
                <button
                  type="button"
                  onClick={() => setIsCheckoutOpen(false)}
                  className="px-4 py-3 rounded-2xl bg-cream-200 text-charcoal-700 font-semibold text-xs"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 8. CSV Bulk Import Modal (Scalable Database Provider) */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/70 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-xl bg-white rounded-3xl p-6 shadow-2xl border border-cream-300 max-h-[92vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-cream-200">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-teal-700" />
                <h3 className="font-display font-bold text-lg text-charcoal-900">
                  Bulk Medicine Catalogue Import (CSV)
                </h3>
              </div>
              <button
                onClick={() => setIsImportModalOpen(false)}
                className="p-1 rounded-full text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-charcoal-600">
              Easily expand the catalogue with hundreds or thousands of verified medicines from your pharmacy distributor or hospital inventory.
            </p>

            {importNotice && (
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>{importNotice}</span>
              </div>
            )}

            <form onSubmit={handleImportSubmit} className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-charcoal-700">
                    Paste CSV Data:
                  </label>
                  <button
                    type="button"
                    onClick={() => setCsvInput(sampleCSVTemplate)}
                    className="text-[11px] font-bold text-teal-850 hover:underline"
                  >
                    Load Sample Template
                  </button>
                </div>
                <textarea
                  rows={6}
                  required
                  placeholder={`name,brand,strength,salt,category,price,isRx\nProduct Name,Brand,500mg,Salt,Diabetes Care,99,true`}
                  value={csvInput}
                  onChange={(e) => setCsvInput(e.target.value)}
                  className="w-full font-mono text-xs p-3 rounded-xl border border-cream-300 focus:ring-2 focus:ring-teal-700 focus:outline-none bg-cream-50"
                />
              </div>

              <div className="p-3 rounded-xl bg-cream-100 text-[11px] text-charcoal-600 space-y-1">
                <p className="font-bold text-charcoal-900">CSV Header Format:</p>
                <code className="text-teal-850 font-bold block">
                  name, brand, strength, salt, category, price, isRx
                </code>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs shadow-md transition-colors"
                >
                  Import Medications into Catalogue
                </button>
                <button
                  type="button"
                  onClick={() => resetCatalogue()}
                  className="px-4 py-3 rounded-xl bg-cream-200 text-charcoal-700 font-semibold text-xs"
                  title="Reset to original verified Apollo & PharmEasy dataset"
                >
                  Reset Default
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 9. Single Medicine Add Modal (Admin / Pharmacist) */}
      {isAddProductModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/70 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-cream-300 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-cream-200">
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Add Product to Pharmacy Inventory
              </h3>
              <button
                onClick={() => setIsAddProductModalOpen(false)}
                className="p-1 rounded-full text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSingleProduct} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">Product Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Amlong 10"
                    value={newProdName}
                    onChange={(e) => setNewProdName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">Brand / Mfr</label>
                  <input
                    type="text"
                    placeholder="e.g. Micro Labs"
                    value={newProdBrand}
                    onChange={(e) => setNewProdBrand(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">Strength</label>
                  <input
                    type="text"
                    placeholder="e.g. 10 mg"
                    value={newProdStrength}
                    onChange={(e) => setNewProdStrength(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-charcoal-700 block mb-1">Price (₹)</label>
                  <input
                    type="number"
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">Active Salt Composition</label>
                <input
                  type="text"
                  placeholder="e.g. Amlodipine (10mg)"
                  value={newProdSalt}
                  onChange={(e) => setNewProdSalt(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">Category</label>
                <select
                  value={newProdCat}
                  onChange={(e) => setNewProdCat(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                >
                  {medicineCategoriesList.filter((c) => c !== 'All').map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <label className="flex items-center gap-2 text-xs font-bold text-charcoal-700 pt-1">
                <input
                  type="checkbox"
                  checked={newProdIsRx}
                  onChange={(e) => setNewProdIsRx(e.target.checked)}
                  className="text-teal-700 rounded"
                />
                <span>Prescription Required (Schedule H)</span>
              </label>

              <div className="pt-2 flex gap-3">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs shadow-md"
                >
                  Add to Catalogue
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddProductModalOpen(false)}
                  className="px-4 py-3 rounded-xl bg-cream-200 text-charcoal-700 font-semibold text-xs"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
