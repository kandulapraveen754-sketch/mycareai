// ==========================================
// MYCARE AI - DEDICATED AI GUARDIAN PAGE
// Full-Screen Conversational Voice Healthcare Assistant
// Real-time patient clinical records context
// Multilingual: English, Telugu, Hindi
// ==========================================

import React, { useState } from 'react';
import {
  Sparkles,
  Mic,
  MicOff,
  Send,
  Volume2,
  VolumeX,
  RefreshCw,
  Bot,
  User,
  ShieldCheck,
  HeartPulse,
  Pill,
  Calendar,
  AlertTriangle,
  Globe
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { VoiceService } from '../services/voiceService';
import { LanguageCode } from '../types';

export const GuardianPage: React.FC = () => {
  const {
    guardianMessages,
    isGuardianTyping,
    sendGuardianMessage,
    clearGuardianChat,
    language,
    setLanguage,
    autoVoiceEnabled,
    setAutoVoiceEnabled,
    currentUser,
    todayDoses,
    appointments,
    medicines,
    isElderlyMode,
    t
  } = useApp();

  const [inputQuery, setInputQuery] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [voiceError, setVoiceError] = useState<string | null>(null);

  const pendingDoses = todayDoses.filter(d => d.status === 'pending');
  const nextApt = appointments.find(a => a.status === 'Confirmed');

  const suggestedQuestions = [
    "What medicines should I take today?",
    "Did I miss any medicine?",
    "When is my next appointment with Dr. Patel?",
    "What is my adherence this week?",
    "Show my blood pressure trend",
    "How does Telmikind 40 help my blood pressure?",
    "What should I do if I feel dizzy?"
  ];

  const handleSend = () => {
    if (!inputQuery.trim()) return;
    sendGuardianMessage(inputQuery);
    setInputQuery('');
  };

  const handleVoiceToggle = () => {
    if (isListening) {
      VoiceService.stopListening();
      setIsListening(false);
      return;
    }

    setVoiceError(null);
    const started = VoiceService.startListening(
      language,
      (transcript, isFinal) => {
        setInputQuery(transcript);
        if (isFinal) {
          setIsListening(false);
        }
      },
      (error) => {
        setVoiceError(error);
        setIsListening(false);
      },
      () => {
        setIsListening(false);
      }
    );

    if (started) {
      setIsListening(true);
    }
  };

  const speakMessage = (text: string) => {
    VoiceService.speak(text, language);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="rounded-3xl bg-teal-850 text-cream-50 p-6 shadow-card border border-teal-700/40 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-mustard-300 text-charcoal-900 flex items-center justify-center font-bold">
              <Sparkles className="w-5 h-5 text-teal-850" />
            </div>
            <div>
              <h1 className="text-2xl font-display font-extrabold text-cream-50">
                {t.aiGuardian} — Healthcare Companion
              </h1>
              <p className="text-xs text-cream-200">
                Personalized AI assistant connected to your prescriptions, appointments, and vitals
              </p>
            </div>
          </div>
        </div>

        {/* Voice and Language quick selectors */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-teal-900/80 border border-teal-700/50">
            {(['en', 'te', 'hi'] as LanguageCode[]).map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`px-3 py-1 rounded-xl text-xs font-bold uppercase transition-colors ${
                  language === lang
                    ? 'bg-mustard-300 text-charcoal-900 shadow-sm'
                    : 'text-cream-200 hover:text-white'
                }`}
              >
                {lang === 'en' ? 'English' : lang === 'te' ? 'తెలుగు' : 'हिन्दी'}
              </button>
            ))}
          </div>

          <button
            onClick={() => setAutoVoiceEnabled(!autoVoiceEnabled)}
            className={`px-3 py-2 rounded-2xl text-xs font-bold flex items-center gap-1.5 transition-colors ${
              autoVoiceEnabled
                ? 'bg-mustard-300 text-charcoal-900'
                : 'bg-teal-900/80 text-cream-200 border border-teal-700/50'
            }`}
          >
            {autoVoiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span>{autoVoiceEnabled ? 'Auto-Voice On' : 'Voice Muted'}</span>
          </button>
        </div>
      </div>

      {/* Main Conversation & Context Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (8 cols): Large Chat Interface */}
        <div className="lg:col-span-8 space-y-4">
          <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card flex flex-col h-[650px] justify-between">
            
            {/* Chat Messages List */}
            <div className="flex-1 overflow-y-auto space-y-4 pr-2 scrollbar-thin">
              {guardianMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex items-start gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
                >
                  <div
                    className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 shadow-sm ${
                      msg.sender === 'user'
                        ? 'bg-peach-500 text-white'
                        : 'bg-teal-850 text-mustard-300'
                    }`}
                  >
                    {msg.sender === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
                  </div>

                  <div
                    className={`max-w-[85%] rounded-3xl p-4 shadow-sm ${
                      msg.sender === 'user'
                        ? 'bg-peach-500 text-white rounded-tr-none'
                        : 'bg-cream-50 text-charcoal-800 border border-cream-200 rounded-tl-none'
                    }`}
                  >
                    <p className={`whitespace-pre-line leading-relaxed ${isElderlyMode ? 'text-base' : 'text-sm'}`}>
                      {msg.text}
                    </p>

                    <div className="mt-2 flex items-center justify-between gap-3 text-xs">
                      {msg.sender === 'guardian' && (
                        <button
                          onClick={() => speakMessage(msg.text)}
                          className="flex items-center gap-1 text-teal-850 hover:text-teal-700 font-semibold"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>Listen</span>
                        </button>
                      )}
                      <span className={`text-[10px] ml-auto ${msg.sender === 'user' ? 'text-peach-200' : 'text-charcoal-400'}`}>
                        {msg.timestamp}
                      </span>
                    </div>

                    {msg.suggestedPills && msg.suggestedPills.length > 0 && (
                      <div className="mt-3 pt-2.5 border-t border-cream-200/80 flex flex-wrap gap-1.5">
                        {msg.suggestedPills.map((pill, pIdx) => (
                          <button
                            key={pIdx}
                            onClick={() => sendGuardianMessage(pill)}
                            className="text-[11px] px-2.5 py-1 rounded-full bg-white text-teal-850 border border-cream-300 hover:bg-teal-50 font-bold"
                          >
                            {pill}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {isGuardianTyping && (
                <div className="flex items-center gap-2 p-3.5 bg-cream-50 rounded-2xl border border-cream-200 max-w-xs">
                  <RefreshCw className="w-4 h-4 animate-spin text-teal-700" />
                  <span className="text-xs text-charcoal-600 font-semibold">
                    AI Guardian is formulating clinical answer...
                  </span>
                </div>
              )}
            </div>

            {/* Listening Indicator */}
            {isListening && (
              <div className="my-2 p-3 rounded-2xl bg-peach-100 border border-peach-300 flex items-center justify-between animate-pulse">
                <div className="flex items-center gap-2 text-peach-800 text-xs font-bold">
                  <span className="w-2.5 h-2.5 rounded-full bg-peach-500 animate-ping"></span>
                  <span>{t.listening} {t.speakNow}</span>
                </div>
                <button
                  onClick={() => VoiceService.stopListening()}
                  className="text-xs font-bold text-peach-600 underline"
                >
                  Done Speaking
                </button>
              </div>
            )}

            {voiceError && (
              <p className="my-1 text-xs text-red-600 bg-red-50 p-2 rounded-xl border border-red-200">
                {voiceError}
              </p>
            )}

            {/* Input Bar with Voice Mic */}
            <div className="pt-3 border-t border-cream-200 space-y-2">
              <div className="flex items-center gap-2">
                <button
                  onClick={handleVoiceToggle}
                  className={`p-3.5 rounded-2xl transition-all shadow-sm ${
                    isListening
                      ? 'bg-peach-500 text-white ring-4 ring-peach-300 animate-pulse'
                      : 'bg-teal-850 hover:bg-teal-700 text-white'
                  }`}
                  title="Speak in English, Telugu, or Hindi"
                >
                  {isListening ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                </button>

                <input
                  type="text"
                  value={inputQuery}
                  onChange={(e) => setInputQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder={t.typeYourMessage}
                  className="flex-1 px-4 py-3.5 rounded-2xl bg-cream-50 border border-cream-300 text-charcoal-800 placeholder-charcoal-400 text-sm focus:outline-none focus:ring-2 focus:ring-teal-700"
                />

                <button
                  onClick={handleSend}
                  disabled={!inputQuery.trim()}
                  className="p-3.5 rounded-2xl bg-teal-850 hover:bg-teal-700 disabled:opacity-50 text-white transition-colors shadow-sm"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>

              <div className="flex items-center justify-between text-[11px] text-charcoal-500 pt-1">
                <span>Microphone supports: English, తెలుగు (Telugu), हिन्दी (Hindi)</span>
                <button
                  onClick={clearGuardianChat}
                  className="hover:underline text-teal-850 font-semibold"
                >
                  Clear Chat
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (4 cols): Patient Clinical Context Card */}
        <div className="lg:col-span-4 space-y-4">
          <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-5">
            <h3 className="font-display font-bold text-base text-charcoal-900 pb-2 border-b border-cream-200">
              Live Clinical Context (Ramesh Sharma)
            </h3>

            {/* Conditions & Allergies */}
            <div className="space-y-2 text-xs">
              <span className="font-bold text-charcoal-500 uppercase tracking-wider block">
                Diagnosed Conditions:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {(currentUser.conditions || []).map((c, i) => (
                  <span key={i} className="px-2.5 py-1 rounded-xl bg-cream-100 text-charcoal-800 font-semibold">
                    {c}
                  </span>
                ))}
              </div>
            </div>

            <div className="space-y-1.5 text-xs">
              <span className="font-bold text-red-600 uppercase tracking-wider block">
                Known Drug Allergies:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {(currentUser.allergies || []).map((a, i) => (
                  <span key={i} className="px-2.5 py-1 rounded-xl bg-red-50 text-red-700 font-bold border border-red-200">
                    ⚠ {a}
                  </span>
                ))}
              </div>
            </div>

            {/* Pending Doses */}
            <div className="p-3.5 rounded-2xl bg-sage-50 border border-sage-200 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-teal-900">
                <span className="flex items-center gap-1.5">
                  <Pill className="w-4 h-4 text-teal-700" />
                  <span>Pending Doses Today:</span>
                </span>
                <span className="px-2 py-0.5 rounded-full bg-teal-850 text-white text-[10px]">
                  {pendingDoses.length} remaining
                </span>
              </div>
              <div className="space-y-1 text-xs text-charcoal-700">
                {pendingDoses.map((d) => (
                  <p key={d.id} className="font-medium">
                    • {d.medicineName} ({d.scheduledTime})
                  </p>
                ))}
              </div>
            </div>

            {/* Next Doctor Visit */}
            {nextApt && (
              <div className="p-3.5 rounded-2xl bg-peach-50 border border-peach-200 space-y-1 text-xs">
                <span className="font-bold text-peach-700 uppercase flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-peach-500" />
                  <span>Next Doctor Visit:</span>
                </span>
                <p className="font-bold text-charcoal-900">{nextApt.doctorName}</p>
                <p className="text-charcoal-600">{nextApt.date} at {nextApt.time}</p>
              </div>
            )}

            {/* Safety Disclaimers */}
            <div className="p-3.5 rounded-2xl bg-cream-100 text-[11px] text-charcoal-600 space-y-1 border border-cream-200">
              <span className="font-bold text-charcoal-900 flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-teal-700" />
                <span>AI Clinical Boundaries:</span>
              </span>
              <p>
                AI Guardian cannot diagnose illnesses, alter prescribed dosages, or prescribe restricted drugs. In acute distress, trigger Emergency SOS.
              </p>
            </div>
          </div>

          {/* Quick Prompts to Try */}
          <div className="rounded-3xl bg-cream-50 border border-cream-300 p-5 shadow-sm space-y-2.5">
            <p className="text-xs font-bold text-charcoal-700 uppercase tracking-wider">
              Quick Inquiries to Try:
            </p>
            <div className="space-y-1.5">
              {suggestedQuestions.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => sendGuardianMessage(q)}
                  className="w-full text-left text-xs p-2 rounded-xl bg-white hover:bg-teal-50 hover:text-teal-850 border border-cream-200 transition-colors font-medium text-charcoal-700"
                >
                  "{q}"
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
