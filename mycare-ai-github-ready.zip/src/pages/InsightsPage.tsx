// ==========================================
// MYCARE AI - HEALTH INSIGHTS & REPORTS
// Adherence graphs, vitals trend lines, missed-dose audit,
// Printable / Downloadable Health Summary Report
// ==========================================

import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Download,
  Printer,
  Calendar,
  HeartPulse,
  Droplet,
  Activity,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Sparkles,
  Share2
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';
import { useApp } from '../context/AppContext';
import { weeklyAdherenceData } from '../data/mockData';

export const InsightsPage: React.FC = () => {
  const { vitals, currentUser, medicines, appointments, t } = useApp();
  const [reportGenerated, setReportGenerated] = useState(false);

  // Transform vitals data for chart (reversed chronologically)
  const vitalsChartData = [...vitals].reverse().map((v) => ({
    name: v.date.split(' ')[0],
    systolic: v.bloodPressureSystolic,
    diastolic: v.bloodPressureDiastolic,
    glucose: v.bloodGlucose,
    pulse: v.heartRate
  }));

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-display font-extrabold text-charcoal-900">
              {t.healthInsights} & Adherence Reports
            </h1>
            <span className="text-xs bg-mustard-100 text-mustard-600 font-bold px-2.5 py-0.5 rounded-full">
              7-Day Adherence: 92%
            </span>
          </div>
          <p className="text-xs text-charcoal-500 mt-1">
            Clinical reports compiled from daily dose confirmations, nurse readings, and doctor consultations
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handlePrint}
            className="px-4 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-all"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>

          <button
            onClick={() => setReportGenerated(true)}
            className="px-4 py-2.5 rounded-xl bg-mustard-300 hover:bg-mustard-200 text-charcoal-900 font-display font-bold text-xs flex items-center gap-2 shadow-sm transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Export Clinical Summary</span>
          </button>
        </div>
      </div>

      {/* AI Guardian Summary Banner */}
      <div className="p-5 rounded-3xl bg-cream-100 border border-cream-300 flex items-start gap-4">
        <div className="w-10 h-10 rounded-2xl bg-teal-850 text-mustard-300 flex items-center justify-center shrink-0 shadow-sm mt-0.5">
          <Sparkles className="w-5 h-5" />
        </div>
        <div className="space-y-1">
          <h3 className="font-display font-bold text-sm text-teal-850">
            AI Guardian Clinical Assessment
          </h3>
          <p className="text-xs text-charcoal-700 leading-relaxed">
            Patient Ramesh Sharma (74 yrs) demonstrated strong adherence (92%) over the past 7 days with zero unconfirmed doses. Resting blood pressure remains well-controlled (126/82 mmHg average) under Telmikind 40 therapy. Fasting blood sugar is stable at 118 mg/dL. Ready for Dr. Vikram Patel's review on Nov 18.
          </p>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Adherence Chart */}
        <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-cream-200">
            <div>
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Weekly Medication Adherence (%)
              </h3>
              <p className="text-xs text-charcoal-500">Scheduled vs Confirmed Doses</p>
            </div>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full">
              Target &gt; 85% Met
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyAdherenceData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#EDE4D5" />
                <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#566661' }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#566661' }} />
                <Tooltip
                  formatter={(val: any) => [`${val}%`, 'Adherence']}
                  contentStyle={{ backgroundColor: '#174F4A', borderRadius: 12, color: '#FAF7F2' }}
                />
                <Bar dataKey="adherence" fill="#286B61" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Blood Pressure & Pulse Trend */}
        <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-cream-200">
            <div>
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Blood Pressure Trend (mmHg)
              </h3>
              <p className="text-xs text-charcoal-500">Systolic & Diastolic Logged by Nurse Anjali</p>
            </div>
            <span className="text-xs font-bold text-teal-850 bg-teal-50 px-2.5 py-0.5 rounded-full">
              Target: &lt; 130/85
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={vitalsChartData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#EDE4D5" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#566661' }} />
                <YAxis domain={[60, 150]} tick={{ fontSize: 11, fill: '#566661' }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#174F4A', borderRadius: 12, color: '#FAF7F2' }}
                />
                <Line type="monotone" dataKey="systolic" stroke="#C77B5A" strokeWidth={3} dot={{ r: 4 }} name="Systolic" />
                <Line type="monotone" dataKey="diastolic" stroke="#286B61" strokeWidth={2.5} dot={{ r: 4 }} name="Diastolic" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Vitals Log Table */}
      <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-4">
        <h3 className="font-display font-bold text-base text-charcoal-900 pb-2 border-b border-cream-200">
          Recorded Vital Signs Log
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-cream-100 text-charcoal-700 uppercase font-bold text-[10px]">
              <tr>
                <th className="p-3 rounded-l-xl">Date / Time</th>
                <th className="p-3">Blood Pressure (mmHg)</th>
                <th className="p-3">Pulse (bpm)</th>
                <th className="p-3">Fasting Glucose (mg/dL)</th>
                <th className="p-3">SpO2 (%)</th>
                <th className="p-3 rounded-r-xl">Logged By</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-cream-100">
              {vitals.map((v) => (
                <tr key={v.id} className="hover:bg-cream-50 transition-colors">
                  <td className="p-3 font-bold text-charcoal-900">{v.date}</td>
                  <td className="p-3 text-teal-850 font-bold">{v.bloodPressureSystolic}/{v.bloodPressureDiastolic}</td>
                  <td className="p-3">{v.heartRate} bpm</td>
                  <td className="p-3">{v.bloodGlucose} mg/dL</td>
                  <td className="p-3 text-emerald-700 font-bold">{v.spo2}%</td>
                  <td className="p-3 text-charcoal-500">{v.recordedBy}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Export Report Preview Banner */}
      {reportGenerated && (
        <div className="p-5 rounded-3xl bg-emerald-50 border border-emerald-300 text-emerald-900 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-emerald-600" />
            <div>
              <p className="font-bold text-sm">Clinical Summary Ready for Download</p>
              <p className="text-xs text-emerald-700">Includes 7-day adherence charts, recent vitals, active prescriptions & doctor remarks.</p>
            </div>
          </div>
          <button
            onClick={handlePrint}
            className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs"
          >
            Save as PDF
          </button>
        </div>
      )}
    </div>
  );
};
