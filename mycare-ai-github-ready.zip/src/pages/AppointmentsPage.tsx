// ==========================================
// MYCARE AI - DOCTOR APPOINTMENTS BOOKING PAGE
// Specialists, interactive slot selection, double-booking prevention,
// Teleconsultation & In-person Clinic visits
// ==========================================

import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  Star,
  Search,
  Filter,
  Video,
  Building,
  CheckCircle2,
  X,
  PhoneCall,
  UserCheck,
  ChevronRight
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Doctor, Appointment } from '../types';

export const AppointmentsPage: React.FC = () => {
  const {
    doctors,
    appointments,
    bookAppointment,
    cancelAppointment,
    rescheduleAppointment,
    isElderlyMode,
    t
  } = useApp();

  const [searchDoctorQuery, setSearchDoctorQuery] = useState('');
  const [selectedSpecialization, setSelectedSpecialization] = useState('All');
  const [bookingDoctor, setBookingDoctor] = useState<Doctor | null>(null);
  const [selectedDate, setSelectedDate] = useState('2026-11-16');
  const [selectedSlot, setSelectedSlot] = useState('10:00 AM');
  const [consultationType, setConsultationType] = useState<'In-person Clinic' | 'Video Consultation'>('In-person Clinic');
  const [consultationReason, setConsultationReason] = useState('Routine Elderly Assessment & Blood Pressure Review');

  const specializations = [
    'All',
    'Geriatric Medicine Specialist',
    'Senior Cardiologist',
    'Endocrinologist & Diabetologist',
    'Neurologist',
    'Orthopedic & Joint Care',
    'Ophthalmologist (Eye Care)'
  ];

  const filteredDoctors = doctors.filter((doc) => {
    const matchesSearch =
      doc.name.toLowerCase().includes(searchDoctorQuery.toLowerCase()) ||
      doc.specialization.toLowerCase().includes(searchDoctorQuery.toLowerCase()) ||
      doc.hospital.toLowerCase().includes(searchDoctorQuery.toLowerCase());

    const matchesSpec =
      selectedSpecialization === 'All' || doc.specialization === selectedSpecialization;

    return matchesSearch && matchesSpec;
  });

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingDoctor) return;

    const success = bookAppointment(
      bookingDoctor.id,
      selectedDate,
      selectedSlot,
      consultationType,
      consultationReason
    );

    if (success) {
      setBookingDoctor(null);
    }
  };

  const upcomingApts = appointments.filter(a => a.status === 'Confirmed' || a.status === 'Rescheduled');
  const pastApts = appointments.filter(a => a.status === 'Completed' || a.status === 'Cancelled');

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-display font-extrabold text-charcoal-900">
              {t.doctorAppointments}
            </h1>
            <span className="text-xs bg-peach-100 text-peach-700 font-bold px-2.5 py-0.5 rounded-full">
              {doctors.length} Verified Specialists
            </span>
          </div>
          <p className="text-xs text-charcoal-500 mt-1">
            Book consultations, video checkups, and routine assessments with geriatric care specialists
          </p>
        </div>
      </div>

      {/* Active Consultations Card */}
      {upcomingApts.length > 0 && (
        <div className="rounded-3xl bg-peach-50/70 border border-peach-200 p-6 shadow-sm space-y-3">
          <h2 className="text-sm font-bold text-peach-800 uppercase tracking-wider">
            Your Confirmed Upcoming Appointments:
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {upcomingApts.map((apt) => (
              <div
                key={apt.id}
                className="p-4 rounded-2xl bg-white border border-peach-300 shadow-sm flex items-start justify-between gap-3"
              >
                <div className="flex items-start gap-3">
                  <img
                    src={apt.doctorImage}
                    alt={apt.doctorName}
                    className="w-12 h-12 rounded-2xl object-cover ring-2 ring-peach-300 shrink-0"
                  />
                  <div>
                    <h3 className="font-bold text-sm text-charcoal-900">{apt.doctorName}</h3>
                    <p className="text-xs text-peach-600 font-semibold">{apt.specialization}</p>
                    <p className="text-[11px] text-charcoal-600 mt-1 font-medium flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-teal-700" />
                      <span>{apt.date} at {apt.time} ({apt.type})</span>
                    </p>
                  </div>
                </div>

                <div className="text-right flex flex-col items-end gap-1.5">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {apt.status}
                  </span>
                  <button
                    onClick={() => cancelAppointment(apt.id)}
                    className="text-[11px] text-charcoal-400 hover:text-red-600 font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Search & Specialization Filters */}
      <div className="rounded-3xl bg-white border border-cream-300 p-4 shadow-sm space-y-3">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-charcoal-400" />
          <input
            type="text"
            placeholder="Search doctor name, specialization, or clinic..."
            value={searchDoctorQuery}
            onChange={(e) => setSearchDoctorQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-cream-50 border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {specializations.map((spec) => (
            <button
              key={spec}
              onClick={() => setSelectedSpecialization(spec)}
              className={`px-3.5 py-1.5 rounded-xl font-bold text-xs whitespace-nowrap transition-colors ${
                selectedSpecialization === spec
                  ? 'bg-teal-850 text-white shadow-sm'
                  : 'bg-cream-100 text-charcoal-700 hover:bg-cream-200'
              }`}
            >
              {spec}
            </button>
          ))}
        </div>
      </div>

      {/* Doctors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredDoctors.map((doc) => (
          <div
            key={doc.id}
            className="p-5 rounded-3xl border border-cream-300 bg-white hover:border-teal-700/40 hover:shadow-card-hover transition-all flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-start gap-3.5">
                <img
                  src={doc.image}
                  alt={doc.name}
                  className="w-16 h-16 rounded-2xl object-cover ring-2 ring-peach-300 shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-base text-charcoal-900 truncate">{doc.name}</h3>
                    <div className="flex items-center gap-1 text-xs font-bold text-mustard-600 bg-mustard-50 px-2 py-0.5 rounded-md">
                      <Star className="w-3.5 h-3.5 fill-mustard-500 text-mustard-500" />
                      <span>{doc.rating}</span>
                    </div>
                  </div>
                  <p className="text-xs text-peach-600 font-semibold">{doc.specialization}</p>
                  <p className="text-[11px] text-charcoal-500 mt-0.5">{doc.qualifications} • {doc.experienceYears} yrs exp</p>
                </div>
              </div>

              <p className="text-xs text-charcoal-600 mt-3 line-clamp-2">{doc.about}</p>

              <div className="mt-3 p-3 rounded-xl bg-cream-50 border border-cream-200 text-xs space-y-1">
                <p className="text-charcoal-700 flex items-center gap-1.5 truncate">
                  <MapPin className="w-3.5 h-3.5 text-teal-700 shrink-0" />
                  <span className="truncate">{doc.hospital}</span>
                </p>
                <div className="flex items-center justify-between pt-1 border-t border-cream-200">
                  <span className="text-charcoal-500">Consultation Fee:</span>
                  <span className="font-extrabold text-teal-850">₹{doc.consultationFee}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                setBookingDoctor(doc);
                if (doc.availableSlots[0]) {
                  setSelectedDate(doc.availableSlots[0].date);
                  setSelectedSlot(doc.availableSlots[0].slots[0]);
                }
              }}
              className="w-full py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-colors"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Appointment</span>
            </button>
          </div>
        ))}
      </div>

      {/* Booking Modal with Slot Picker */}
      {bookingDoctor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-cream-300 max-h-[92vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-cream-200">
              <div className="flex items-center gap-3">
                <img
                  src={bookingDoctor.image}
                  alt={bookingDoctor.name}
                  className="w-10 h-10 rounded-xl object-cover ring-2 ring-peach-300"
                />
                <div>
                  <h3 className="font-display font-bold text-base text-charcoal-900">
                    Book: {bookingDoctor.name}
                  </h3>
                  <p className="text-xs text-charcoal-500">{bookingDoctor.specialization}</p>
                </div>
              </div>
              <button
                onClick={() => setBookingDoctor(null)}
                className="p-1 rounded-full text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleBookingSubmit} className="space-y-4">
              {/* Consultation Type Radio */}
              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">
                  Consultation Mode:
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <label
                    className={`flex items-center gap-2 p-3 rounded-2xl border cursor-pointer text-xs ${
                      consultationType === 'In-person Clinic'
                        ? 'border-teal-700 bg-cream-100 font-bold'
                        : 'border-cream-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="consType"
                      checked={consultationType === 'In-person Clinic'}
                      onChange={() => setConsultationType('In-person Clinic')}
                    />
                    <Building className="w-4 h-4 text-teal-700" />
                    <span>In-person Clinic</span>
                  </label>

                  <label
                    className={`flex items-center gap-2 p-3 rounded-2xl border cursor-pointer text-xs ${
                      consultationType === 'Video Consultation'
                        ? 'border-teal-700 bg-cream-100 font-bold'
                        : 'border-cream-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="consType"
                      checked={consultationType === 'Video Consultation'}
                      onChange={() => setConsultationType('Video Consultation')}
                    />
                    <Video className="w-4 h-4 text-peach-500" />
                    <span>Video Teleconsult</span>
                  </label>
                </div>
              </div>

              {/* Date selection */}
              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">
                  Select Date:
                </label>
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {bookingDoctor.availableSlots.map((d) => (
                    <button
                      type="button"
                      key={d.date}
                      onClick={() => {
                        setSelectedDate(d.date);
                        setSelectedSlot(d.slots[0]);
                      }}
                      className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-colors ${
                        selectedDate === d.date
                          ? 'bg-teal-850 text-white shadow-sm'
                          : 'bg-cream-100 text-charcoal-700 hover:bg-cream-200'
                      }`}
                    >
                      {d.date}
                    </button>
                  ))}
                </div>
              </div>

              {/* Time slot picker */}
              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">
                  Select Time Slot:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    bookingDoctor.availableSlots.find((d) => d.date === selectedDate)?.slots || [
                      "10:00 AM",
                      "11:30 AM",
                      "04:00 PM"
                    ]
                  ).map((slot) => (
                    <button
                      type="button"
                      key={slot}
                      onClick={() => setSelectedSlot(slot)}
                      className={`p-2.5 rounded-xl border text-xs font-bold text-center transition-colors ${
                        selectedSlot === slot
                          ? 'border-teal-700 bg-teal-50 text-teal-850 ring-2 ring-teal-700/30 font-extrabold'
                          : 'border-cream-300 bg-white hover:bg-cream-50 text-charcoal-700'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reason for consultation */}
              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">
                  Reason for Visit / Symptoms:
                </label>
                <input
                  type="text"
                  required
                  value={consultationReason}
                  onChange={(e) => setConsultationReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="submit"
                  className="flex-1 py-3.5 rounded-2xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-sm shadow-md transition-colors"
                >
                  Confirm Booking (₹{bookingDoctor.consultationFee})
                </button>
                <button
                  type="button"
                  onClick={() => setBookingDoctor(null)}
                  className="px-4 py-3 rounded-2xl bg-cream-200 text-charcoal-700 font-semibold text-xs"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
