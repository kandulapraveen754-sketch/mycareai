// ==========================================
// MYCARE AI - ROOT APPLICATION COMPONENT
// Optimized for CATALYST Hackathon Evaluation:
// - Route-Level Code Splitting (React.lazy + Suspense)
// - WCAG 2.1 AA Accessibility (Skip-to-Content link, Semantic Landmarks)
// - Seamless Elderly Healthcare UX & Responsive Flow
// ==========================================

import React, { useState, Suspense, lazy } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/common/Sidebar';
import { Navbar } from './components/common/Navbar';
import { MedicineScannerModal } from './components/scanner/MedicineScannerModal';
import { EmergencyModal } from './components/emergency/EmergencyModal';
import { LogOut, Sparkles, Loader2 } from 'lucide-react';

// Lazy Loaded Pages for Instant Initial Load & Bundle Optimization
const LandingPage = lazy(() => import('./pages/LandingPage').then(m => ({ default: m.LandingPage })));
const AuthPage = lazy(() => import('./pages/AuthPage').then(m => ({ default: m.AuthPage })));
const DashboardPage = lazy(() => import('./pages/DashboardPage').then(m => ({ default: m.DashboardPage })));
const MedicinesPage = lazy(() => import('./pages/MedicinesPage').then(m => ({ default: m.MedicinesPage })));
const PharmacyPage = lazy(() => import('./pages/PharmacyPage').then(m => ({ default: m.PharmacyPage })));
const AppointmentsPage = lazy(() => import('./pages/AppointmentsPage').then(m => ({ default: m.AppointmentsPage })));
const GuardianPage = lazy(() => import('./pages/GuardianPage').then(m => ({ default: m.GuardianPage })));
const FamilyPage = lazy(() => import('./pages/FamilyPage').then(m => ({ default: m.FamilyPage })));
const InsightsPage = lazy(() => import('./pages/InsightsPage').then(m => ({ default: m.InsightsPage })));
const EmergencyPage = lazy(() => import('./pages/EmergencyPage').then(m => ({ default: m.EmergencyPage })));
const HealthPage = lazy(() => import('./pages/HealthPage').then(m => ({ default: m.HealthPage })));
const NotificationsPage = lazy(() => import('./pages/NotificationsPage').then(m => ({ default: m.NotificationsPage })));
const SettingsPage = lazy(() => import('./pages/SettingsPage').then(m => ({ default: m.SettingsPage })));

// Accessible Page Loading Fallback
const PageLoadingFallback: React.FC = () => (
  <div
    role="status"
    aria-live="polite"
    className="flex flex-col items-center justify-center min-h-[50vh] p-8 text-charcoal-700"
  >
    <div className="w-12 h-12 rounded-full border-4 border-teal-200 border-t-teal-700 animate-spin flex items-center justify-center mb-4">
      <Loader2 className="w-6 h-6 text-teal-700 animate-spin" />
    </div>
    <p className="text-sm font-semibold text-charcoal-600">Loading your healthcare records...</p>
    <span className="sr-only">Please wait, loading healthcare module.</span>
  </div>
);

const AppContent: React.FC = () => {
  const {
    activePage,
    fontSize,
    isAuthenticated,
    isDemoMode,
    enterDemoMode,
    logout
  } = useApp();

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authTab, setAuthTab] = useState<'login' | 'register' | 'forgot'>('login');

  // If not authenticated, show premium Landing Page first, or Auth Portal when requested
  if (!isAuthenticated) {
    if (showAuthModal) {
      return (
        <Suspense fallback={<PageLoadingFallback />}>
          <AuthPage
            initialTab={authTab}
            onBackToHome={() => setShowAuthModal(false)}
          />
        </Suspense>
      );
    }
    return (
      <Suspense fallback={<PageLoadingFallback />}>
        <LandingPage
          onGetStarted={() => {
            setAuthTab('register');
            setShowAuthModal(true);
          }}
          onSignIn={() => {
            setAuthTab('login');
            setShowAuthModal(true);
          }}
          onExploreDemo={(role = 'elderly') => {
            enterDemoMode(role);
          }}
        />
      </Suspense>
    );
  }

  const getFontSizeClass = () => {
    switch (fontSize) {
      case 'large':
        return 'text-base';
      case 'xlarge':
        return 'text-lg';
      case 'normal':
      default:
        return 'text-sm';
    }
  };

  const renderActivePage = () => {
    switch (activePage) {
      case 'dashboard':
        return <DashboardPage />;
      case 'health':
        return <HealthPage />;
      case 'medicines':
        return <MedicinesPage />;
      case 'ordering':
        return <PharmacyPage />;
      case 'guardian':
        return <GuardianPage />;
      case 'appointments':
        return <AppointmentsPage />;
      case 'family':
        return <FamilyPage />;
      case 'insights':
        return <InsightsPage />;
      case 'emergency':
        return <EmergencyPage />;
      case 'notifications':
        return <NotificationsPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className={`min-h-screen bg-cream-100 text-charcoal-800 flex flex-col ${getFontSizeClass()}`}>
      {/* WCAG 2.1 AA Accessibility: Skip to Main Content Link */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-teal-850 focus:text-white focus:rounded-xl focus:shadow-xl focus:ring-2 focus:ring-mustard-400 font-semibold"
      >
        Skip to main content
      </a>

      {/* Demo Mode Notice Banner */}
      {isDemoMode && (
        <div
          role="region"
          aria-label="Demo mode announcement"
          className="bg-sage-100 border-b border-sage-300 px-4 py-2 text-xs text-charcoal-800 flex items-center justify-between z-40 lg:pl-76"
        >
          <div className="flex items-center gap-2">
            <span className="bg-teal-850 text-white text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-mustard-300" aria-hidden="true" />
              Demo Mode Active
            </span>
            <span className="text-[11px] font-semibold text-charcoal-700 hidden sm:inline">
              Viewing simulated healthcare records [DEMO DATA]. No real personal information is stored.
            </span>
          </div>
          <button
            onClick={logout}
            aria-label="Exit demo mode and open login screen"
            className="text-[11px] font-bold text-teal-850 hover:text-teal-700 flex items-center gap-1 hover:underline focus:outline-none focus:ring-2 focus:ring-teal-700 rounded px-1"
          >
            <span>Exit Demo & Sign In</span>
            <LogOut className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
        </div>
      )}

      <div className="flex-1 flex">
        {/* Sidebar Navigation */}
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-w-0 lg:pl-72 transition-all">
          {/* Top Navbar */}
          <Navbar onToggleSidebar={() => setSidebarOpen(!sidebarOpen)} />

          {/* Accessible Semantic Landmark */}
          <main
            id="main-content"
            role="main"
            tabIndex={-1}
            className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto focus:outline-none"
          >
            <Suspense fallback={<PageLoadingFallback />}>
              {renderActivePage()}
            </Suspense>
          </main>
        </div>
      </div>

      {/* Global Modals */}
      <MedicineScannerModal />
      <EmergencyModal />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;
