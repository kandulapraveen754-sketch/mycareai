// ==========================================
// MYCARE AI - ROOT APPLICATION COMPONENT
// Complete Responsive Multi-page Elderly Healthcare Hub
// ==========================================

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/common/Sidebar';
import { Navbar } from './components/common/Navbar';
import { MedicineScannerModal } from './components/scanner/MedicineScannerModal';
import { EmergencyModal } from './components/emergency/EmergencyModal';
import { LogOut, Sparkles } from 'lucide-react';

// Pages
import { LandingPage } from './pages/LandingPage';
import { AuthPage } from './pages/AuthPage';
import { DashboardPage } from './pages/DashboardPage';
import { MedicinesPage } from './pages/MedicinesPage';
import { PharmacyPage } from './pages/PharmacyPage';
import { AppointmentsPage } from './pages/AppointmentsPage';
import { GuardianPage } from './pages/GuardianPage';
import { FamilyPage } from './pages/FamilyPage';
import { InsightsPage } from './pages/InsightsPage';
import { EmergencyPage } from './pages/EmergencyPage';
import { HealthPage } from './pages/HealthPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { SettingsPage } from './pages/SettingsPage';

const AppContent: React.FC = () => {
  const {
    activePage,
    isElderlyMode,
    fontSize,
    isAuthenticated,
    isDemoMode,
    enterDemoMode,
    logout
  } = useApp();

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authTab, setAuthTab] = useState<'login' | 'register' | 'forgot'>('login');

  // If not authenticated, show premium Landing Page first, or Auth Portal when requested
  if (!isAuthenticated) {
    if (showAuthModal) {
      return (
        <AuthPage
          initialTab={authTab}
          onBackToHome={() => setShowAuthModal(false)}
        />
      );
    }
    return (
      <LandingPage
        onGetStarted={() => {
          setAuthTab('register');
          setShowAuthModal(true);
        }}
        onSignIn={() => {
          setAuthTab('login');
          setShowAuthModal(true);
        }}
        onExploreDemo={(role = 'elderly') => {
          enterDemoMode(role);
        }}
      />
    );
  }

  const getFontSizeClass = () => {
    switch (fontSize) {
      case 'large':
        return 'text-base';
      case 'xlarge':
        return 'text-lg';
      case 'normal':
      default:
        return 'text-sm';
    }
  };

  const renderActivePage = () => {
    switch (activePage) {
      case 'dashboard':
        return <DashboardPage />;
      case 'health':
        return <HealthPage />;
      case 'medicines':
        return <MedicinesPage />;
      case 'ordering':
        return <PharmacyPage />;
      case 'guardian':
        return <GuardianPage />;
      case 'appointments':
        return <AppointmentsPage />;
      case 'family':
        return <FamilyPage />;
      case 'insights':
        return <InsightsPage />;
      case 'emergency':
        return <EmergencyPage />;
      case 'notifications':
        return <NotificationsPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className={`min-h-screen bg-cream-100 text-charcoal-800 flex flex-col ${getFontSizeClass()}`}>
      {/* Demo Mode Notice Banner */}
      {isDemoMode && (
        <div className="bg-sage-100 border-b border-sage-300 px-4 py-2 text-xs text-charcoal-800 flex items-center justify-between z-40 lg:pl-76">
          <div className="flex items-center gap-2">
            <span className="bg-teal-850 text-white text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-mustard-300" />
              Demo Mode Active
            </span>
            <span className="text-[11px] font-semibold text-charcoal-700 hidden sm:inline">
              Viewing simulated healthcare records [DEMO DATA]. No real personal information is stored.
            </span>
          </div>
          <button
            onClick={logout}
            className="text-[11px] font-bold text-teal-850 hover:text-teal-700 flex items-center gap-1 hover:underline"
          >
            <span>Exit Demo & Sign In</span>
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      <div className="flex-1 flex">
        {/* Sidebar Navigation */}
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-w-0 lg:pl-72 transition-all">
          {/* Top Navbar */}
          <Navbar onToggleSidebar={() => setSidebarOpen(!sidebarOpen)} />

          {/* Page Container */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
            {renderActivePage()}
          </main>
        </div>
      </div>

      {/* Global Modals */}
      <MedicineScannerModal />
      <EmergencyModal />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;
