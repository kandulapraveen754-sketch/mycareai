// ==========================================
// MYCARE AI - AI MEDICINE PHOTO SCANNER
// OCR & Gemini Vision Packaging Identification
// Live Camera, Upload & 1-Click Test Presets
// ==========================================

import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  Upload,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  X,
  ShoppingBag,
  Sparkles,
  Search,
  Eye,
  Info,
  ShieldCheck,
  ChevronRight,
  Maximize2
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { sampleScanPresets, medicineCatalogue } from '../../data/mockData';
import { AIService } from '../../services/aiService';
import { ScannedMedicineResult, MedicineCatalogueItem } from '../../types';
import { triggerConfetti } from '../../utils/confetti';

export const MedicineScannerModal: React.FC = () => {
  const { isScannerOpen, closeScanner, addToCart } = useApp();

  const [activeTab, setActiveTab] = useState<'presets' | 'upload' | 'camera'>('presets');
  const [selectedImage, setSelectedImage] = useState<string | null>(sampleScanPresets[0].imageUrl);
  const [selectedPresetId, setSelectedPresetId] = useState<string | null>(sampleScanPresets[0].id);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [scanResult, setScanResult] = useState<ScannedMedicineResult | null>(null);
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Auto analyze initial preset on open
  useEffect(() => {
    if (isScannerOpen && !scanResult && selectedPresetId) {
      handleAnalyzePreset(selectedPresetId);
    }
  }, [isScannerOpen]);

  // Clean camera stream on close
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    setCameraError(null);
    setCameraActive(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err: any) {
      console.warn("Camera error:", err);
      setCameraError("Camera access denied or unavailable. You can use Presets or File Upload instead.");
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg');
      setSelectedImage(dataUrl);
      setSelectedPresetId(null);
      stopCamera();
      analyzeImage(dataUrl);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setSelectedImage(dataUrl);
      setSelectedPresetId(null);
      analyzeImage(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyzePreset = async (presetId: string) => {
    const preset = sampleScanPresets.find(p => p.id === presetId);
    if (!preset) return;

    setSelectedPresetId(presetId);
    setSelectedImage(preset.imageUrl);
    setIsProcessing(true);
    setScanResult(null);

    // Simulate AI scanning delay for realistic experience
    setTimeout(async () => {
      const result = await AIService.scanPackagingImage(preset.imageUrl, presetId);
      setScanResult(result);
      setIsProcessing(false);
    }, 900);
  };

  const analyzeImage = async (dataUrl: string) => {
    setIsProcessing(true);
    setScanResult(null);
    setTimeout(async () => {
      const result = await AIService.scanPackagingImage(dataUrl);
      setScanResult(result);
      setIsProcessing(false);
    }, 1100);
  };

  const handleAddToCart = (item: MedicineCatalogueItem) => {
    addToCart(item, 1);
    triggerConfetti(2000);
  };

  if (!isScannerOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-charcoal-900/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-4xl max-h-[92vh] bg-cream-50 rounded-3xl shadow-2xl border border-cream-300 flex flex-col overflow-hidden text-charcoal-800">
        
        {/* Modal Header */}
        <div className="bg-teal-850 px-6 py-4 text-cream-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-mustard-300/20 text-mustard-300 flex items-center justify-center">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-display font-extrabold tracking-tight">AI MEDICINE SCANNER</h2>
                <span className="text-[10px] bg-peach-500 text-white font-bold px-2 py-0.5 rounded-full">
                  Gemini Vision OCR
                </span>
              </div>
              <p className="text-xs text-cream-200">
                Identify medicine packaging, extract dosage strength & compare with pharmacy catalogue
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              stopCamera();
              closeScanner();
            }}
            className="p-2 rounded-full hover:bg-white/10 text-cream-200 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Controls */}
        <div className="px-6 pt-4 border-b border-cream-300 flex items-center gap-2 bg-cream-100/50">
          <button
            onClick={() => {
              stopCamera();
              setActiveTab('presets');
            }}
            className={`px-4 py-2.5 rounded-t-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all ${
              activeTab === 'presets'
                ? 'bg-cream-50 text-teal-850 border-t-2 border-teal-700 shadow-sm'
                : 'text-charcoal-600 hover:text-teal-850'
            }`}
          >
            <Sparkles className="w-4 h-4 text-mustard-500" />
            <span>1-Click Test Samples</span>
          </button>

          <button
            onClick={() => {
              stopCamera();
              setActiveTab('upload');
            }}
            className={`px-4 py-2.5 rounded-t-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all ${
              activeTab === 'upload'
                ? 'bg-cream-50 text-teal-850 border-t-2 border-teal-700 shadow-sm'
                : 'text-charcoal-600 hover:text-teal-850'
            }`}
          >
            <Upload className="w-4 h-4 text-teal-700" />
            <span>Upload Image</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('camera');
              startCamera();
            }}
            className={`px-4 py-2.5 rounded-t-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all ${
              activeTab === 'camera'
                ? 'bg-cream-50 text-teal-850 border-t-2 border-teal-700 shadow-sm'
                : 'text-charcoal-600 hover:text-teal-850'
            }`}
          >
            <Camera className="w-4 h-4 text-peach-500" />
            <span>Live Camera</span>
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          
          {/* Top Panel: Presets or Upload or Camera Feed */}
          {activeTab === 'presets' && (
            <div>
              <p className="text-xs font-bold text-charcoal-500 uppercase tracking-wider mb-2.5">
                Select a sample packaging photo to test AI recognition:
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                {sampleScanPresets.map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => handleAnalyzePreset(preset.id)}
                    className={`p-2.5 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                      selectedPresetId === preset.id
                        ? 'border-teal-700 bg-teal-50/70 ring-2 ring-teal-700/30 shadow-md'
                        : 'border-cream-300 bg-white hover:border-cream-400'
                    }`}
                  >
                    <div className="w-full h-16 rounded-xl overflow-hidden mb-2 bg-cream-200">
                      <img
                        src={preset.imageUrl}
                        alt={preset.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-charcoal-900 truncate">{preset.name}</p>
                      <p className="text-[10px] text-charcoal-500 truncate">{preset.label}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'upload' && (
            <div className="p-6 border-2 border-dashed border-teal-700/40 rounded-3xl bg-cream-100/50 text-center">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
              <div className="w-12 h-12 rounded-full bg-cream-200 text-teal-850 flex items-center justify-center mx-auto mb-3">
                <Upload className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-charcoal-800">
                Click to browse or drop medicine packaging image
              </p>
              <p className="text-xs text-charcoal-500 mt-1">Supports JPG, PNG, WEBP from mobile or computer</p>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="mt-4 px-5 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white text-xs font-bold shadow-md transition-colors"
              >
                Browse Image File
              </button>
            </div>
          )}

          {activeTab === 'camera' && (
            <div className="relative rounded-3xl overflow-hidden bg-black aspect-video max-h-72 flex items-center justify-center">
              <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
              <canvas ref={canvasRef} className="hidden" />

              {cameraError ? (
                <div className="absolute inset-0 bg-charcoal-900/90 text-white p-6 flex flex-col items-center justify-center text-center">
                  <AlertTriangle className="w-8 h-8 text-peach-500 mb-2" />
                  <p className="text-sm font-bold">{cameraError}</p>
                  <button
                    onClick={() => setActiveTab('presets')}
                    className="mt-3 px-4 py-2 rounded-xl bg-peach-500 text-white text-xs font-bold"
                  >
                    Switch to Test Presets
                  </button>
                </div>
              ) : (
                <div className="absolute bottom-4 left-0 right-0 flex justify-center">
                  <button
                    onClick={capturePhoto}
                    className="px-6 py-2.5 rounded-full bg-peach-500 hover:bg-peach-600 text-white font-bold text-sm shadow-xl flex items-center gap-2 transition-transform hover:scale-105"
                  >
                    <Camera className="w-4 h-4" />
                    <span>Capture Packaging</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Image Preview & Laser Scan Animation */}
          {selectedImage && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
              
              {/* Left Column: Image Preview with scanning line */}
              <div className="md:col-span-5">
                <div className="relative rounded-3xl overflow-hidden border border-cream-300 bg-charcoal-900 aspect-square shadow-inner">
                  <img
                    src={selectedImage}
                    alt="Packaging preview"
                    className="w-full h-full object-cover"
                  />
                  {isProcessing && (
                    <div className="absolute inset-0 bg-teal-900/30 flex flex-col items-center justify-center">
                      <div className="w-full h-1 bg-gradient-to-r from-transparent via-mustard-300 to-transparent shadow-glow animate-pulse absolute top-1/2 -translate-y-1/2"></div>
                      <div className="p-3 rounded-2xl bg-charcoal-900/80 text-white text-xs font-bold flex items-center gap-2">
                        <RefreshCw className="w-4 h-4 animate-spin text-mustard-300" />
                        <span>Extracting OCR Text & Packaging Info...</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Right Column: AI Extraction & Catalogue Match Result */}
              <div className="md:col-span-7 space-y-4">
                {isProcessing ? (
                  <div className="p-8 rounded-3xl bg-cream-100 border border-cream-200 text-center space-y-3">
                    <div className="w-12 h-12 rounded-full bg-teal-100 text-teal-850 flex items-center justify-center mx-auto animate-bounce">
                      <Sparkles className="w-6 h-6 text-teal-700" />
                    </div>
                    <h3 className="font-display font-bold text-base text-charcoal-900">
                      AI Analyzing Medicine Packaging...
                    </h3>
                    <p className="text-xs text-charcoal-600 max-w-sm mx-auto">
                      Running OCR text recognition, identifying dosage form, strength, active salts, and searching local pharmacy database.
                    </p>
                  </div>
                ) : scanResult ? (
                  <div className="space-y-4">
                    {/* Confidence header */}
                    <div className="p-4 rounded-2xl bg-white border border-cream-300 shadow-sm flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-display font-bold text-sm text-charcoal-900">
                            Detection Confidence:
                          </span>
                          <span
                            className={`text-xs font-extrabold px-2.5 py-0.5 rounded-full ${
                              scanResult.confidence >= 80
                                ? 'bg-emerald-100 text-emerald-800'
                                : scanResult.confidence >= 50
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {scanResult.confidence}% {scanResult.confidence >= 80 ? 'High' : 'Uncertain'}
                          </span>
                        </div>
                        <p className="text-[11px] text-charcoal-500 mt-0.5">
                          Extracted from packaging front imprint & batch markings
                        </p>
                      </div>

                      {scanResult.confidence < 60 && (
                        <div className="flex items-center gap-1.5 text-xs text-amber-700 font-bold bg-amber-50 px-2.5 py-1 rounded-xl">
                          <AlertTriangle className="w-4 h-4" />
                          <span>Blurry / Partial</span>
                        </div>
                      )}
                    </div>

                    {/* Detected Packaging Specs */}
                    <div className="p-4 rounded-2xl bg-cream-100 border border-cream-300/80 space-y-2">
                      <h4 className="text-xs font-bold text-teal-850 uppercase tracking-wider">
                        Extracted Packaging Details:
                      </h4>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <span className="text-charcoal-400">Detected Name:</span>
                          <p className="font-bold text-charcoal-900">{scanResult.detectedName || 'Unknown'}</p>
                        </div>
                        <div>
                          <span className="text-charcoal-400">Strength:</span>
                          <p className="font-bold text-charcoal-900">{scanResult.detectedStrength || 'Unspecified'}</p>
                        </div>
                        <div>
                          <span className="text-charcoal-400">Manufacturer/Brand:</span>
                          <p className="font-bold text-charcoal-900">{scanResult.detectedBrand || 'Unknown'}</p>
                        </div>
                        <div>
                          <span className="text-charcoal-400">Dosage Form:</span>
                          <p className="font-bold text-charcoal-900">{scanResult.detectedDosageForm || 'Tablet'}</p>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-cream-300">
                        <span className="text-[11px] text-charcoal-400">Raw OCR Text:</span>
                        <p className="text-[11px] font-mono text-charcoal-600 bg-white/70 p-2 rounded-xl mt-1 line-clamp-2">
                          {scanResult.extractedText}
                        </p>
                      </div>
                    </div>

                    {/* Matched Catalogue Product & Ordering Shortcut */}
                    {scanResult.matchedCatalogueItem ? (
                      <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            <span className="text-xs font-bold text-emerald-900">
                              Catalogue Match Found in Pharmacy
                            </span>
                          </div>
                          <span className="text-xs font-extrabold text-emerald-800">
                            ₹{scanResult.matchedCatalogueItem.discountPrice || scanResult.matchedCatalogueItem.price}
                          </span>
                        </div>

                        <div className="flex items-center gap-3">
                          <img
                            src={scanResult.matchedCatalogueItem.image}
                            alt={scanResult.matchedCatalogueItem.name}
                            className="w-12 h-12 rounded-xl object-cover ring-1 ring-emerald-300"
                          />
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-bold text-charcoal-900 truncate">
                              {scanResult.matchedCatalogueItem.name}
                            </p>
                            <p className="text-[11px] text-charcoal-500">
                              {scanResult.matchedCatalogueItem.brand} • {scanResult.matchedCatalogueItem.dosageForm}
                            </p>
                            <p className="text-[10px] text-emerald-700 font-semibold mt-0.5">
                              In Stock ({scanResult.matchedCatalogueItem.stockCount} units available)
                            </p>
                          </div>
                        </div>

                        <button
                          onClick={() => handleAddToCart(scanResult.matchedCatalogueItem!)}
                          className="w-full py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-colors"
                        >
                          <ShoppingBag className="w-4 h-4" />
                          <span>Add Verified Product to Cart</span>
                        </button>
                      </div>
                    ) : (
                      <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200">
                        <div className="flex items-center gap-2 text-amber-900 text-xs font-bold mb-1">
                          <AlertTriangle className="w-4 h-4 text-amber-600" />
                          <span>No Exact Catalogue Match Found</span>
                        </div>
                        <p className="text-xs text-amber-800">
                          The image was too blurry or the medication is not currently stocked in the pharmacy catalogue. Please retake the photo under bright lighting or search manually.
                        </p>
                      </div>
                    )}

                    {/* Medical Safety Mandatory Notice */}
                    <div className="p-3.5 rounded-2xl bg-cream-200/80 border border-cream-300 text-[11px] text-charcoal-600 flex items-start gap-2.5">
                      <ShieldCheck className="w-4 h-4 text-teal-850 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-charcoal-800">Medical Safety Notice: </span>
                        {scanResult.safetyDisclaimer}
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-cream-300 bg-cream-100 flex items-center justify-between text-xs">
          <span className="text-charcoal-500 flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-teal-700" />
            <span>OCR Powered by Google Gemini Vision & Catalogue Matching Engine</span>
          </span>
          <button
            onClick={() => {
              stopCamera();
              closeScanner();
            }}
            className="px-4 py-2 rounded-xl bg-cream-200 hover:bg-cream-300 text-charcoal-800 font-bold transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
