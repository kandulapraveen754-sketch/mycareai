// ==========================================
// MYCARE AI - EMERGENCY SOS MODAL
// Dispatches immediate simulated emergency alert with GPS
// ==========================================

import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  PhoneCall,
  MapPin,
  CheckCircle2,
  X,
  AlertTriangle,
  Send,
  Users,
  Check
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const EmergencyModal: React.FC = () => {
  const {
    isSOSActive,
    emergencyAlert,
    resolveSOS,
    cancelSOS,
    emergencyContacts,
    currentUser
  } = useApp();

  const [countDown, setCountDown] = useState(3);
  const [isHolding, setIsHolding] = useState(false);
  const [resolveNote, setResolveNote] = useState('');
  const [showResolveInput, setShowResolveInput] = useState(false);

  if (!isSOSActive && !emergencyAlert) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border-4 border-red-500 overflow-hidden text-charcoal-800">
        {/* Urgent Header */}
        <div className="bg-red-600 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center animate-bounce">
              <ShieldAlert className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-display font-extrabold tracking-tight">EMERGENCY SOS ACTIVE</h2>
              <p className="text-xs text-red-100 font-medium">Family and Caregiver Alert Triggered</p>
            </div>
          </div>
          <button
            onClick={cancelSOS}
            className="p-2 rounded-full hover:bg-white/20 text-white transition-colors"
            title="Close / Cancel"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5">
          {/* Status Badge */}
          <div className="p-4 rounded-2xl bg-red-50 border border-red-200 flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-full bg-red-600 text-white flex items-center justify-center animate-pulse shrink-0">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-red-900">Alert Dispatched to Emergency Circle</p>
              <p className="text-xs text-red-700">
                Timestamp: {emergencyAlert?.timestamp || 'Just now'} • Status: <span className="font-bold underline">{emergencyAlert?.status || 'Sent'}</span>
              </p>
            </div>
          </div>

          {/* Location details */}
          <div className="p-4 rounded-2xl bg-cream-50 border border-cream-200 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-teal-850 uppercase">
              <MapPin className="w-4 h-4 text-peach-500" />
              <span>Current GPS Location Sent:</span>
            </div>
            <p className="text-sm font-medium text-charcoal-800">
              {emergencyAlert?.location?.address || "Flat 402, Sai Nilayam, Road No. 12, Banjara Hills, Hyderabad"}
            </p>
            <p className="text-[11px] text-charcoal-500">
              Lat: 17.4156° N, Long: 78.4750° E (Accuracy: ± 4 meters)
            </p>
          </div>

          {/* Notified Emergency Contacts */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-bold text-charcoal-700 uppercase flex items-center gap-1.5">
                <Users className="w-4 h-4 text-teal-700" />
                <span>Notified Contacts:</span>
              </span>
              <span className="text-xs text-sage-600 font-bold">SMS & Push Sent</span>
            </div>

            <div className="space-y-2">
              {emergencyContacts.map((contact) => (
                <div
                  key={contact.id}
                  className="p-3 rounded-xl bg-cream-50 border border-cream-300 flex items-center justify-between"
                >
                  <div>
                    <p className="text-xs font-bold text-charcoal-800">{contact.name}</p>
                    <p className="text-[11px] text-charcoal-500">{contact.relation} • {contact.phone}</p>
                  </div>
                  <a
                    href={`tel:${contact.phone}`}
                    className="px-3 py-1.5 rounded-lg bg-teal-850 hover:bg-teal-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>Call Now</span>
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* National Emergency Hotline shortcut */}
          <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
              <div>
                <p className="text-xs font-bold text-amber-900">National Emergency Ambulances (India)</p>
                <p className="text-[11px] text-amber-800">Dial 112 (All Emergencies) or 108 (Free Ambulance)</p>
              </div>
            </div>
            <a
              href="tel:112"
              className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-sm"
            >
              Call 112
            </a>
          </div>

          {/* Resolve / Cancel Actions */}
          <div className="pt-2 border-t border-cream-200 flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => resolveSOS("Patient confirmed safe.")}
              className="flex-1 py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-md transition-all"
            >
              <Check className="w-4 h-4" />
              <span>Mark Patient Safe (Resolve)</span>
            </button>
            <button
              onClick={cancelSOS}
              className="py-3 px-4 rounded-2xl bg-cream-200 hover:bg-cream-300 text-charcoal-700 text-sm font-semibold transition-colors"
            >
              Cancel False Alarm
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
