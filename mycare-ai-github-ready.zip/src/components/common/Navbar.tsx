// ==========================================
// MYCARE AI - TOP NAVIGATION COMPONENT
// Search, Notifications, Language, Emergency SOS, Profile
// ==========================================

import React, { useState } from 'react';
import {
  Menu,
  Search,
  Bell,
  Globe,
  ShieldAlert,
  Sparkles,
  ShoppingBag,
  ChevronDown,
  User,
  Settings,
  Volume2,
  CheckCircle,
  LogOut,
  X
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { LanguageCode, UserRole } from '../../types';

interface NavbarProps {
  onToggleSidebar: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleSidebar }) => {
  const {
    currentUser,
    currentRole,
    switchRole,
    searchQuery,
    setSearchQuery,
    language,
    setLanguage,
    t,
    isElderlyMode,
    setIsElderlyMode,
    cart,
    setActivePage,
    unreadNotificationCount,
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    triggerSOS,
    isSOSActive,
    autoVoiceEnabled,
    setAutoVoiceEnabled,
    isDemoMode,
    logout
  } = useApp();

  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const languages: { code: LanguageCode; name: string; nativeName: string }[] = [
    { code: 'en', name: 'English', nativeName: 'English (India)' },
    { code: 'te', name: 'Telugu', nativeName: 'తెలుగు (Telugu)' },
    { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी (Hindi)' },
  ];

  return (
    <header className="sticky top-0 z-30 bg-cream-100/90 backdrop-blur-md border-b border-cream-300/60 px-4 lg:px-8 py-3.5 transition-all">
      <div className="flex items-center justify-between gap-3 lg:gap-6 max-w-7xl mx-auto">
        {/* Left: Mobile hamburger & Brand */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSidebar}
            className="p-2.5 rounded-xl bg-cream-200 text-teal-850 hover:bg-cream-300 lg:hidden focus:outline-none"
            aria-label="Open sidebar menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Quick elderly mode badge for mobile */}
          <div className="lg:hidden flex items-center gap-2">
            <span className="font-display font-extrabold text-teal-850 text-lg">MyCare</span>
            <span className="text-peach-500 font-bold text-xs bg-peach-100 px-2 py-0.5 rounded-full">AI</span>
          </div>
        </div>

        {/* Center: Search Bar */}
        <div className="flex-1 max-w-md hidden sm:block">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-charcoal-400" />
            <input
              type="text"
              placeholder={t.searchMedicines}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-cream-50 border border-cream-300/80 text-charcoal-800 placeholder-charcoal-400 focus:outline-none focus:ring-2 focus:ring-teal-700/30 focus:border-teal-700 text-sm transition-all shadow-sm"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Right Navigation Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick SOS Trigger Button */}
          <button
            onClick={() => triggerSOS(true)}
            className={`px-3 py-2 sm:px-4 sm:py-2.5 rounded-2xl font-display font-bold text-xs sm:text-sm flex items-center gap-2 shadow-md transition-all ${
              isSOSActive
                ? 'bg-red-600 text-white animate-pulse ring-4 ring-red-300 shadow-sos'
                : 'bg-peach-500 hover:bg-peach-600 text-white hover:shadow-lg'
            }`}
          >
            <ShieldAlert className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
            <span className="hidden xs:inline">{isSOSActive ? 'SOS ACTIVE' : 'EMERGENCY SOS'}</span>
            <span className="xs:hidden">SOS</span>
          </button>

          {/* Voice Assistance Auto-Speak Toggle */}
          <button
            onClick={() => setAutoVoiceEnabled(!autoVoiceEnabled)}
            title={autoVoiceEnabled ? "Voice Responses: Enabled" : "Voice Responses: Muted"}
            className={`p-2.5 rounded-2xl border transition-all ${
              autoVoiceEnabled
                ? 'bg-teal-700 text-white border-teal-700 shadow-sm'
                : 'bg-cream-50 text-charcoal-600 border-cream-300 hover:bg-cream-200'
            }`}
          >
            <Volume2 className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          {/* Multilingual Selector */}
          <div className="relative">
            <button
              onClick={() => {
                setShowLangMenu(!showLangMenu);
                setShowNotifications(false);
                setShowProfileMenu(false);
              }}
              className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-cream-50 border border-cream-300 text-charcoal-800 text-xs sm:text-sm font-semibold hover:bg-cream-200 transition-colors shadow-sm"
            >
              <Globe className="w-4 h-4 text-teal-700" />
              <span className="uppercase">{language}</span>
              <ChevronDown className="w-3.5 h-3.5 text-charcoal-400" />
            </button>

            {showLangMenu && (
              <div className="absolute right-0 mt-2 w-52 bg-white rounded-2xl shadow-xl border border-cream-300/80 py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3.5 py-1.5 border-b border-cream-200 text-xs font-bold text-charcoal-400 uppercase">
                  Select Language
                </div>
                {languages.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => {
                      setLanguage(l.code);
                      setShowLangMenu(false);
                    }}
                    className={`w-full px-4 py-2.5 text-left text-sm flex items-center justify-between hover:bg-cream-100 transition-colors ${
                      language === l.code ? 'font-bold text-teal-850 bg-cream-50' : 'text-charcoal-800'
                    }`}
                  >
                    <span>{l.nativeName}</span>
                    {language === l.code && <CheckCircle className="w-4 h-4 text-teal-700" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Pharmacy Cart Button */}
          <button
            onClick={() => setActivePage('ordering')}
            className="relative p-2.5 rounded-2xl bg-cream-50 border border-cream-300 text-charcoal-700 hover:bg-cream-200 transition-colors shadow-sm"
            aria-label="View medicine cart"
          >
            <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5 text-teal-850" />
            {totalCartCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-peach-500 text-white font-bold text-[10px] w-5 h-5 rounded-full flex items-center justify-center ring-2 ring-white shadow-sm">
                {totalCartCount}
              </span>
            )}
          </button>

          {/* Notifications Bell */}
          <div className="relative">
            <button
              onClick={() => {
                setShowNotifications(!showNotifications);
                setShowLangMenu(false);
                setShowProfileMenu(false);
              }}
              className="relative p-2.5 rounded-2xl bg-cream-50 border border-cream-300 text-charcoal-700 hover:bg-cream-200 transition-colors shadow-sm"
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4 sm:w-5 sm:h-5 text-charcoal-800" />
              {unreadNotificationCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-peach-500 text-white font-bold text-[10px] w-5 h-5 rounded-full flex items-center justify-center ring-2 ring-white shadow-sm animate-bounce">
                  {unreadNotificationCount}
                </span>
              )}
            </button>

            {/* Notification Dropdown Panel */}
            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-3xl shadow-2xl border border-cream-300 py-3 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-5 py-2.5 border-b border-cream-200 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-display font-bold text-charcoal-900">Notifications</span>
                    {unreadNotificationCount > 0 && (
                      <span className="bg-peach-100 text-peach-600 text-xs font-bold px-2 py-0.5 rounded-full">
                        {unreadNotificationCount} new
                      </span>
                    )}
                  </div>
                  {unreadNotificationCount > 0 && (
                    <button
                      onClick={markAllNotificationsRead}
                      className="text-xs font-semibold text-teal-700 hover:underline"
                    >
                      Mark all read
                    </button>
                  )}
                </div>

                <div className="max-h-80 overflow-y-auto divide-y divide-cream-100 px-2 py-1">
                  {notifications.length === 0 ? (
                    <p className="text-center py-6 text-xs text-charcoal-400">No notifications.</p>
                  ) : (
                    notifications.map((n) => (
                      <div
                        key={n.id}
                        onClick={() => markNotificationRead(n.id)}
                        className={`p-3.5 rounded-2xl cursor-pointer transition-colors ${
                          !n.read ? 'bg-cream-50 hover:bg-cream-100' : 'hover:bg-cream-50/50 opacity-80'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-xs font-bold text-charcoal-800">{n.title}</p>
                          <span className="text-[10px] text-charcoal-400 whitespace-nowrap">{n.timestamp}</span>
                        </div>
                        <p className="text-xs text-charcoal-600 mt-1">{n.message}</p>
                      </div>
                    ))
                  )}
                </div>

                <div className="p-3 border-t border-cream-200 text-center">
                  <button
                    onClick={() => {
                      setActivePage('notifications');
                      setShowNotifications(false);
                    }}
                    className="text-xs font-bold text-teal-850 hover:text-teal-700"
                  >
                    View All Notifications →
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* User Profile Menu */}
          <div className="relative">
            <button
              onClick={() => {
                setShowProfileMenu(!showProfileMenu);
                setShowLangMenu(false);
                setShowNotifications(false);
              }}
              className="flex items-center gap-2 p-1.5 sm:px-2.5 rounded-2xl bg-cream-50 border border-cream-300 hover:bg-cream-200 transition-colors shadow-sm"
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-7 h-7 sm:w-8 sm:h-8 rounded-full object-cover ring-2 ring-teal-700/30"
              />
              <span className="hidden md:inline text-xs font-bold text-charcoal-800 max-w-[100px] truncate">
                {currentUser.name}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-charcoal-400 hidden sm:inline" />
            </button>

            {showProfileMenu && (
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-3xl shadow-2xl border border-cream-300 py-3 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-5 py-3 border-b border-cream-200">
                  <p className="font-bold text-sm text-charcoal-900">{currentUser.name}</p>
                  <p className="text-xs text-charcoal-500">{currentUser.email}</p>
                  <span className="mt-1.5 inline-block text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-teal-100 text-teal-850">
                    Role: {currentRole}
                  </span>
                </div>

                <div className="px-3 py-2 border-b border-cream-200">
                  <p className="text-[11px] font-bold text-charcoal-400 uppercase px-2 mb-1">Switch Role Demo:</p>
                  {(['elderly', 'family', 'caregiver', 'admin'] as const).map((r) => (
                    <button
                      key={r}
                      onClick={() => {
                        switchRole(r);
                        setShowProfileMenu(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 rounded-xl text-xs font-semibold capitalize flex items-center justify-between ${
                        currentRole === r ? 'bg-cream-200 text-teal-850 font-bold' : 'text-charcoal-700 hover:bg-cream-100'
                      }`}
                    >
                      <span>{r === 'elderly' ? 'Senior Member (Ramesh)' : r === 'family' ? 'Family (Priya)' : r === 'caregiver' ? 'Caregiver (Anjali)' : 'Admin (Dr. Patel)'}</span>
                      {currentRole === r && <CheckCircle className="w-3.5 h-3.5 text-teal-700" />}
                    </button>
                  ))}
                </div>

                <div className="px-2 pt-2 border-t border-cream-200 mt-2 space-y-1">
                  <button
                    onClick={() => {
                      setActivePage('settings');
                      setShowProfileMenu(false);
                    }}
                    className="w-full text-left px-4 py-2 rounded-xl text-xs font-medium text-charcoal-700 hover:bg-cream-100 flex items-center gap-2"
                  >
                    <Settings className="w-4 h-4 text-charcoal-500" />
                    <span>Settings & Profile</span>
                  </button>

                  <button
                    onClick={() => {
                      setShowProfileMenu(false);
                      if (window.confirm('Are you sure you want to sign out of MyCare AI?')) {
                        logout();
                      }
                    }}
                    className="w-full text-left px-4 py-2 rounded-xl text-xs font-bold text-red-600 hover:bg-red-50 flex items-center gap-2 transition-colors"
                  >
                    <LogOut className="w-4 h-4 text-red-500" />
                    <span>{isDemoMode ? 'Exit Demo' : 'Sign Out / Logout'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
