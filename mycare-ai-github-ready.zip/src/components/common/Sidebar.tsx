// ==========================================
// MYCARE AI - DEEP TEAL SIDEBAR COMPONENT
// Color: #174F4A deep teal background
// Elegant rounded corners, accessible icons & typography
// ==========================================

import React from 'react';
import {
  LayoutDashboard,
  HeartPulse,
  Pill,
  ShoppingBag,
  Sparkles,
  Calendar,
  Users,
  BarChart3,
  ShieldAlert,
  Bell,
  Settings,
  LogOut,
  ChevronRight,
  Eye,
  Volume2
} from 'lucide-react';
import { useApp, NavigationPage } from '../../context/AppContext';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const {
    activePage,
    setActivePage,
    t,
    currentRole,
    currentUser,
    switchRole,
    isElderlyMode,
    setIsElderlyMode,
    unreadNotificationCount,
    isSOSActive,
    isDemoMode,
    logout
  } = useApp();

  const navItems: {
    id: NavigationPage;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number | string;
    isDanger?: boolean;
    isAi?: boolean;
  }[] = [
    { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
    { id: 'health', label: t.myHealth, icon: HeartPulse },
    { id: 'medicines', label: t.medicines, icon: Pill },
    { id: 'ordering', label: t.medicineOrdering, icon: ShoppingBag },
    { id: 'guardian', label: t.aiGuardian, icon: Sparkles, isAi: true },
    { id: 'appointments', label: t.doctorAppointments, icon: Calendar },
    { id: 'family', label: t.familyCircle, icon: Users },
    { id: 'insights', label: t.healthInsights, icon: BarChart3 },
    { id: 'emergency', label: t.emergencySos, icon: ShieldAlert, isDanger: true },
    { id: 'notifications', label: t.notifications, icon: Bell, badge: unreadNotificationCount > 0 ? unreadNotificationCount : undefined },
    { id: 'settings', label: t.settings, icon: Settings },
  ];

  const handleNavClick = (page: NavigationPage) => {
    setActivePage(page);
    onClose();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-charcoal-900/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 bg-teal-850 text-cream-50 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } shadow-2xl lg:shadow-none border-r border-teal-900/40`}
      >
        {/* Brand Header */}
        <div className="p-6 border-b border-teal-700/30 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-cream-100 flex items-center justify-center p-2 shadow-md ring-2 ring-mustard-300/40">
              <img src="/logo.svg" alt="MyCare AI Logo" className="w-full h-full object-contain" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-display font-extrabold text-xl tracking-tight text-cream-50">
                  MyCare <span className="text-mustard-300">AI</span>
                </span>
              </div>
              <p className="text-[11px] text-cream-200/80 font-medium tracking-wide">
                Your Health. Care. Family.
              </p>
            </div>
          </div>
        </div>

        {/* Elderly Mode Quick Toggle Banner */}
        <div className="px-5 pt-4 pb-2">
          <button
            onClick={() => setIsElderlyMode(!isElderlyMode)}
            className={`w-full py-2.5 px-3.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-all ${
              isElderlyMode
                ? 'bg-sage-100 text-teal-900 ring-2 ring-sage-300'
                : 'bg-teal-900/70 text-cream-200 hover:bg-teal-700/50'
            }`}
          >
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-peach-500" />
              <span>Elderly Friendly Mode</span>
            </div>
            <span
              className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                isElderlyMode ? 'bg-teal-700 text-cream-50' : 'bg-teal-800 text-cream-300'
              }`}
            >
              {isElderlyMode ? 'ON' : 'OFF'}
            </span>
          </button>
        </div>

        {/* Navigation Menu */}
        <nav aria-label="Main Navigation" className="flex-1 overflow-y-auto px-4 py-3 space-y-1.5 scrollbar-thin scrollbar-thumb-teal-700">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                aria-current={isActive ? 'page' : undefined}
                aria-label={item.label}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl font-medium text-sm transition-all duration-200 group focus:outline-none focus:ring-2 focus:ring-mustard-300 ${
                  isActive
                    ? 'bg-teal-700 text-cream-50 shadow-md font-semibold ring-1 ring-white/10'
                    : item.isDanger && isSOSActive
                    ? 'bg-peach-600 text-white animate-pulse font-bold'
                    : 'text-cream-200/90 hover:bg-teal-900/60 hover:text-cream-50'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
                      isActive
                        ? 'bg-white/20 text-mustard-300'
                        : item.isAi
                        ? 'bg-mustard-300/20 text-mustard-300 group-hover:bg-mustard-300/30'
                        : item.isDanger
                        ? 'bg-peach-500/20 text-peach-200 group-hover:bg-peach-500/30'
                        : 'bg-teal-900/50 text-cream-300 group-hover:bg-teal-700/50 group-hover:text-cream-50'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className={`text-left tracking-wide ${isElderlyMode ? 'text-base' : 'text-sm'}`}>
                    {item.label}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {item.badge !== undefined && (
                    <span className="bg-peach-500 text-white text-[11px] font-bold px-2 py-0.5 rounded-full shadow-sm">
                      {item.badge}
                    </span>
                  )}
                  {item.isAi && !isActive && (
                    <span className="text-[10px] bg-mustard-300/20 text-mustard-200 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">
                      AI
                    </span>
                  )}
                  {isActive && <ChevronRight className="w-4 h-4 text-mustard-300" />}
                </div>
              </button>
            );
          })}
        </nav>

        {/* Active Role & Profile Card */}
        <div className="p-3.5 mx-4 mb-3 rounded-2xl bg-teal-900/70 border border-teal-700/40">
          <div className="flex items-center gap-3 mb-2">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-peach-400"
            />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <p className="text-xs font-bold text-cream-50 truncate">{currentUser.name}</p>
                {isDemoMode && (
                  <span className="text-[9px] bg-peach-500/90 text-white font-extrabold px-1.5 py-0.2 rounded shrink-0">
                    DEMO
                  </span>
                )}
              </div>
              <p className="text-[11px] text-mustard-300 font-medium capitalize flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-sage-300"></span>
                {currentRole === 'elderly'
                  ? 'Senior Member'
                  : currentRole === 'family'
                  ? 'Family Guardian'
                  : currentRole === 'caregiver'
                  ? 'Care Nurse'
                  : 'Administrator'}
              </p>
            </div>
          </div>

          {isDemoMode ? (
            <div className="pt-2 border-t border-teal-700/30">
              <label className="text-[10px] font-bold text-cream-300 uppercase tracking-wider block mb-1">
                Switch Demo Persona:
              </label>
              <div className="grid grid-cols-4 gap-1 text-[10px]">
                {(['elderly', 'family', 'caregiver', 'admin'] as const).map((r) => (
                  <button
                    key={r}
                    onClick={() => switchRole(r)}
                    className={`py-1 rounded text-center font-bold capitalize transition-colors ${
                      currentRole === r
                        ? 'bg-peach-500 text-white shadow-sm'
                        : 'bg-teal-850 text-cream-300 hover:bg-teal-750 hover:text-white'
                    }`}
                  >
                    {r === 'elderly' ? 'Senior' : r}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="pt-2 border-t border-teal-700/30 text-[11px] text-cream-200/80 truncate">
              <span>{currentUser.email}</span>
            </div>
          )}

          {/* Logout Action */}
          <button
            onClick={() => {
              if (window.confirm('Are you sure you want to sign out of MyCare AI?')) {
                logout();
              }
            }}
            className="w-full mt-2.5 py-2 px-3 rounded-xl bg-teal-850 hover:bg-red-950/60 hover:text-red-300 text-cream-200 text-xs font-bold flex items-center justify-center gap-2 border border-teal-700/50 transition-all shadow-xs"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{isDemoMode ? 'Exit Demo Session' : 'Sign Out / Logout'}</span>
          </button>
        </div>

        {/* Footer info */}
        <div className="px-6 py-3 border-t border-teal-900/50 flex items-center justify-between text-[11px] text-cream-300/70">
          <span>MyCare AI v1.0</span>
          <span className="text-sage-300 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            System Online
          </span>
        </div>
      </aside>
    </>
  );
};
