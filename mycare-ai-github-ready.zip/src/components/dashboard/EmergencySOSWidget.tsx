// ==========================================
// MYCARE AI - DASHBOARD EMERGENCY SOS WIDGET
// Large SOS Button, Emergency Contacts, Status
// ==========================================

import React, { useState } from 'react';
import {
  ShieldAlert,
  PhoneCall,
  MapPin,
  AlertTriangle,
  Send,
  Users
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const EmergencySOSWidget: React.FC = () => {
  const { triggerSOS, isSOSActive, emergencyContacts, t, setActivePage } = useApp();
  const [isPressing, setIsPressing] = useState(false);

  const primaryContact = emergencyContacts.find(c => c.isPrimary) || emergencyContacts[0];

  return (
    <div className="rounded-3xl bg-gradient-to-br from-peach-50 via-white to-peach-100/60 border border-peach-200 p-6 shadow-card space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-peach-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-peach-500 text-white flex items-center justify-center shadow-sm">
            <ShieldAlert className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-display font-bold text-charcoal-900">
              {t.emergencyShield} & Immediate SOS
            </h2>
            <p className="text-xs text-charcoal-600">
              Instant multi-channel emergency alert with real-time GPS
            </p>
          </div>
        </div>

        <button
          onClick={() => setActivePage('emergency')}
          className="text-xs font-bold text-peach-700 hover:text-peach-800"
        >
          Shield View →
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
        {/* Left Column: Big SOS Button */}
        <div className="md:col-span-5 flex flex-col items-center text-center p-3">
          <button
            onClick={() => triggerSOS(true)}
            className={`w-36 h-36 rounded-full flex flex-col items-center justify-center font-display font-black text-white shadow-2xl transition-all transform hover:scale-105 active:scale-95 ${
              isSOSActive
                ? 'bg-red-600 ring-8 ring-red-300 shadow-sos animate-pulse'
                : 'bg-gradient-to-tr from-peach-600 via-peach-500 to-terracotta ring-4 ring-peach-300/60 hover:shadow-peach-500/40'
            }`}
          >
            <ShieldAlert className="w-10 h-10 mb-1" />
            <span className="text-lg tracking-wider">
              {isSOSActive ? "ACTIVE" : "SOS"}
            </span>
            <span className="text-[10px] font-bold text-peach-100 tracking-normal">
              {isSOSActive ? "ALERT SENT" : "PRESS FOR HELP"}
            </span>
          </button>
          <p className="text-[11px] text-charcoal-500 mt-3 font-medium">
            Notifies daughter Priya (+91 99887 65432) & Sister Anjali
          </p>
        </div>

        {/* Right Column: Quick Dial Shortcuts */}
        <div className="md:col-span-7 space-y-2.5">
          <p className="text-xs font-bold text-charcoal-500 uppercase tracking-wider">
            Quick Emergency Call Shortcuts:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {emergencyContacts.slice(0, 4).map((c) => (
              <a
                key={c.id}
                href={`tel:${c.phone}`}
                className="p-3 rounded-2xl bg-white border border-cream-300 hover:border-peach-400 hover:shadow-sm transition-all flex items-center justify-between group"
              >
                <div className="min-w-0 pr-2">
                  <p className="text-xs font-bold text-charcoal-900 truncate">{c.name}</p>
                  <p className="text-[11px] text-charcoal-500 truncate">{c.relation}</p>
                </div>
                <div className="w-8 h-8 rounded-xl bg-peach-100 group-hover:bg-peach-500 text-peach-600 group-hover:text-white flex items-center justify-center transition-colors shrink-0">
                  <PhoneCall className="w-4 h-4" />
                </div>
              </a>
            ))}
          </div>

          <div className="p-3 rounded-2xl bg-white/80 border border-peach-200 text-[11px] text-charcoal-600 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-peach-600 shrink-0" />
            <span>
              For critical medical emergencies, call national services at <strong className="text-charcoal-900">112</strong> or hospital at <strong className="text-charcoal-900">1066</strong>.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
