// ==========================================
// MYCARE AI - TODAY'S MEDICINES COMPONENT
// Daily schedule, Taken/Pending/Skipped tracking,
// Confetti celebration, Skip modal with reasons
// ==========================================

import React, { useState } from 'react';
import {
  Pill,
  CheckCircle2,
  Clock,
  AlertCircle,
  Plus,
  ChevronRight,
  Sparkles,
  X,
  Check
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ScheduledDose } from '../../types';

export const TodayMedicinesCard: React.FC = () => {
  const { todayDoses, markDoseTaken, skipDose, setActivePage, isElderlyMode, t } = useApp();

  const [skipModalDose, setSkipModalDose] = useState<ScheduledDose | null>(null);
  const [skipReason, setSkipReason] = useState<string>('Nausea / Stomach discomfort');
  const [customReason, setCustomReason] = useState<string>('');

  const handleSkipConfirm = () => {
    if (!skipModalDose) return;
    const finalReason = customReason.trim() ? customReason : skipReason;
    skipDose(skipModalDose.id, finalReason);
    setSkipModalDose(null);
    setCustomReason('');
  };

  const getStatusBadge = (status: ScheduledDose['status']) => {
    switch (status) {
      case 'taken':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{t.taken}</span>
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300">
            <Clock className="w-3.5 h-3.5" />
            <span>{t.pending}</span>
          </span>
        );
      case 'skipped':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-charcoal-200 text-charcoal-700 border border-charcoal-300">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>{t.skipped}</span>
          </span>
        );
      case 'missed':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-800 border border-red-300">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>{t.missed}</span>
          </span>
        );
    }
  };

  return (
    <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-cream-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-sage-100 text-teal-850 flex items-center justify-center">
            <Pill className="w-5 h-5 text-teal-700" />
          </div>
          <div>
            <h2 className="text-lg font-display font-bold text-charcoal-900">
              {t.todaysMedicines}
            </h2>
            <p className="text-xs text-charcoal-500">
              Mark doses accurately to update family and adherence records
            </p>
          </div>
        </div>

        <button
          onClick={() => setActivePage('medicines')}
          className="text-xs font-bold text-teal-850 hover:text-teal-700 flex items-center gap-1"
        >
          <span>All Medicines</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Doses List */}
      <div className="space-y-3">
        {todayDoses.map((dose) => (
          <div
            key={dose.id}
            className={`p-4 rounded-2xl border transition-all ${
              dose.status === 'taken'
                ? 'bg-cream-50/70 border-emerald-200/80'
                : dose.status === 'pending'
                ? 'bg-white border-cream-300 hover:border-teal-700/50 shadow-sm'
                : 'bg-cream-100/50 border-cream-300 opacity-75'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              {/* Medicine details */}
              <div className="flex items-start gap-3.5 min-w-0">
                <div
                  className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-sm"
                  style={{ backgroundColor: dose.colorTag || '#DDE8D7' }}
                >
                  <Pill className="w-5 h-5 text-charcoal-800" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className={`font-bold text-charcoal-900 ${isElderlyMode ? 'text-base' : 'text-sm'}`}>
                      {dose.medicineName}
                    </h3>
                    <span className="text-xs font-semibold text-charcoal-500 bg-cream-200 px-2 py-0.5 rounded-md">
                      {dose.strength} • {dose.dosage}
                    </span>
                  </div>
                  <p className="text-xs text-charcoal-600 mt-0.5">{dose.instructions}</p>
                  <div className="flex items-center gap-3 mt-1.5 text-xs text-charcoal-500">
                    <span className="flex items-center gap-1 font-medium text-teal-850">
                      <Clock className="w-3.5 h-3.5 text-teal-700" />
                      <span>{dose.scheduledTime} ({dose.timeSlot})</span>
                    </span>
                    {dose.takenAt && (
                      <span className="text-emerald-700 font-semibold">
                        ✓ Taken at {dose.takenAt}
                      </span>
                    )}
                    {dose.skippedReason && (
                      <span className="text-charcoal-500 italic">
                        Reason: {dose.skippedReason}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Status and Action Buttons */}
              <div className="flex items-center gap-2.5 shrink-0 self-end sm:self-center">
                {getStatusBadge(dose.status)}

                {dose.status === 'pending' && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => markDoseTaken(dose.id)}
                      className="px-4 py-2 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-sm transition-all hover:scale-105"
                    >
                      <Check className="w-4 h-4" />
                      <span>{t.markAsTaken}</span>
                    </button>
                    <button
                      onClick={() => setSkipModalDose(dose)}
                      className="px-3 py-2 rounded-xl bg-cream-200 hover:bg-cream-300 text-charcoal-700 font-semibold text-xs transition-colors"
                    >
                      <span>Skip</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Skip Dose Modal */}
      {skipModalDose && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-cream-300 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-cream-200">
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Skip Dose: {skipModalDose.medicineName}
              </h3>
              <button
                onClick={() => setSkipModalDose(null)}
                className="p-1 rounded-full text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-charcoal-600">
              Please select or enter the clinical reason for skipping this dose. This will be logged in adherence reports and shared with your caregiver.
            </p>

            <div className="space-y-2">
              {[
                "Nausea / Stomach discomfort",
                "Fast or empty stomach required",
                "Advised by doctor / nurse to pause",
                "Forgot / delayed past window",
                "Medicine ran out of stock"
              ].map((reason) => (
                <label
                  key={reason}
                  className={`flex items-center gap-2.5 p-2.5 rounded-xl border cursor-pointer text-xs transition-colors ${
                    skipReason === reason ? 'border-teal-700 bg-cream-100 font-bold' : 'border-cream-300 hover:bg-cream-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="skipReason"
                    checked={skipReason === reason}
                    onChange={() => setSkipReason(reason)}
                    className="text-teal-700 focus:ring-teal-700"
                  />
                  <span>{reason}</span>
                </label>
              ))}
            </div>

            <div>
              <label className="text-xs font-semibold text-charcoal-700 block mb-1">
                Other Note (Optional):
              </label>
              <input
                type="text"
                placeholder="Type additional details..."
                value={customReason}
                onChange={(e) => setCustomReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700 focus:outline-none"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={handleSkipConfirm}
                className="flex-1 py-2.5 rounded-xl bg-peach-500 hover:bg-peach-600 text-white font-bold text-xs shadow-sm transition-colors"
              >
                Confirm Skip
              </button>
              <button
                onClick={() => setSkipModalDose(null)}
                className="px-4 py-2.5 rounded-xl bg-cream-200 text-charcoal-700 font-semibold text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
