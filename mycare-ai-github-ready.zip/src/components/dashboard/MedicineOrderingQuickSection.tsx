// ==========================================
// MYCARE AI - DASHBOARD MEDICINE ORDERING QUICK SECTION
// Browse popular medications, scan button, add to cart
// ==========================================

import React from 'react';
import {
  ShoppingBag,
  Camera,
  Plus,
  Check,
  ChevronRight,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { triggerConfetti } from '../../utils/confetti';

export const MedicineOrderingQuickSection: React.FC = () => {
  const { catalogue, addToCart, cart, setActivePage, openScanner, t } = useApp();

  const previewItems = catalogue.slice(0, 4);

  const handleAdd = (item: typeof catalogue[0]) => {
    addToCart(item, 1);
    triggerConfetti(1500);
  };

  return (
    <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-cream-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-peach-100 text-peach-600 flex items-center justify-center">
            <ShoppingBag className="w-5 h-5 text-peach-500" />
          </div>
          <div>
            <h2 className="text-lg font-display font-bold text-charcoal-900">
              {t.medicineOrdering} & Senior Pharmacy
            </h2>
            <p className="text-xs text-charcoal-500">
              Prescription verification, doorstep delivery & packaging scan
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Prominent Scan Medicine Photo Button */}
          <button
            onClick={openScanner}
            className="px-3.5 py-2 rounded-xl bg-mustard-300 hover:bg-mustard-200 text-charcoal-900 font-display font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all hover:scale-105"
          >
            <Camera className="w-4 h-4 text-teal-850" />
            <span>{t.scanMedicine}</span>
          </button>

          <button
            onClick={() => setActivePage('ordering')}
            className="text-xs font-bold text-teal-850 hover:text-teal-700 flex items-center gap-1"
          >
            <span>Full Store</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Grid of Medicines */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {previewItems.map((item) => {
          const inCart = cart.find(c => c.medicine.id === item.id);
          return (
            <div
              key={item.id}
              className="p-3.5 rounded-2xl border border-cream-300 bg-cream-50/50 hover:bg-white hover:border-teal-700/40 hover:shadow-card-hover transition-all flex flex-col justify-between"
            >
              <div>
                <div className="relative w-full h-28 rounded-xl overflow-hidden mb-2.5 bg-cream-200">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                  {item.prescriptionRequired && (
                    <span className="absolute top-2 left-2 text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-peach-500 text-white shadow-sm">
                      Rx Required
                    </span>
                  )}
                </div>

                <p className="text-xs font-bold text-charcoal-900 line-clamp-1">{item.name}</p>
                <p className="text-[11px] text-charcoal-500 truncate">{item.brand} • {item.strength}</p>
              </div>

              <div className="mt-3 pt-2.5 border-t border-cream-200 flex items-center justify-between">
                <div>
                  <span className="text-xs font-extrabold text-teal-850">
                    ₹{item.discountPrice || item.price}
                  </span>
                  {item.discountPrice && (
                    <span className="text-[10px] text-charcoal-400 line-through ml-1.5">
                      ₹{item.price}
                    </span>
                  )}
                </div>

                <button
                  onClick={() => handleAdd(item)}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1 transition-all ${
                    inCart
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-teal-850 hover:bg-teal-700 text-white'
                  }`}
                >
                  {inCart ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>In Cart ({inCart.quantity})</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
