// ==========================================
// MYCARE AI - DASHBOARD WELCOME BANNER
// Warm elderly photograph, personalized greeting,
// health status, quick access to AI Guardian
// ==========================================

import React from 'react';
import {
  Sparkles,
  HeartPulse,
  Clock,
  ArrowRight,
  ShieldCheck,
  Calendar
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const WelcomeBanner: React.FC = () => {
  const { currentUser, t, setActivePage, openScanner } = useApp();

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return t.goodMorning;
    if (hour < 17) return t.goodAfternoon;
    return t.goodEvening;
  };

  const todayFormatted = new Date().toLocaleDateString('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-teal-850 via-teal-900 to-teal-850 text-cream-50 p-6 sm:p-8 shadow-card border border-teal-700/40">
      {/* Decorative background glow rings */}
      <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-teal-700/20 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/3 -mb-20 w-60 h-60 rounded-full bg-mustard-300/10 blur-2xl pointer-events-none" />

      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* Left Column: Greeting & Health Safety Note */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-cream-100/10 text-mustard-300 border border-mustard-300/30 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              <span>{todayFormatted}</span>
            </span>

            <span className="text-xs font-semibold px-3 py-1 rounded-full bg-sage-600/30 text-sage-200 border border-sage-500/30 flex items-center gap-1.5">
              <HeartPulse className="w-3.5 h-3.5 text-sage-300" />
              <span>Vitals Stable: 126/82 mmHg</span>
            </span>
          </div>

          <div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-display font-extrabold tracking-tight text-cream-50 leading-tight">
              {getGreeting()}, <span className="text-mustard-300">{currentUser.name}</span>
            </h1>
            <p className="text-sm sm:text-base text-cream-200/90 font-medium mt-1.5 max-w-xl">
              {t.healthSafetyNote}
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => setActivePage('guardian')}
              className="px-5 py-3 rounded-2xl bg-mustard-300 hover:bg-mustard-200 text-charcoal-900 font-display font-bold text-sm shadow-md flex items-center gap-2.5 transition-all transform hover:scale-[1.02]"
            >
              <Sparkles className="w-4 h-4 text-teal-850" />
              <span>{t.askGuardian}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={openScanner}
              className="px-5 py-3 rounded-2xl bg-teal-700/60 hover:bg-teal-700 text-cream-50 font-bold text-sm border border-teal-600/60 shadow-sm flex items-center gap-2 transition-all"
            >
              <span>{t.scanMedicine}</span>
            </button>

            <button
              onClick={() => setActivePage('medicines')}
              className="px-4 py-3 rounded-2xl bg-cream-50/10 hover:bg-cream-50/20 text-cream-200 font-semibold text-sm transition-all"
            >
              <span>View All Medicines</span>
            </button>
          </div>
        </div>

        {/* Right Column: Realistic warm elderly-care photograph */}
        <div className="lg:col-span-4 flex justify-center lg:justify-end">
          <div className="relative w-44 sm:w-52 h-44 sm:h-52 rounded-3xl overflow-hidden shadow-2xl ring-4 ring-white/20 transform rotate-1 hover:rotate-0 transition-transform duration-300">
            <img
              src="https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?auto=format&fit=crop&w=500&q=80"
              alt="Elderly Care Wellness"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-teal-950/80 via-transparent to-transparent flex items-end p-3.5">
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-cream-100">
                <ShieldCheck className="w-3.5 h-3.5 text-sage-300" />
                <span>Protected by MyCare AI Circle</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
