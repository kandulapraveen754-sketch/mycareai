// ==========================================
// MYCARE AI - DASHBOARD RECENT ACTIVITY TIMELINE
// Medicine confirmations, caregiver actions, appointments
// ==========================================

import React from 'react';
import {
  Clock,
  Pill,
  Calendar,
  HeartPulse,
  CheckCircle2,
  ShoppingBag,
  ShieldAlert,
  ChevronRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const RecentActivitySection: React.FC = () => {
  const { activityLogs, setActivePage } = useApp();

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Pill':
        return <Pill className="w-4 h-4 text-emerald-600" />;
      case 'Calendar':
        return <Calendar className="w-4 h-4 text-teal-700" />;
      case 'HeartPulse':
        return <HeartPulse className="w-4 h-4 text-peach-500" />;
      case 'ShoppingBag':
        return <ShoppingBag className="w-4 h-4 text-mustard-600" />;
      case 'ShieldAlert':
        return <ShieldAlert className="w-4 h-4 text-red-600" />;
      default:
        return <CheckCircle2 className="w-4 h-4 text-teal-700" />;
    }
  };

  return (
    <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-cream-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-cream-100 text-teal-850 flex items-center justify-center">
            <Clock className="w-5 h-5 text-teal-700" />
          </div>
          <div>
            <h2 className="text-lg font-display font-bold text-charcoal-900">
              Recent Care Activity & Audit Trail
            </h2>
            <p className="text-xs text-charcoal-500">
              Logged actions by patient, daughter Priya, and Sister Anjali
            </p>
          </div>
        </div>
      </div>

      {/* Activity Timeline List */}
      <div className="space-y-3">
        {activityLogs.slice(0, 5).map((log) => (
          <div
            key={log.id}
            className="p-3.5 rounded-2xl bg-cream-50/60 border border-cream-200 flex items-start gap-3 hover:bg-cream-50 transition-colors"
          >
            <div className="w-8 h-8 rounded-xl bg-white border border-cream-300 flex items-center justify-center shrink-0 shadow-sm mt-0.5">
              {getIcon(log.icon)}
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <p className="text-xs font-bold text-charcoal-900">{log.title}</p>
                <span className="text-[10px] text-charcoal-400 whitespace-nowrap">{log.time}</span>
              </div>
              <p className="text-xs text-charcoal-600 mt-0.5">{log.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
