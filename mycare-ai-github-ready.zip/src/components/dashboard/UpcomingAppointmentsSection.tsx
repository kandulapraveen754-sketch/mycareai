// ==========================================
// MYCARE AI - UPCOMING APPOINTMENTS SECTION
// Doctor profiles, scheduled dates, statuses, booking actions
// ==========================================

import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  Video,
  ChevronRight,
  AlertCircle,
  Plus,
  CheckCircle2,
  X
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Appointment } from '../../types';

export const UpcomingAppointmentsSection: React.FC = () => {
  const { appointments, cancelAppointment, rescheduleAppointment, setActivePage, t } = useApp();

  const [rescheduleApt, setRescheduleApt] = useState<Appointment | null>(null);
  const [newDate, setNewDate] = useState('2026-11-20');
  const [newSlot, setNewSlot] = useState('11:00 AM');

  const upcoming = appointments.filter(a => a.status === 'Confirmed' || a.status === 'Rescheduled');

  const handleRescheduleSubmit = () => {
    if (!rescheduleApt) return;
    rescheduleAppointment(rescheduleApt.id, newDate, newSlot);
    setRescheduleApt(null);
  };

  return (
    <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-cream-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-peach-100 text-peach-600 flex items-center justify-center">
            <Calendar className="w-5 h-5 text-peach-500" />
          </div>
          <div>
            <h2 className="text-lg font-display font-bold text-charcoal-900">
              {t.nextAppointment} & Consultations
            </h2>
            <p className="text-xs text-charcoal-500">
              Verified clinical consultations and video sessions
            </p>
          </div>
        </div>

        <button
          onClick={() => setActivePage('appointments')}
          className="px-3.5 py-1.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{t.bookDoctor}</span>
        </button>
      </div>

      {/* Appointments List */}
      {upcoming.length === 0 ? (
        <div className="text-center py-8 bg-cream-50 rounded-2xl border border-cream-200">
          <Calendar className="w-8 h-8 text-charcoal-400 mx-auto mb-2" />
          <p className="text-sm font-bold text-charcoal-700">No Upcoming Appointments</p>
          <p className="text-xs text-charcoal-500 mt-1">Schedule a routine consultation with a geriatric specialist</p>
          <button
            onClick={() => setActivePage('appointments')}
            className="mt-3 px-4 py-2 rounded-xl bg-teal-850 text-white font-bold text-xs"
          >
            Find a Doctor
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {upcoming.map((apt) => (
            <div
              key={apt.id}
              className="p-4 rounded-2xl border border-cream-300 bg-cream-50/60 hover:bg-cream-50 hover:border-teal-700/40 transition-all flex flex-col justify-between space-y-3"
            >
              <div className="flex items-start gap-3">
                <img
                  src={apt.doctorImage}
                  alt={apt.doctorName}
                  className="w-12 h-12 rounded-2xl object-cover ring-2 ring-peach-300 shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <h3 className="font-bold text-sm text-charcoal-900 truncate">
                      {apt.doctorName}
                    </h3>
                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      {apt.status}
                    </span>
                  </div>
                  <p className="text-xs text-peach-600 font-semibold truncate">{apt.specialization}</p>
                  <p className="text-[11px] text-charcoal-500 flex items-center gap-1 mt-1 truncate">
                    <MapPin className="w-3 h-3 text-teal-700 shrink-0" />
                    <span>{apt.hospital}</span>
                  </p>
                </div>
              </div>

              {/* Consultation Date & Type Pill */}
              <div className="p-3 rounded-xl bg-white border border-cream-200 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-charcoal-800 font-bold">
                  <Clock className="w-3.5 h-3.5 text-teal-700" />
                  <span>{apt.date} at {apt.time}</span>
                </div>
                <span className="flex items-center gap-1 text-[11px] font-semibold text-teal-850 bg-teal-50 px-2 py-0.5 rounded-md">
                  {apt.type === 'Video Consultation' ? <Video className="w-3 h-3 text-teal-700" /> : null}
                  <span>{apt.type}</span>
                </span>
              </div>

              {/* Actions: Reschedule & Cancel */}
              <div className="pt-2 border-t border-cream-200 flex items-center justify-between text-xs">
                <button
                  onClick={() => setRescheduleApt(apt)}
                  className="font-bold text-teal-850 hover:text-teal-700 hover:underline"
                >
                  Reschedule
                </button>
                <button
                  onClick={() => cancelAppointment(apt.id)}
                  className="text-charcoal-500 hover:text-red-600 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Reschedule Modal */}
      {rescheduleApt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-cream-300 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-cream-200">
              <h3 className="font-display font-bold text-base text-charcoal-900">
                Reschedule: {rescheduleApt.doctorName}
              </h3>
              <button
                onClick={() => setRescheduleApt(null)}
                className="p-1 rounded-full text-charcoal-400 hover:text-charcoal-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">
                  Select New Date:
                </label>
                <input
                  type="date"
                  value={newDate}
                  min={new Date().toISOString().split('T')[0]}
                  onChange={(e) => setNewDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-charcoal-700 block mb-1">
                  Select Available Time Slot:
                </label>
                <select
                  value={newSlot}
                  onChange={(e) => setNewSlot(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-cream-300 text-xs focus:ring-2 focus:ring-teal-700"
                >
                  <option value="09:30 AM">09:30 AM</option>
                  <option value="11:00 AM">11:00 AM</option>
                  <option value="02:30 PM">02:30 PM</option>
                  <option value="04:00 PM">04:00 PM</option>
                  <option value="05:30 PM">05:30 PM</option>
                </select>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={handleRescheduleSubmit}
                className="flex-1 py-2.5 rounded-xl bg-teal-850 hover:bg-teal-700 text-white font-bold text-xs shadow-sm"
              >
                Confirm Reschedule
              </button>
              <button
                onClick={() => setRescheduleApt(null)}
                className="px-4 py-2.5 rounded-xl bg-cream-200 text-charcoal-700 font-semibold text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
