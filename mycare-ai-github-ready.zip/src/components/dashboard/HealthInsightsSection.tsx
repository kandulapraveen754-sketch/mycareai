// ==========================================
// MYCARE AI - DASHBOARD HEALTH INSIGHTS SECTION
// 7-day adherence chart & vital signs tracker
// ==========================================

import React from 'react';
import {
  BarChart3,
  TrendingUp,
  HeartPulse,
  Activity,
  Droplet,
  ChevronRight
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip
} from 'recharts';
import { useApp } from '../../context/AppContext';
import { weeklyAdherenceData } from '../../data/mockData';

export const HealthInsightsSection: React.FC = () => {
  const { vitals, setActivePage, t } = useApp();

  const latestVital = vitals[0] || {
    bloodPressureSystolic: 126,
    bloodPressureDiastolic: 82,
    heartRate: 72,
    bloodGlucose: 118,
    spo2: 98
  };

  return (
    <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-cream-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-mustard-100 text-mustard-600 flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-mustard-600" />
          </div>
          <div>
            <h2 className="text-lg font-display font-bold text-charcoal-900">
              {t.healthInsights} & Vitals
            </h2>
            <p className="text-xs text-charcoal-500">
              Continuous monitoring & 7-day adherence analysis
            </p>
          </div>
        </div>

        <button
          onClick={() => setActivePage('insights')}
          className="text-xs font-bold text-teal-850 hover:text-teal-700 flex items-center gap-1"
        >
          <span>Detailed Trends</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
        {/* Left Column: 4 Key Vitals Badges */}
        <div className="lg:col-span-5 grid grid-cols-2 gap-3">
          {/* Blood Pressure */}
          <div className="p-3.5 rounded-2xl bg-sage-50 border border-sage-200">
            <div className="flex items-center justify-between text-xs text-sage-700 font-bold">
              <span>Blood Pressure</span>
              <HeartPulse className="w-4 h-4 text-teal-700" />
            </div>
            <p className="text-xl font-display font-extrabold text-charcoal-900 mt-1">
              {latestVital.bloodPressureSystolic}/{latestVital.bloodPressureDiastolic}
              <span className="text-xs font-normal text-charcoal-500 ml-1">mmHg</span>
            </p>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full inline-block mt-1">
              Normal Range
            </span>
          </div>

          {/* Heart Rate */}
          <div className="p-3.5 rounded-2xl bg-peach-50 border border-peach-200">
            <div className="flex items-center justify-between text-xs text-peach-700 font-bold">
              <span>Pulse / Heart Rate</span>
              <Activity className="w-4 h-4 text-peach-500" />
            </div>
            <p className="text-xl font-display font-extrabold text-charcoal-900 mt-1">
              {latestVital.heartRate}
              <span className="text-xs font-normal text-charcoal-500 ml-1">bpm</span>
            </p>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full inline-block mt-1">
              Resting Stable
            </span>
          </div>

          {/* Blood Glucose */}
          <div className="p-3.5 rounded-2xl bg-mustard-50 border border-mustard-200">
            <div className="flex items-center justify-between text-xs text-mustard-600 font-bold">
              <span>Fasting Glucose</span>
              <Droplet className="w-4 h-4 text-mustard-500" />
            </div>
            <p className="text-xl font-display font-extrabold text-charcoal-900 mt-1">
              {latestVital.bloodGlucose}
              <span className="text-xs font-normal text-charcoal-500 ml-1">mg/dL</span>
            </p>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full inline-block mt-1">
              Controlled
            </span>
          </div>

          {/* Blood Oxygen SpO2 */}
          <div className="p-3.5 rounded-2xl bg-lavender-50 border border-lavender-200">
            <div className="flex items-center justify-between text-xs text-lavender-700 font-bold">
              <span>Oxygen (SpO2)</span>
              <TrendingUp className="w-4 h-4 text-lavender-700" />
            </div>
            <p className="text-xl font-display font-extrabold text-charcoal-900 mt-1">
              {latestVital.spo2}%
            </p>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full inline-block mt-1">
              Optimal
            </span>
          </div>
        </div>

        {/* Right Column: 7-Day Adherence Bar Chart */}
        <div className="lg:col-span-7 p-4 rounded-2xl bg-cream-50 border border-cream-200">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-charcoal-700">7-Day Medication Adherence (%)</span>
            <span className="text-xs font-extrabold text-teal-850">Average: 92%</span>
          </div>

          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyAdherenceData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#566661' }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#566661' }} />
                <Tooltip
                  formatter={(val: any) => [`${val}% Adherence`, 'Score']}
                  contentStyle={{ backgroundColor: '#174F4A', borderRadius: 12, color: '#FAF7F2', border: 'none' }}
                  itemStyle={{ color: '#E5C477', fontWeight: 'bold' }}
                />
                <Bar dataKey="adherence" fill="#286B61" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
