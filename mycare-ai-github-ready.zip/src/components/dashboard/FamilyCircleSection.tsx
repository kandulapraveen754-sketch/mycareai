// ==========================================
// MYCARE AI - FAMILY CIRCLE & CARE TASKS SECTION
// Connected family guardians, nurse tasks, completion toggles
// ==========================================

import React from 'react';
import {
  Users,
  CheckCircle2,
  Circle,
  Plus,
  ChevronRight,
  ShieldCheck,
  Clock,
  UserCheck
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { triggerConfetti } from '../../utils/confetti';

export const FamilyCircleSection: React.FC = () => {
  const { familyMembers, careTasks, toggleCareTask, setActivePage, t } = useApp();

  const handleTaskToggle = (taskId: string) => {
    toggleCareTask(taskId);
    triggerConfetti(1500);
  };

  return (
    <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-cream-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-lavender-100 text-lavender-700 flex items-center justify-center">
            <Users className="w-5 h-5 text-lavender-700" />
          </div>
          <div>
            <h2 className="text-lg font-display font-bold text-charcoal-900">
              {t.familyCircle} & Care Tasks
            </h2>
            <p className="text-xs text-charcoal-500">
              Coordinated care between family members and professional nurse
            </p>
          </div>
        </div>

        <button
          onClick={() => setActivePage('family')}
          className="text-xs font-bold text-teal-850 hover:text-teal-700 flex items-center gap-1"
        >
          <span>Manage Circle</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
        {/* Left Column: Connected Family & Caregivers */}
        <div className="md:col-span-5 space-y-3">
          <p className="text-xs font-bold text-charcoal-500 uppercase tracking-wider">
            Connected Guardians & Nurse:
          </p>
          <div className="space-y-2">
            {familyMembers.map((member) => (
              <div
                key={member.id}
                className="p-3 rounded-2xl bg-cream-50 border border-cream-200 flex items-center justify-between"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={member.avatar}
                    alt={member.name}
                    className="w-10 h-10 rounded-full object-cover ring-2 ring-peach-300 shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-charcoal-900 truncate">{member.name}</p>
                    <p className="text-[11px] text-charcoal-500 truncate">{member.relation}</p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                    {member.lastActive}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Care Tasks List */}
        <div className="md:col-span-7 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold text-charcoal-500 uppercase tracking-wider">
              Today's Care Tasks:
            </p>
            <span className="text-xs text-teal-850 font-bold">
              {careTasks.filter(t => t.completed).length} of {careTasks.length} Completed
            </span>
          </div>

          <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
            {careTasks.map((task) => (
              <div
                key={task.id}
                onClick={() => handleTaskToggle(task.id)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${
                  task.completed
                    ? 'bg-cream-100/60 border-cream-300 opacity-80'
                    : 'bg-white border-cream-300 hover:border-teal-700/50 shadow-sm'
                }`}
              >
                <div className="mt-0.5 shrink-0 text-teal-700">
                  {task.completed ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  ) : (
                    <Circle className="w-5 h-5 text-charcoal-400 hover:text-teal-700" />
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <h4
                      className={`text-xs font-bold ${
                        task.completed ? 'line-through text-charcoal-500' : 'text-charcoal-900'
                      }`}
                    >
                      {task.title}
                    </h4>
                    {task.urgent && !task.completed && (
                      <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.2 rounded bg-peach-500 text-white">
                        Urgent
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-charcoal-600 mt-0.5 line-clamp-1">
                    {task.description}
                  </p>
                  <p className="text-[10px] text-teal-850 font-semibold mt-1 flex items-center gap-1">
                    <UserCheck className="w-3 h-3 text-teal-700" />
                    <span>Assigned to: {task.assignedTo} ({task.dueDate})</span>
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
