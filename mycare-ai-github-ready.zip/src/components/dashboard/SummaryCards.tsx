// ==========================================
// MYCARE AI - FOUR COLORFUL SUMMARY CARDS
// Palette: Sage Green, Peach, Muted Mustard, Soft Lavender
// ==========================================

import React from 'react';
import {
  Pill,
  Calendar,
  TrendingUp,
  Users,
  CheckCircle2,
  Clock,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const SummaryCards: React.FC = () => {
  const { todayDoses, appointments, familyMembers, setActivePage, isElderlyMode } = useApp();

  const totalDoses = todayDoses.length;
  const takenDoses = todayDoses.filter(d => d.status === 'taken').length;
  const pendingDose = todayDoses.find(d => d.status === 'pending');

  const nextAppointment = appointments.find(a => a.status === 'Confirmed');
  const activeCaregiver = familyMembers.find(f => f.role === 'Primary Caregiver') || familyMembers[0];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
      {/* 1. Today's Medicines Card - Sage Green */}
      <div
        onClick={() => setActivePage('medicines')}
        className="rounded-3xl bg-sage-100/90 border border-sage-200 p-5 shadow-card hover:shadow-card-hover transition-all duration-200 cursor-pointer group flex flex-col justify-between"
      >
        <div className="flex items-start justify-between">
          <div className="w-12 h-12 rounded-2xl bg-white/80 text-teal-850 flex items-center justify-center shadow-sm">
            <Pill className="w-6 h-6 text-teal-700" />
          </div>
          <span className="text-xs font-extrabold px-2.5 py-1 rounded-full bg-teal-850 text-cream-50">
            {takenDoses}/{totalDoses} Done
          </span>
        </div>

        <div className="mt-4">
          <span className="text-xs font-bold text-teal-900/70 uppercase tracking-wider">
            Today's Medicines
          </span>
          <p className="text-2xl font-display font-extrabold text-teal-900 mt-1">
            {takenDoses} of {totalDoses} Taken
          </p>
          <div className="mt-2 text-xs text-teal-800 font-medium flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-teal-700" />
            <span className="truncate">
              {pendingDose ? `Next: ${pendingDose.medicineName} (${pendingDose.scheduledTime})` : "All doses completed!"}
            </span>
          </div>
        </div>

        <div className="mt-3 pt-2.5 border-t border-sage-200/80 flex items-center justify-between text-xs font-bold text-teal-850 group-hover:text-teal-700">
          <span>Manage Schedule</span>
          <ChevronRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
        </div>
      </div>

      {/* 2. Next Appointment Card - Peach */}
      <div
        onClick={() => setActivePage('appointments')}
        className="rounded-3xl bg-peach-100/90 border border-peach-200 p-5 shadow-card hover:shadow-card-hover transition-all duration-200 cursor-pointer group flex flex-col justify-between"
      >
        <div className="flex items-start justify-between">
          <div className="w-12 h-12 rounded-2xl bg-white/80 text-peach-600 flex items-center justify-center shadow-sm">
            <Calendar className="w-6 h-6 text-peach-500" />
          </div>
          <span className="text-xs font-extrabold px-2.5 py-1 rounded-full bg-peach-500 text-white">
            Upcoming
          </span>
        </div>

        <div className="mt-4">
          <span className="text-xs font-bold text-peach-700 uppercase tracking-wider">
            Next Doctor Visit
          </span>
          <p className="text-xl font-display font-extrabold text-charcoal-900 mt-1 truncate">
            {nextAppointment ? nextAppointment.doctorName : "No appointment"}
          </p>
          <p className="text-xs text-charcoal-700 font-medium mt-1 truncate">
            {nextAppointment ? `${nextAppointment.date} at ${nextAppointment.time}` : "Book a routine checkup"}
          </p>
        </div>

        <div className="mt-3 pt-2.5 border-t border-peach-200/80 flex items-center justify-between text-xs font-bold text-peach-700 group-hover:text-peach-600">
          <span>View Consultations</span>
          <ChevronRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
        </div>
      </div>

      {/* 3. Medication Adherence - Muted Mustard */}
      <div
        onClick={() => setActivePage('insights')}
        className="rounded-3xl bg-mustard-100 border border-mustard-200 p-5 shadow-card hover:shadow-card-hover transition-all duration-200 cursor-pointer group flex flex-col justify-between"
      >
        <div className="flex items-start justify-between">
          <div className="w-12 h-12 rounded-2xl bg-white/80 text-mustard-600 flex items-center justify-center shadow-sm">
            <TrendingUp className="w-6 h-6 text-mustard-500" />
          </div>
          <span className="text-xs font-extrabold px-2.5 py-1 rounded-full bg-mustard-500 text-charcoal-900">
            92% High
          </span>
        </div>

        <div className="mt-4">
          <span className="text-xs font-bold text-mustard-600 uppercase tracking-wider">
            Medication Adherence
          </span>
          <p className="text-2xl font-display font-extrabold text-charcoal-900 mt-1">
            92% This Week
          </p>
          <p className="text-xs text-charcoal-700 font-medium mt-1">
            32 of 35 doses confirmed on-time
          </p>
        </div>

        <div className="mt-3 pt-2.5 border-t border-mustard-200/80 flex items-center justify-between text-xs font-bold text-charcoal-800 group-hover:text-mustard-600">
          <span>Health Insights & Trends</span>
          <ChevronRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
        </div>
      </div>

      {/* 4. Family & Caregiver Status - Soft Lavender */}
      <div
        onClick={() => setActivePage('family')}
        className="rounded-3xl bg-lavender-100 border border-lavender-200 p-5 shadow-card hover:shadow-card-hover transition-all duration-200 cursor-pointer group flex flex-col justify-between"
      >
        <div className="flex items-start justify-between">
          <div className="w-12 h-12 rounded-2xl bg-white/80 text-lavender-700 flex items-center justify-center shadow-sm">
            <Users className="w-6 h-6 text-lavender-700" />
          </div>
          <span className="text-xs font-extrabold px-2.5 py-1 rounded-full bg-lavender-700 text-white flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-ping"></span>
            Active
          </span>
        </div>

        <div className="mt-4">
          <span className="text-xs font-bold text-lavender-700 uppercase tracking-wider">
            Family & Caregiver
          </span>
          <p className="text-xl font-display font-extrabold text-charcoal-900 mt-1 truncate">
            {activeCaregiver ? activeCaregiver.name : "3 Connected"}
          </p>
          <p className="text-xs text-charcoal-700 font-medium mt-1">
            Last check-in: Active just now
          </p>
        </div>

        <div className="mt-3 pt-2.5 border-t border-lavender-200/80 flex items-center justify-between text-xs font-bold text-lavender-700 group-hover:text-purple-800">
          <span>Care Circle & Tasks</span>
          <ChevronRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </div>
  );
};
