// ==========================================
// MYCARE AI - AI GUARDIAN DASHBOARD WIDGET
// Intelligent Voice & Conversational Assistant
// Multilingual: English, Telugu, Hindi
// ==========================================

import React, { useState } from 'react';
import {
  Sparkles,
  Mic,
  MicOff,
  Send,
  Volume2,
  VolumeX,
  RefreshCw,
  AlertTriangle,
  Bot,
  User,
  ShieldCheck
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { VoiceService } from '../../services/voiceService';

export const AIGuardianWidget: React.FC = () => {
  const {
    guardianMessages,
    isGuardianTyping,
    sendGuardianMessage,
    clearGuardianChat,
    language,
    t,
    isElderlyMode,
    autoVoiceEnabled,
    setAutoVoiceEnabled
  } = useApp();

  const [inputQuery, setInputQuery] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [voiceError, setVoiceError] = useState<string | null>(null);

  const suggestedQuestions = [
    "What medicines should I take today?",
    "Did I miss any medicine?",
    "When is my next appointment?",
    "What is my adherence this week?",
    "Show my blood pressure trend"
  ];

  const handleSend = () => {
    if (!inputQuery.trim()) return;
    sendGuardianMessage(inputQuery);
    setInputQuery('');
  };

  const handleVoiceToggle = () => {
    if (isListening) {
      VoiceService.stopListening();
      setIsListening(false);
      return;
    }

    setVoiceError(null);
    const started = VoiceService.startListening(
      language,
      (transcript, isFinal) => {
        setInputQuery(transcript);
        if (isFinal) {
          setIsListening(false);
        }
      },
      (error) => {
        setVoiceError(error);
        setIsListening(false);
      },
      () => {
        setIsListening(false);
      }
    );

    if (started) {
      setIsListening(true);
    }
  };

  const speakLastMessage = () => {
    const lastGuardianMsg = [...guardianMessages].reverse().find(m => m.sender === 'guardian');
    if (lastGuardianMsg) {
      VoiceService.speak(lastGuardianMsg.text, language);
    }
  };

  return (
    <div className="rounded-3xl bg-white border border-cream-300 p-6 shadow-card space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-cream-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-mustard-100 text-teal-850 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-mustard-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-display font-bold text-charcoal-900">
                {t.aiGuardian}
              </h2>
              <span className="text-[10px] bg-teal-100 text-teal-850 font-bold px-2 py-0.5 rounded-full uppercase">
                Gemini Powered
              </span>
            </div>
            <p className="text-xs text-charcoal-500">
              {t.aiGuardianSub}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Read aloud button */}
          <button
            onClick={speakLastMessage}
            className="p-2 rounded-xl bg-cream-100 hover:bg-cream-200 text-teal-850 transition-colors"
            title="Speak last answer aloud"
          >
            <Volume2 className="w-4 h-4" />
          </button>

          {/* Reset chat */}
          <button
            onClick={clearGuardianChat}
            className="p-2 rounded-xl bg-cream-100 hover:bg-cream-200 text-charcoal-500 transition-colors"
            title="Clear chat"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Suggested Quick Questions */}
      <div>
        <p className="text-[11px] font-bold text-charcoal-500 uppercase tracking-wider mb-2">
          {t.suggestedQuestions}
        </p>
        <div className="flex flex-wrap gap-2">
          {suggestedQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => sendGuardianMessage(q)}
              className="text-xs px-3 py-1.5 rounded-full bg-cream-100 hover:bg-teal-50 hover:text-teal-850 text-charcoal-700 border border-cream-300 transition-colors shadow-sm font-medium"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Log */}
      <div className="max-h-64 sm:max-h-72 overflow-y-auto space-y-3 p-3 rounded-2xl bg-cream-50 border border-cream-200 scrollbar-thin">
        {guardianMessages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start gap-2.5 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div
              className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${
                msg.sender === 'user'
                  ? 'bg-peach-500 text-white'
                  : 'bg-teal-850 text-mustard-300'
              }`}
            >
              {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            <div
              className={`max-w-[85%] rounded-2xl px-4 py-2.5 shadow-sm text-xs sm:text-sm ${
                msg.sender === 'user'
                  ? 'bg-peach-500 text-white rounded-tr-none'
                  : 'bg-white text-charcoal-800 border border-cream-300 rounded-tl-none'
              }`}
            >
              <p className="whitespace-pre-line leading-relaxed">{msg.text}</p>
              <div
                className={`text-[10px] mt-1 text-right ${
                  msg.sender === 'user' ? 'text-peach-200' : 'text-charcoal-400'
                }`}
              >
                {msg.timestamp}
              </div>
            </div>
          </div>
        ))}

        {isGuardianTyping && (
          <div className="flex items-center gap-2 p-3 bg-white rounded-2xl border border-cream-200 max-w-xs">
            <RefreshCw className="w-4 h-4 animate-spin text-teal-700" />
            <span className="text-xs text-charcoal-600 font-medium">
              AI Guardian is thinking...
            </span>
          </div>
        )}
      </div>

      {/* Listening Animation Indicator */}
      {isListening && (
        <div className="p-3 rounded-2xl bg-peach-100 border border-peach-300 flex items-center justify-between animate-pulse">
          <div className="flex items-center gap-2 text-peach-800 text-xs font-bold">
            <span className="w-2.5 h-2.5 rounded-full bg-peach-500 animate-ping"></span>
            <span>{t.listening} {t.speakNow}</span>
          </div>
          <button
            onClick={() => VoiceService.stopListening()}
            className="text-xs font-bold text-peach-600 underline"
          >
            Stop
          </button>
        </div>
      )}

      {voiceError && (
        <p className="text-xs text-red-600 bg-red-50 p-2 rounded-xl border border-red-200">
          {voiceError}
        </p>
      )}

      {/* Input Form with Big Voice Mic Button */}
      <div className="flex items-center gap-2">
        <button
          onClick={handleVoiceToggle}
          className={`p-3 rounded-2xl transition-all shadow-sm ${
            isListening
              ? 'bg-peach-500 text-white ring-4 ring-peach-300 animate-pulse'
              : 'bg-teal-850 hover:bg-teal-700 text-cream-50'
          }`}
          title="Voice Assistant (English, Telugu, Hindi)"
        >
          {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        <input
          type="text"
          value={inputQuery}
          onChange={(e) => setInputQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder={t.typeYourMessage}
          className="flex-1 px-4 py-3 rounded-2xl bg-cream-50 border border-cream-300 text-charcoal-800 placeholder-charcoal-400 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-teal-700"
        />

        <button
          onClick={handleSend}
          disabled={!inputQuery.trim()}
          className="p-3 rounded-2xl bg-teal-850 hover:bg-teal-700 disabled:opacity-50 text-white transition-colors shadow-sm"
        >
          <Send className="w-5 h-5" />
        </button>
      </div>

      {/* Safety Disclaimer */}
      <div className="pt-2 border-t border-cream-200 flex items-center gap-1.5 text-[10px] text-charcoal-500">
        <ShieldCheck className="w-3.5 h-3.5 text-teal-700 shrink-0" />
        <span>
          AI Guardian provides guidance based on verified patient records. Not a substitute for clinical diagnosis.
        </span>
      </div>
    </div>
  );
};
