// ==========================================
// MYCARE AI - CENTRAL APPLICATION CONTEXT & STATE
// Manages authentication, medicines, cart, appointments,
// emergency SOS, family tasks, and multilingual support.
// ==========================================

import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserProfile,
  UserRole,
  LanguageCode,
  ScheduledDose,
  Medicine,
  MedicineCatalogueItem,
  CartItem,
  Order,
  Doctor,
  Appointment,
  CareTask,
  FamilyMember,
  EmergencyContact,
  EmergencyAlert,
  NotificationItem,
  HealthVital,
  ChatMessage
} from '../types';
import {
  mockUsers,
  initialMedicines,
  initialTodayDoses,
  medicineCatalogue,
  mockDoctors,
  initialAppointments,
  initialFamilyMembers,
  initialCareTasks,
  initialEmergencyContacts,
  initialNotifications,
  initialVitals,
  initialOrders,
  recentActivityLogs
} from '../data/mockData';
import { translations, Translations } from '../data/translations';
import { triggerConfetti } from '../utils/confetti';
import { AIService } from '../services/aiService';
import { VoiceService } from '../services/voiceService';
import { AuthService } from '../services/authService';

export type NavigationPage = 
  | 'dashboard'
  | 'health'
  | 'medicines'
  | 'ordering'
  | 'guardian'
  | 'appointments'
  | 'family'
  | 'insights'
  | 'emergency'
  | 'notifications'
  | 'settings';

interface AppContextType {
  // User & Auth
  isAuthenticated: boolean;
  isDemoMode: boolean;
  currentUser: UserProfile;
  currentRole: UserRole;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (params: any) => Promise<{ success: boolean; error?: string }>;
  enterDemoMode: (role?: UserRole) => void;
  logout: () => void;
  switchRole: (role: UserRole) => void;
  updateUserProfile: (updates: Partial<UserProfile>) => Promise<void>;
  // Navigation
  activePage: NavigationPage;
  setActivePage: (page: NavigationPage) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  // Language & Translations
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: Translations;
  // Accessibility
  isElderlyMode: boolean;
  setIsElderlyMode: (val: boolean) => void;
  fontSize: 'normal' | 'large' | 'xlarge';
  setFontSize: (size: 'normal' | 'large' | 'xlarge') => void;
  autoVoiceEnabled: boolean;
  setAutoVoiceEnabled: (val: boolean) => void;
  // Medicines & Doses
  medicines: Medicine[];
  todayDoses: ScheduledDose[];
  markDoseTaken: (doseId: string) => void;
  skipDose: (doseId: string, reason: string) => void;
  addMedicine: (med: Partial<Medicine>) => void;
  deleteMedicine: (id: string) => void;
  // Pharmacy & Cart
  catalogue: MedicineCatalogueItem[];
  addCatalogueItem: (item: Partial<MedicineCatalogueItem>) => void;
  importCatalogueCSV: (csvText: string) => number;
  resetCatalogue: () => void;
  cart: CartItem[];
  cartTotal: number;
  addToCart: (item: MedicineCatalogueItem, quantity?: number) => void;
  removeFromCart: (medicineId: string) => void;
  updateCartQuantity: (medicineId: string, quantity: number) => void;
  clearCart: () => void;
  orders: Order[];
  placeOrder: (details: { address: string; paymentMethod: string; prescriptionFile?: string }) => Order;
  // Doctors & Appointments
  doctors: Doctor[];
  appointments: Appointment[];
  bookAppointment: (doctorId: string, date: string, slot: string, type: 'In-person Clinic' | 'Video Consultation', reason: string) => boolean;
  cancelAppointment: (appointmentId: string) => void;
  rescheduleAppointment: (appointmentId: string, newDate: string, newSlot: string) => void;
  // Emergency Shield
  emergencyContacts: EmergencyContact[];
  addEmergencyContact: (contact: Partial<EmergencyContact>) => void;
  updateEmergencyContact: (id: string, contact: Partial<EmergencyContact>) => void;
  deleteEmergencyContact: (id: string) => void;
  emergencyAlert: EmergencyAlert | null;
  isSOSActive: boolean;
  triggerSOS: (consentGps?: boolean) => void;
  resolveSOS: (note?: string) => void;
  cancelSOS: () => void;
  // Family & Care Tasks
  familyMembers: FamilyMember[];
  addFamilyMember: (member: Partial<FamilyMember>) => void;
  updateFamilyMember: (id: string, member: Partial<FamilyMember>) => void;
  deleteFamilyMember: (id: string) => void;
  careTasks: CareTask[];
  toggleCareTask: (taskId: string, notes?: string) => void;
  addCareTask: (task: Partial<CareTask>) => void;
  inviteFamilyMember: (member: Partial<FamilyMember>) => void;
  // Notifications
  notifications: NotificationItem[];
  unreadNotificationCount: number;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  // Health Vitals & Insights
  vitals: HealthVital[];
  addVitalRecord: (vital: Partial<HealthVital>) => void;
  activityLogs: typeof recentActivityLogs;
  // AI Guardian Chat
  guardianMessages: ChatMessage[];
  isGuardianTyping: boolean;
  sendGuardianMessage: (text: string) => Promise<void>;
  clearGuardianChat: () => void;
  // AI Scanner Modal
  isScannerOpen: boolean;
  openScanner: () => void;
  closeScanner: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Check active session (tab/session storage)
  const activeSession = AuthService.getActiveSession();
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(!!activeSession);
  const [isDemoMode, setIsDemoMode] = useState<boolean>(activeSession?.isDemo ?? false);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(activeSession?.user ?? null);
  const [currentRole, setCurrentRole] = useState<UserRole>(activeSession?.user?.role ?? 'elderly');
  const [activePage, setActivePage] = useState<NavigationPage>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Multilingual & Accessibility
  const [language, setLanguageState] = useState<LanguageCode>('en');
  const [isElderlyMode, setIsElderlyMode] = useState<boolean>(true); // Elderly-friendly by default for optimal senior UX
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>('large');
  const [autoVoiceEnabled, setAutoVoiceEnabled] = useState<boolean>(false);

  // Data collections - strictly partitioned per authenticated user or demo session
  const [medicines, setMedicines] = useState<Medicine[]>(activeSession?.isDemo ? initialMedicines : []);
  const [todayDoses, setTodayDoses] = useState<ScheduledDose[]>(activeSession?.isDemo ? initialTodayDoses : []);
  const [catalogue, setCatalogue] = useState<MedicineCatalogueItem[]>(medicineCatalogue);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>(activeSession?.isDemo ? initialOrders : []);
  const [doctors] = useState<Doctor[]>(mockDoctors);
  const [appointments, setAppointments] = useState<Appointment[]>(activeSession?.isDemo ? initialAppointments : []);
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>(activeSession?.isDemo ? initialFamilyMembers : []);
  const [careTasks, setCareTasks] = useState<CareTask[]>(activeSession?.isDemo ? initialCareTasks : []);
  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>(activeSession?.isDemo ? initialEmergencyContacts : []);
  const [emergencyAlert, setEmergencyAlert] = useState<EmergencyAlert | null>(null);
  const [isSOSActive, setIsSOSActive] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>(activeSession?.isDemo ? initialNotifications : []);
  const [vitals, setVitals] = useState<HealthVital[]>(activeSession?.isDemo ? initialVitals : []);
  const [activityLogs, setActivityLogs] = useState(recentActivityLogs);

  // Helper to sync changes to authenticated user's isolated account database
  const syncUserData = (partial: any) => {
    if (currentUser?.id && !isDemoMode) {
      AuthService.saveUserData(currentUser.id, partial);
    }
  };

  // Load private user data on mount if authenticated
  useEffect(() => {
    if (activeSession?.user && !activeSession.isDemo) {
      AuthService.loadUserData(activeSession.user.id).then(userData => {
        if (userData) {
          if (userData.medicines) setMedicines(userData.medicines);
          if (userData.todayDoses) setTodayDoses(userData.todayDoses);
          if (userData.vitals) setVitals(userData.vitals);
          if (userData.appointments) setAppointments(userData.appointments);
          if (userData.familyMembers) setFamilyMembers(userData.familyMembers);
          if (userData.careTasks) setCareTasks(userData.careTasks);
          if (userData.emergencyContacts) setEmergencyContacts(userData.emergencyContacts);
          if (userData.orders) setOrders(userData.orders);
          if (userData.notifications) setNotifications(userData.notifications);
          if (userData.guardianMessages?.length) setGuardianMessages(userData.guardianMessages);
        }
      });
    }
  }, []);

  // Authentication Handlers
  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    const res = await AuthService.login(email, password);
    if (res.success && res.user) {
      setCurrentUser(res.user);
      setCurrentRole(res.user.role);
      setIsAuthenticated(true);
      setIsDemoMode(false);

      const userData = await AuthService.loadUserData(res.user.id);
      if (userData) {
        setMedicines(userData.medicines || []);
        setTodayDoses(userData.todayDoses || []);
        setVitals(userData.vitals || []);
        setAppointments(userData.appointments || []);
        setFamilyMembers(userData.familyMembers || []);
        setCareTasks(userData.careTasks || []);
        setEmergencyContacts(userData.emergencyContacts || []);
        setOrders(userData.orders || []);
        setNotifications(userData.notifications || []);
        if (userData.guardianMessages?.length) setGuardianMessages(userData.guardianMessages);
      } else {
        setMedicines([]);
        setTodayDoses([]);
        setVitals([]);
        setAppointments([]);
        setFamilyMembers([]);
        setCareTasks([]);
        setEmergencyContacts([]);
        setOrders([]);
        setNotifications([
          {
            id: `notif_${Date.now()}`,
            title: `Welcome ${res.user.name}`,
            message: 'Your personal health account is ready. Add medicines and family contacts to get started.',
            type: 'system',
            timestamp: 'Just now',
            read: false
          }
        ]);
      }
      setActivePage('dashboard');
      return { success: true };
    }
    return { success: false, error: res.error || 'Login failed.' };
  };

  const register = async (params: any): Promise<{ success: boolean; error?: string }> => {
    const res = await AuthService.register(params);
    if (res.success && res.user) {
      setCurrentUser(res.user);
      setCurrentRole(res.user.role);
      setIsAuthenticated(true);
      setIsDemoMode(false);

      const starterContacts = params.emergencyContact ? [
        {
          id: `em_${Date.now()}`,
          name: params.emergencyContact.name,
          relation: params.emergencyContact.relation,
          phone: params.emergencyContact.phone,
          isPrimary: true,
          notifyOnSOS: true,
          isDemoData: false
        }
      ] : [];

      setMedicines([]);
      setTodayDoses([]);
      setVitals([]);
      setAppointments([]);
      setFamilyMembers([]);
      setCareTasks([]);
      setEmergencyContacts(starterContacts);
      setOrders([]);
      setNotifications([
        {
          id: `notif_${Date.now()}`,
          title: `Welcome ${res.user.name}`,
          message: 'Your personal health account is ready. Add your daily medicines and family contacts to get started.',
          type: 'system',
          timestamp: 'Just now',
          read: false
        }
      ]);

      setActivePage('dashboard');
      return { success: true };
    }
    return { success: false, error: res.error || 'Registration failed.' };
  };

  const enterDemoMode = (role: UserRole = 'elderly') => {
    const demoUser = mockUsers[role] || mockUsers.elderly;
    setCurrentUser(demoUser);
    setCurrentRole(role);
    setIsDemoMode(true);
    setIsAuthenticated(true);
    AuthService.setActiveSession(demoUser, true);

    setMedicines(initialMedicines);
    setTodayDoses(initialTodayDoses);
    setVitals(initialVitals);
    setAppointments(initialAppointments);
    setFamilyMembers(initialFamilyMembers);
    setCareTasks(initialCareTasks);
    setEmergencyContacts(initialEmergencyContacts);
    setOrders(initialOrders);
    setNotifications(initialNotifications);
    setActivePage('dashboard');
  };

  const logout = () => {
    AuthService.clearSession();
    setIsAuthenticated(false);
    setIsDemoMode(false);
    setCurrentUser(null);
    setActivePage('dashboard');
  };

  const updateUserProfile = async (updates: Partial<UserProfile>) => {
    if (!currentUser) return;
    const updated = { ...currentUser, ...updates };
    setCurrentUser(updated);
    if (!isDemoMode) {
      await AuthService.updateUserProfile(currentUser.id, updates);
    }
    addNotification({
      title: "Profile Updated",
      message: "Your profile information was successfully updated in your account.",
      type: "system"
    });
  };

  const addEmergencyContact = (contact: Partial<EmergencyContact>) => {
    const newContact: EmergencyContact = {
      id: `em_${Date.now()}`,
      name: contact.name || "Emergency Contact",
      relation: contact.relation || "Family",
      phone: contact.phone || "+91 90000 00000",
      isPrimary: contact.isPrimary ?? false,
      notifyOnSOS: contact.notifyOnSOS ?? true,
      isDemoData: false
    };
    setEmergencyContacts(prev => {
      const updated = contact.isPrimary 
        ? [newContact, ...prev.map(c => ({ ...c, isPrimary: false }))]
        : [...prev, newContact];
      syncUserData({ emergencyContacts: updated });
      return updated;
    });
    addNotification({
      title: "Emergency Contact Added",
      message: `${newContact.name} configured for immediate SOS assistance.`,
      type: "emergency"
    });
  };

  const updateEmergencyContact = (id: string, contactUpdates: Partial<EmergencyContact>) => {
    setEmergencyContacts(prev => {
      const updated = prev.map(c => (c.id === id ? { ...c, ...contactUpdates } : c));
      syncUserData({ emergencyContacts: updated });
      return updated;
    });
  };

  const deleteEmergencyContact = (id: string) => {
    setEmergencyContacts(prev => {
      const updated = prev.filter(c => c.id !== id);
      syncUserData({ emergencyContacts: updated });
      return updated;
    });
  };

  const addFamilyMember = (member: Partial<FamilyMember>) => {
    const newMember: FamilyMember = {
      id: `fam_${Date.now()}`,
      name: member.name || "Family Member",
      relation: member.relation || "Family",
      role: member.role || "Family Member",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80",
      phone: member.phone || "+91 90000 00000",
      email: member.email || "family@mycare.ai",
      permissions: member.permissions || {
        canViewVitals: true,
        canManageMedicines: true,
        canBookAppointments: true,
        canReceiveSOS: true
      },
      lastActive: "Just now",
      status: "Active",
      isDemoData: false
    };
    setFamilyMembers(prev => {
      const updated = [...prev, newMember];
      syncUserData({ familyMembers: updated });
      return updated;
    });
    addNotification({
      title: "Family Member Connected",
      message: `${newMember.name} joined your MyCare circle.`,
      type: "family"
    });
  };

  const updateFamilyMember = (id: string, updates: Partial<FamilyMember>) => {
    setFamilyMembers(prev => {
      const updated = prev.map(m => (m.id === id ? { ...m, ...updates } : m));
      syncUserData({ familyMembers: updated });
      return updated;
    });
  };

  const deleteFamilyMember = (id: string) => {
    setFamilyMembers(prev => {
      const updated = prev.filter(m => m.id !== id);
      syncUserData({ familyMembers: updated });
      return updated;
    });
  };

  const addCatalogueItem = (item: Partial<MedicineCatalogueItem>) => {
    const newItem: MedicineCatalogueItem = {
      id: `cat_${Date.now()}`,
      name: item.name || "New Medicine",
      brand: item.brand || "Generic Brand",
      strength: item.strength || "500 mg",
      dosageForm: item.dosageForm || "Tablet",
      packSize: item.packSize || "Strip of 10 tablets",
      manufacturer: item.manufacturer || "Indian Pharma Ltd.",
      category: item.category || "General Healthcare",
      price: item.price || 100,
      discountPrice: item.discountPrice || (item.price ? Math.round(item.price * 0.88) : 88),
      inStock: item.inStock ?? true,
      stockCount: item.stockCount || 100,
      prescriptionRequired: item.prescriptionRequired ?? true,
      image: item.image || "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=400&q=80",
      description: item.description || "Medication verified in Indian National Formulary.",
      activeIngredients: item.activeIngredients || item.name || "Active salt",
      packagingInfo: item.packagingInfo || "Standard pharmaceutical blister packaging.",
      rating: 4.8,
      reviewCount: 50
    };
    setCatalogue(prev => [newItem, ...prev]);
    addNotification({
      title: "Catalogue Updated",
      message: `${newItem.name} added to pharmacy inventory.`,
      type: "order"
    });
  };

  const importCatalogueCSV = (csvText: string): number => {
    try {
      const lines = csvText.split('\n').map(l => l.trim()).filter(Boolean);
      if (lines.length <= 1) return 0;
      const newItems: MedicineCatalogueItem[] = [];
      for (let i = 1; i < lines.length; i++) {
        const parts = lines[i].split(',').map(p => p.trim().replace(/^"|"$/g, ''));
        if (parts.length >= 4) {
          const [name, brand, strength, salt, category, price, isRx] = parts;
          newItems.push({
            id: `csv_${Date.now()}_${i}`,
            name: name || `Product ${i}`,
            brand: brand || "Generic",
            strength: strength || "500 mg",
            dosageForm: "Tablet",
            packSize: "Strip of 10 tablets",
            manufacturer: brand || "Pharma Manufacturer",
            category: (category as any) || "General Healthcare",
            price: parseFloat(price) || 99,
            discountPrice: Math.round((parseFloat(price) || 99) * 0.88),
            inStock: true,
            stockCount: 150,
            prescriptionRequired: isRx?.toLowerCase() === 'true' || isRx === '1',
            image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=400&q=80",
            description: `Imported catalogue product: ${name} (${salt || 'Active formulation'})`,
            activeIngredients: salt || name,
            packagingInfo: "Standard blister pack",
            rating: 4.7,
            reviewCount: 30
          });
        }
      }
      if (newItems.length > 0) {
        setCatalogue(prev => [...newItems, ...prev]);
        addNotification({
          title: "Bulk Catalogue Import Successful",
          message: `${newItems.length} products imported into pharmacy catalogue.`,
          type: "order"
        });
        return newItems.length;
      }
    } catch (err) {
      console.error("CSV import error:", err);
    }
    return 0;
  };

  const resetCatalogue = () => {
    setCatalogue(medicineCatalogue);
  };

  // AI Guardian state
  const [guardianMessages, setGuardianMessages] = useState<ChatMessage[]>([
    {
      id: "msg_welcome",
      sender: "guardian",
      text: "Hello Ramesh ji, I am your MyCare AI Guardian. Your morning blood pressure is stable at 126/82 mmHg, and you have taken all 3 morning doses. How can I assist you right now?",
      timestamp: "08:40 AM",
      language: "en",
      suggestedPills: [
        "What medicines should I take today?",
        "When is my next appointment?",
        "Did I miss any medicine?",
        "What is my adherence this week?"
      ]
    }
  ]);
  const [isGuardianTyping, setIsGuardianTyping] = useState<boolean>(false);
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);

  // Role Switcher Handler
  const switchRole = (role: UserRole) => {
    setCurrentRole(role);
    setCurrentUser(mockUsers[role] || mockUsers.elderly);
    // Add activity log
    const roleLabels = {
      elderly: 'Elderly Member (Ramesh Sharma)',
      family: 'Family Guardian (Priya Sharma)',
      caregiver: 'Healthcare Caregiver (Sister Anjali)',
      admin: 'Medical Admin (Dr. Vikram Patel)'
    };
    addNotification({
      title: "Active Role Switched",
      message: `You are now viewing MyCare AI as ${roleLabels[role]}.`,
      type: "system"
    });
  };

  const setLanguage = (lang: LanguageCode) => {
    setLanguageState(lang);
    // Greet in the selected language in AI Guardian
    const greetingText = lang === 'te' 
      ? "నమస్కారం రమేష్ గారు! నేను మీ MyCare AI సంరక్షకుడిని. మీకు ఎలా సహాయపడగలను?"
      : lang === 'hi'
      ? "नमस्ते रमेश जी! मैं आपका MyCare AI गार्जियन हूँ। मैं आपकी क्या सहायता कर सकता हूँ?"
      : "Hello Ramesh ji! I am your MyCare AI Guardian. How may I assist your health routine today?";
    
    setGuardianMessages(prev => [
      ...prev,
      {
        id: `msg_lang_${Date.now()}`,
        sender: 'guardian',
        text: greetingText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        language: lang,
        suggestedPills: lang === 'te' 
          ? ["నేటి మందులు ఏవి?", "తదుపరి అపాయింట్‌మెంట్ ఎప్పుడు?", "ఈ వారం క్రమశిక్షణ ఎంత?"]
          : lang === 'hi'
          ? ["आज की दवाइयाँ क्या हैं?", "अगला अपॉइंटमेंट कब है?", "दवा नियमितता रिपोर्ट?"]
          : ["What medicines should I take today?", "When is my next appointment?"]
      }
    ]);
  };

  // Medicine Dose Tracking Actions
  const markDoseTaken = (doseId: string) => {
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    let doseName = "";

    setTodayDoses(prev =>
      prev.map(dose => {
        if (dose.id === doseId) {
          doseName = dose.medicineName;
          return {
            ...dose,
            status: 'taken' as const,
            takenAt: timeStr,
            confirmedBy: currentUser.name
          };
        }
        return dose;
      })
    );

    // Trigger visual confetti celebration
    triggerConfetti(2200);

    // Add activity log
    setActivityLogs(prev => [
      {
        id: `act_${Date.now()}`,
        title: "Medication Confirmed",
        time: `Just now (${timeStr})`,
        description: `${doseName} confirmed taken by ${currentUser.name}.`,
        icon: "Pill",
        type: "success"
      },
      ...prev
    ]);

    // Create notification
    addNotification({
      title: "Medication Dose Logged",
      message: `${doseName} marked as taken at ${timeStr}.`,
      type: "medicine"
    });
  };

  const skipDose = (doseId: string, reason: string) => {
    let doseName = "";
    setTodayDoses(prev =>
      prev.map(dose => {
        if (dose.id === doseId) {
          doseName = dose.medicineName;
          return {
            ...dose,
            status: 'skipped' as const,
            skippedReason: reason,
            confirmedBy: currentUser.name
          };
        }
        return dose;
      })
    );

    setActivityLogs(prev => [
      {
        id: `act_${Date.now()}`,
        title: "Dose Skipped with Reason",
        time: "Just now",
        description: `${doseName} was skipped. Reason: "${reason}". Caregiver notified.`,
        icon: "AlertTriangle",
        type: "warning"
      },
      ...prev
    ]);

    addNotification({
      title: "Dose Skipped Alert",
      message: `${doseName} skipped by ${currentUser.name}. Reason: ${reason}.`,
      type: "medicine"
    });
  };

  const addMedicine = (med: Partial<Medicine>) => {
    const newMed: Medicine = {
      id: `med_${Date.now()}`,
      name: med.name || "New Medication",
      brand: med.brand || med.name || "Prescribed Brand",
      strength: med.strength || "500 mg",
      dosageForm: med.dosageForm || "Tablet",
      frequency: med.frequency || "Once daily",
      scheduleTimes: med.scheduleTimes || ["Morning"],
      exactTimes: med.exactTimes || ["08:00 AM"],
      dosage: med.dosage || "1 tablet",
      startDate: med.startDate || new Date().toISOString().split('T')[0],
      instructions: med.instructions || "Take with water after food.",
      prescribedBy: med.prescribedBy || "Dr. Vikram Patel",
      image: med.image || "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=300&q=80",
      category: med.category || "General",
      remainingPills: med.remainingPills || 30,
      refillThreshold: med.refillThreshold || 7,
      isPrescriptionRequired: med.isPrescriptionRequired ?? true
    };

    setMedicines(prev => [newMed, ...prev]);

    // Also append to today's schedule
    const newDose: ScheduledDose = {
      id: `dose_${Date.now()}`,
      medicineId: newMed.id,
      medicineName: `${newMed.name} (${newMed.brand})`,
      strength: newMed.strength,
      dosage: newMed.dosage,
      timeSlot: newMed.scheduleTimes[0] || 'Morning',
      scheduledTime: newMed.exactTimes[0] || '08:00 AM',
      instructions: newMed.instructions,
      status: 'pending',
      colorTag: '#B9D0B5',
      shape: 'tablet'
    };
    setTodayDoses(prev => [...prev, newDose]);

    addNotification({
      title: "New Medicine Added",
      message: `${newMed.name} ${newMed.strength} added to your active prescription.`,
      type: "medicine"
    });
  };

  const deleteMedicine = (id: string) => {
    setMedicines(prev => prev.filter(m => m.id !== id));
    setTodayDoses(prev => prev.filter(d => d.medicineId !== id));
    addNotification({
      title: "Medicine Removed",
      message: "Medication was removed from active routine.",
      type: "medicine"
    });
  };

  // Cart & Ordering Actions
  const addToCart = (item: MedicineCatalogueItem, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(ci => ci.medicine.id === item.id);
      if (existing) {
        return prev.map(ci =>
          ci.medicine.id === item.id ? { ...ci, quantity: ci.quantity + quantity } : ci
        );
      }
      return [...prev, { medicine: item, quantity }];
    });
    addNotification({
      title: "Added to Pharmacy Cart",
      message: `${item.name} (${quantity}) added to cart.`,
      type: "order"
    });
  };

  const removeFromCart = (medicineId: string) => {
    setCart(prev => prev.filter(ci => ci.medicine.id !== medicineId));
  };

  const updateCartQuantity = (medicineId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(medicineId);
      return;
    }
    setCart(prev =>
      prev.map(ci => (ci.medicine.id === medicineId ? { ...ci, quantity } : ci))
    );
  };

  const clearCart = () => setCart([]);

  const cartTotal = cart.reduce((sum, item) => {
    const price = item.medicine.discountPrice || item.medicine.price;
    return sum + price * item.quantity;
  }, 0);

  const placeOrder = ({ address, paymentMethod, prescriptionFile }: { address: string; paymentMethod: string; prescriptionFile?: string }): Order => {
    const newOrder: Order = {
      id: `ord_${Date.now()}`,
      orderNumber: `MCA-${Math.floor(10000 + Math.random() * 90000)}`,
      date: new Date().toISOString().split('T')[0],
      items: [...cart],
      subtotal: cartTotal,
      discount: cartTotal > 300 ? 30 : 0,
      deliveryFee: 0, // Free senior doorstep delivery
      total: Math.max(0, cartTotal - (cartTotal > 300 ? 30 : 0)),
      status: 'Confirmed',
      deliveryAddress: address,
      estimatedDelivery: 'Estimated tomorrow by 02:00 PM',
      prescriptionUrl: prescriptionFile,
      prescriptionStatus: cart.some(ci => ci.medicine.prescriptionRequired) ? 'Verified' : 'Not Required',
      paymentMethod
    };

    setOrders(prev => [newOrder, ...prev]);
    clearCart();
    triggerConfetti(3000);

    setActivityLogs(prev => [
      {
        id: `act_${Date.now()}`,
        title: "Medicine Order Placed",
        time: "Just now",
        description: `Order ${newOrder.orderNumber} confirmed (${newOrder.items.length} items). Scheduled for home delivery.`,
        icon: "ShoppingBag",
        type: "success"
      },
      ...prev
    ]);

    addNotification({
      title: "Medicine Order Placed Successfully",
      message: `Order ${newOrder.orderNumber} confirmed. Expected delivery tomorrow by 02:00 PM.`,
      type: "order"
    });

    return newOrder;
  };

  // Doctors & Appointments
  const bookAppointment = (
    doctorId: string,
    date: string,
    slot: string,
    type: 'In-person Clinic' | 'Video Consultation',
    reason: string
  ): boolean => {
    // Check for double booking
    const alreadyBooked = appointments.some(
      apt => apt.date === date && apt.time === slot && apt.status !== 'Cancelled'
    );
    if (alreadyBooked) {
      alert("This time slot is already booked. Please select an alternate slot.");
      return false;
    }

    const doc = doctors.find(d => d.id === doctorId);
    if (!doc) return false;

    const newApt: Appointment = {
      id: `apt_${Date.now()}`,
      doctorId: doc.id,
      doctorName: doc.name,
      specialization: doc.specialization,
      doctorImage: doc.image,
      hospital: doc.hospital,
      date,
      time: slot,
      type,
      status: 'Confirmed',
      consultationFee: doc.consultationFee,
      reason: reason || "Routine Elderly Consultation",
      notes: "Please arrive 10 minutes prior with past prescription history.",
      meetingLink: type === 'Video Consultation' ? 'https://meet.mycare.ai/room-mca-9821' : undefined
    };

    setAppointments(prev => [newApt, ...prev]);
    triggerConfetti(2500);

    setActivityLogs(prev => [
      {
        id: `act_${Date.now()}`,
        title: "Doctor Appointment Booked",
        time: "Just now",
        description: `Appointment booked with ${doc.name} on ${date} at ${slot}.`,
        icon: "Calendar",
        type: "info"
      },
      ...prev
    ]);

    addNotification({
      title: "Doctor Appointment Confirmed",
      message: `Consultation with ${doc.name} on ${date} at ${slot} (${type}).`,
      type: "appointment"
    });

    return true;
  };

  const cancelAppointment = (appointmentId: string) => {
    setAppointments(prev =>
      prev.map(apt => (apt.id === appointmentId ? { ...apt, status: 'Cancelled' as const } : apt))
    );
    addNotification({
      title: "Appointment Cancelled",
      message: "The appointment was cancelled successfully.",
      type: "appointment"
    });
  };

  const rescheduleAppointment = (appointmentId: string, newDate: string, newSlot: string) => {
    setAppointments(prev =>
      prev.map(apt =>
        apt.id === appointmentId
          ? { ...apt, date: newDate, time: newSlot, status: 'Rescheduled' as const }
          : apt
      )
    );
    addNotification({
      title: "Appointment Rescheduled",
      message: `Rescheduled to ${newDate} at ${newSlot}.`,
      type: "appointment"
    });
  };

  // Emergency SOS Shield Workflow
  const triggerSOS = (consentGps = true) => {
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const newAlert: EmergencyAlert = {
      id: `alert_${Date.now()}`,
      timestamp: timeStr,
      status: 'Sent',
      location: consentGps
        ? {
            latitude: 17.4156,
            longitude: 78.4750,
            address: "Flat 402, Sai Nilayam, Road No. 12, Banjara Hills, Hyderabad"
          }
        : undefined,
      notifiedContacts: emergencyContacts.map(c => `${c.name} (${c.phone})`)
    };

    setEmergencyAlert(newAlert);
    setIsSOSActive(true);

    // Add activity log
    setActivityLogs(prev => [
      {
        id: `act_${Date.now()}`,
        title: "🚨 EMERGENCY SOS TRIGGERED",
        time: `Just now (${timeStr})`,
        description: `SOS alert dispatched to ${emergencyContacts.length} designated emergency contacts with GPS location.`,
        icon: "ShieldAlert",
        type: "danger"
      },
      ...prev
    ]);

    // Priority notification
    addNotification({
      title: "🚨 Emergency SOS Sent",
      message: `Emergency alert dispatched to Priya Sharma (+91 99887 65432) and Sister Anjali Rao.`,
      type: "emergency"
    });
  };

  const resolveSOS = (note = "Patient stabilized and confirmed safe by family/caregiver.") => {
    if (emergencyAlert) {
      setEmergencyAlert({
        ...emergencyAlert,
        status: 'Resolved',
        resolvedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        resolvedBy: currentUser.name,
        note
      });
    }
    setIsSOSActive(false);
    addNotification({
      title: "Emergency Alert Resolved",
      message: `Emergency status marked as resolved by ${currentUser.name}.`,
      type: "emergency"
    });
  };

  const cancelSOS = () => {
    if (emergencyAlert) {
      setEmergencyAlert({
        ...emergencyAlert,
        status: 'Cancelled',
        resolvedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        note: "False alarm cancelled by user."
      });
    }
    setIsSOSActive(false);
  };

  // Family Tasks
  const toggleCareTask = (taskId: string, notes?: string) => {
    setCareTasks(prev =>
      prev.map(task => {
        if (task.id === taskId) {
          const nextState = !task.completed;
          return {
            ...task,
            completed: nextState,
            completedAt: nextState ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : undefined,
            completedBy: nextState ? currentUser.name : undefined,
            notes: notes || task.notes
          };
        }
        return task;
      })
    );
  };

  const addCareTask = (task: Partial<CareTask>) => {
    const newTask: CareTask = {
      id: `task_${Date.now()}`,
      title: task.title || "New Care Task",
      description: task.description || "",
      category: task.category || "General",
      assignedTo: task.assignedTo || "Sister Anjali Rao",
      assignedToRole: task.assignedToRole || "Caregiver",
      dueDate: task.dueDate || "Today",
      timeSlot: task.timeSlot,
      completed: false,
      urgent: task.urgent || false
    };
    setCareTasks(prev => [newTask, ...prev]);
    addNotification({
      title: "Care Task Assigned",
      message: `Task '${newTask.title}' assigned to ${newTask.assignedTo}.`,
      type: "caregiver"
    });
  };

  const inviteFamilyMember = (member: Partial<FamilyMember>) => {
    const newMember: FamilyMember = {
      id: `fam_${Date.now()}`,
      name: member.name || "Family Member",
      relation: member.relation || "Relative",
      role: member.role || "Family Member",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80",
      phone: member.phone || "+91 90000 00000",
      email: member.email || "invite@mycare.ai",
      permissions: {
        canViewVitals: true,
        canManageMedicines: false,
        canBookAppointments: false,
        canReceiveSOS: true
      },
      lastActive: "Invited",
      status: "Pending Invite"
    };
    setFamilyMembers(prev => [...prev, newMember]);
    addNotification({
      title: "Care Circle Invitation Sent",
      message: `Invitation code dispatched to ${newMember.name} (${newMember.phone}).`,
      type: "system"
    });
  };

  // Notifications
  const addNotification = (notif: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>) => {
    const newNotif: NotificationItem = {
      id: `notif_${Date.now()}`,
      ...notif,
      timestamp: "Just now",
      read: false
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const unreadNotificationCount = notifications.filter(n => !n.read).length;

  // Health Vitals
  const addVitalRecord = (vital: Partial<HealthVital>) => {
    const newVital: HealthVital = {
      id: `vit_${Date.now()}`,
      date: "Today (Just now)",
      bloodPressureSystolic: vital.bloodPressureSystolic || 120,
      bloodPressureDiastolic: vital.bloodPressureDiastolic || 80,
      heartRate: vital.heartRate || 72,
      bloodGlucose: vital.bloodGlucose || 110,
      spo2: vital.spo2 || 98,
      recordedBy: currentUser.name
    };
    setVitals(prev => [newVital, ...prev]);
    addNotification({
      title: "Health Vitals Logged",
      message: `BP: ${newVital.bloodPressureSystolic}/${newVital.bloodPressureDiastolic} mmHg, Heart Rate: ${newVital.heartRate} bpm.`,
      type: "system"
    });
  };

  // AI Guardian Messaging
  const sendGuardianMessage = async (text: string) => {
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `msg_user_${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      language
    };

    setGuardianMessages(prev => [...prev, userMsg]);
    setIsGuardianTyping(true);

    const context = {
      patientName: mockUsers.elderly.name,
      age: mockUsers.elderly.age || 74,
      conditions: mockUsers.elderly.conditions || [],
      allergies: mockUsers.elderly.allergies || [],
      todayDoses,
      medicines,
      nextAppointment: appointments.find(a => a.status === 'Confirmed'),
      weeklyAdherence: 92,
      recentActivity: activityLogs.map(a => a.title)
    };

    try {
      const response = await AIService.queryGuardian(text, context, language);
      setGuardianMessages(prev => [...prev, response]);

      // If auto-voice is enabled, speak the answer
      if (autoVoiceEnabled) {
        VoiceService.speak(response.text, language);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsGuardianTyping(false);
    }
  };

  const clearGuardianChat = () => {
    setGuardianMessages([
      {
        id: "msg_cleared",
        sender: "guardian",
        text: "Conversation refreshed. How can I help you today?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        language
      }
    ]);
  };

  const openScanner = () => setIsScannerOpen(true);
  const closeScanner = () => setIsScannerOpen(false);

  const safeUser: UserProfile = currentUser || {
    id: "guest",
    name: "Guest Member",
    email: "guest@mycare.ai",
    phone: "",
    role: currentRole,
    avatar: "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=256&q=80",
    language: "en"
  };

  return (
    <AppContext.Provider
      value={{
        isAuthenticated,
        isDemoMode,
        currentUser: safeUser,
        currentRole,
        login,
        register,
        enterDemoMode,
        logout,
        switchRole,
        updateUserProfile,
        activePage,
        setActivePage,
        searchQuery,
        setSearchQuery,
        language,
        setLanguage,
        t: translations[language],
        isElderlyMode,
        setIsElderlyMode,
        fontSize,
        setFontSize,
        autoVoiceEnabled,
        setAutoVoiceEnabled,
        medicines,
        todayDoses,
        markDoseTaken,
        skipDose,
        addMedicine,
        deleteMedicine,
        catalogue,
        addCatalogueItem,
        importCatalogueCSV,
        resetCatalogue,
        cart,
        cartTotal,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        orders,
        placeOrder,
        doctors,
        appointments,
        bookAppointment,
        cancelAppointment,
        rescheduleAppointment,
        emergencyContacts,
        addEmergencyContact,
        updateEmergencyContact,
        deleteEmergencyContact,
        emergencyAlert,
        isSOSActive,
        triggerSOS,
        resolveSOS,
        cancelSOS,
        familyMembers,
        addFamilyMember,
        updateFamilyMember,
        deleteFamilyMember,
        careTasks,
        toggleCareTask,
        addCareTask,
        inviteFamilyMember,
        notifications,
        unreadNotificationCount,
        markNotificationRead,
        markAllNotificationsRead,
        vitals,
        addVitalRecord,
        activityLogs,
        guardianMessages,
        isGuardianTyping,
        sendGuardianMessage,
        clearGuardianChat,
        isScannerOpen,
        openScanner,
        closeScanner
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
