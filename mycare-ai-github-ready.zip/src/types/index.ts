// ==========================================
// MYCARE AI - COMPLETE TYPE DEFINITIONS
// ==========================================

export type UserRole = 'elderly' | 'family' | 'caregiver' | 'admin';

export type LanguageCode = 'en' | 'te' | 'hi';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar: string;
  age?: number;
  gender?: string;
  city?: string;
  bloodGroup?: string;
  conditions?: string[];
  allergies?: string[];
  primaryDoctor?: string;
  language: LanguageCode;
  emergencyContactId?: string;
  elderlyId?: string; // If family/caregiver, which elderly member they oversee
  isDemoData?: boolean;
}

export interface UserAccount {
  id: string;
  email: string;
  password?: string;
  name: string;
  role: UserRole;
  profile: UserProfile;
  isDemoAccount?: boolean;
  createdAt: string;
}

export interface UserPrivateData {
  medicines: Medicine[];
  todayDoses: ScheduledDose[];
  vitals: HealthVital[];
  appointments: Appointment[];
  familyMembers: FamilyMember[];
  careTasks: CareTask[];
  emergencyContacts: EmergencyContact[];
  orders: Order[];
  notifications: NotificationItem[];
  guardianMessages: ChatMessage[];
}

export type DoseStatus = 'taken' | 'pending' | 'missed' | 'skipped';

export interface ScheduledDose {
  id: string;
  medicineId: string;
  medicineName: string;
  strength: string;
  dosage: string;
  timeSlot: 'Morning' | 'Afternoon' | 'Evening' | 'Night';
  scheduledTime: string; // e.g. "08:00 AM"
  instructions: string; // e.g. "Take after breakfast with water"
  status: DoseStatus;
  takenAt?: string;
  skippedReason?: string;
  confirmedBy?: string; // user name or role
  colorTag?: string;
  shape?: 'tablet' | 'capsule' | 'syrup' | 'injection' | 'drops';
}

export interface Medicine {
  id: string;
  name: string;
  brand: string;
  strength: string;
  dosageForm: string; // Tablet, Capsule, Syrup, etc.
  frequency: string; // "Twice daily", "Once daily morning", etc.
  scheduleTimes: ('Morning' | 'Afternoon' | 'Evening' | 'Night')[];
  exactTimes: string[]; // ["08:00 AM", "08:00 PM"]
  dosage: string; // "1 tablet"
  startDate: string;
  endDate?: string;
  instructions: string;
  prescribedBy: string;
  image: string;
  category: string;
  remainingPills: number;
  refillThreshold: number;
  isPrescriptionRequired: boolean;
}

export type MedicineCategory = 
  | 'Fever & Pain'
  | 'Diabetes Care'
  | 'Heart Care'
  | 'Blood Pressure'
  | 'Thyroid Care'
  | 'Cold & Cough'
  | 'Digestive Care'
  | 'Vitamins & Nutrition'
  | 'First Aid'
  | 'Skin Care'
  | 'Senior Care & Devices'
  | 'General Healthcare';

export interface MedicineAlternative {
  id: string;
  name: string;
  brand: string;
  manufacturer: string;
  price: number;
  discountPrice?: number;
  savingsPercent: number;
}

export interface MedicineCatalogueItem {
  id: string;
  name: string;
  brand: string;
  strength: string;
  dosageForm: string;
  packSize: string;
  manufacturer: string;
  category: MedicineCategory;
  price: number;
  discountPrice?: number;
  inStock: boolean;
  stockCount: number;
  prescriptionRequired: boolean;
  image: string;
  description: string;
  activeIngredients: string;
  packagingInfo: string;
  rating?: number;
  reviewCount?: number;
  uses?: string[];
  sideEffects?: string[];
  safetyAdvice?: {
    alcohol?: string;
    driving?: string;
    kidney?: string;
    liver?: string;
    food?: string;
    pregnancy?: string;
  };
  alternatives?: MedicineAlternative[];
}

export interface ScannedMedicineResult {
  scanId: string;
  imageUri: string;
  extractedText: string;
  detectedName?: string;
  detectedBrand?: string;
  detectedStrength?: string;
  detectedManufacturer?: string;
  detectedDosageForm?: string;
  confidence: number; // 0 to 100
  matchedCatalogueItem?: MedicineCatalogueItem;
  possibleMatches: {
    item: MedicineCatalogueItem;
    matchScore: number;
    matchReasons: string[];
  }[];
  isPrescriptionDrug: boolean;
  safetyDisclaimer: string;
}

export interface CartItem {
  medicine: MedicineCatalogueItem;
  quantity: number;
}

export type OrderStatus = 
  | 'Pending'
  | 'Confirmed'
  | 'Prescription Verification'
  | 'Packed'
  | 'Shipped'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Cancelled';

export interface Order {
  id: string;
  orderNumber: string;
  date: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  deliveryFee: number;
  total: number;
  status: OrderStatus;
  deliveryAddress: string;
  estimatedDelivery: string;
  prescriptionUrl?: string;
  prescriptionStatus?: 'Verified' | 'Pending Review' | 'Not Required';
  paymentMethod: string;
}

export interface Doctor {
  id: string;
  name: string;
  specialization: string;
  qualifications: string;
  experienceYears: number;
  hospital: string;
  rating: number;
  reviewCount: number;
  consultationFee: number;
  image: string;
  about: string;
  languages: string[];
  availableSlots: {
    date: string; // YYYY-MM-DD
    slots: string[]; // ["09:30 AM", "11:00 AM", "04:30 PM"]
  }[];
}

export type AppointmentStatus = 'Confirmed' | 'Completed' | 'Rescheduled' | 'Cancelled';

export interface Appointment {
  id: string;
  doctorId: string;
  doctorName: string;
  specialization: string;
  doctorImage: string;
  hospital: string;
  date: string;
  time: string;
  type: 'In-person Clinic' | 'Video Consultation';
  status: AppointmentStatus;
  consultationFee: number;
  reason: string;
  notes?: string;
  meetingLink?: string;
}

export interface CareTask {
  id: string;
  title: string;
  description: string;
  category: 'Medication' | 'Vitals Check' | 'Mobility/Exercise' | 'Nutrition' | 'Doctor/Appointment' | 'General';
  assignedTo: string; // Caregiver or Family name
  assignedToRole: 'Caregiver' | 'Family';
  dueDate: string;
  timeSlot?: string;
  completed: boolean;
  completedAt?: string;
  completedBy?: string;
  notes?: string;
  urgent?: boolean;
}

export interface FamilyMember {
  id: string;
  name: string;
  relation: string;
  role: 'Family Member' | 'Primary Caregiver' | 'Care Coordinator';
  avatar: string;
  phone: string;
  email: string;
  permissions: {
    canViewVitals: boolean;
    canManageMedicines: boolean;
    canBookAppointments: boolean;
    canReceiveSOS: boolean;
  };
  lastActive: string;
  status: 'Active' | 'Pending Invite';
  isDemoData?: boolean;
}

export interface EmergencyContact {
  id: string;
  name: string;
  relation: string;
  phone: string;
  isPrimary: boolean;
  notifyOnSOS: boolean;
  isDemoData?: boolean;
}

export type EmergencyAlertStatus = 'Initiated' | 'Sent' | 'Acknowledged' | 'Resolved' | 'Cancelled';

export interface EmergencyAlert {
  id: string;
  timestamp: string;
  status: EmergencyAlertStatus;
  location?: {
    latitude: number;
    longitude: number;
    address: string;
  };
  notifiedContacts: string[];
  resolvedAt?: string;
  resolvedBy?: string;
  note?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'medicine' | 'appointment' | 'emergency' | 'caregiver' | 'family' | 'order' | 'system';
  timestamp: string;
  read: boolean;
  actionUrl?: string;
}

export interface HealthVital {
  id: string;
  date: string;
  bloodPressureSystolic: number;
  bloodPressureDiastolic: number;
  heartRate: number;
  bloodGlucose: number; // mg/dL
  spo2: number; // %
  recordedBy: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'guardian';
  text: string;
  timestamp: string;
  language: LanguageCode;
  actionRecommendation?: string;
  suggestedPills?: string[];
}
