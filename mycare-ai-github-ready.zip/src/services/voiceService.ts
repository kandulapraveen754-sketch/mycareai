// ==========================================
// MYCARE AI - MULTILINGUAL VOICE ENGINE
// Web Speech API: Speech-to-Text & Text-to-Speech
// Languages: English (en-IN), Telugu (te-IN), Hindi (hi-IN)
// ==========================================

import { LanguageCode } from '../types';

// SpeechRecognition type declarations for browser support
interface IWindow extends Window {
  webkitSpeechRecognition?: any;
  SpeechRecognition?: any;
}

export const getLanguageLocale = (lang: LanguageCode): string => {
  switch (lang) {
    case 'te':
      return 'te-IN'; // Telugu India
    case 'hi':
      return 'hi-IN'; // Hindi India
    case 'en':
    default:
      return 'en-IN'; // English India
  }
};

export class VoiceService {
  private static recognition: any = null;

  public static isSpeechRecognitionSupported(): boolean {
    if (typeof window === 'undefined') return false;
    const win = window as unknown as IWindow;
    return !!(win.SpeechRecognition || win.webkitSpeechRecognition);
  }

  public static isTextToSpeechSupported(): boolean {
    if (typeof window === 'undefined') return false;
    return 'speechSynthesis' in window;
  }

  public static startListening(
    lang: LanguageCode,
    onResult: (transcript: string, isFinal: boolean) => void,
    onError: (error: string) => void,
    onEnd: () => void
  ): boolean {
    if (!this.isSpeechRecognitionSupported()) {
      onError("Speech recognition is not supported in this browser. Please use text input.");
      return false;
    }

    try {
      this.stopListening();

      const win = window as unknown as IWindow;
      const SpeechClass = win.SpeechRecognition || win.webkitSpeechRecognition;
      this.recognition = new SpeechClass();

      this.recognition.lang = getLanguageLocale(lang);
      this.recognition.continuous = false;
      this.recognition.interimResults = true;
      this.recognition.maxAlternatives = 1;

      this.recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        if (finalTranscript) {
          onResult(finalTranscript, true);
        } else if (interimTranscript) {
          onResult(interimTranscript, false);
        }
      };

      this.recognition.onerror = (event: any) => {
        console.warn("Speech recognition error:", event.error);
        onError(event.error === 'not-allowed' 
          ? "Microphone access blocked. Please allow microphone permission in browser settings." 
          : `Speech input error: ${event.error}`);
      };

      this.recognition.onend = () => {
        onEnd();
      };

      this.recognition.start();
      return true;
    } catch (err: any) {
      console.error("Failed to start speech recognition:", err);
      onError(err?.message || "Failed to start speech recognition");
      return false;
    }
  }

  public static stopListening() {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch (e) {
        // ignore
      }
      this.recognition = null;
    }
  }

  public static speak(text: string, lang: LanguageCode, onEnd?: () => void) {
    if (!this.isTextToSpeechSupported()) return;

    try {
      window.speechSynthesis.cancel(); // Stop any active speech

      // Clean markdown tags or emojis if any
      const cleanText = text
        .replace(/[#*_`]/g, '')
        .replace(/\[.*?\]/g, '')
        .trim();

      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.lang = getLanguageLocale(lang);
      utterance.rate = 0.95; // Slightly slower, calm cadence for elderly clarity
      utterance.pitch = 1.0;

      // Select localized voice if available
      const voices = window.speechSynthesis.getVoices();
      const targetLang = getLanguageLocale(lang);
      const matchedVoice = voices.find(v => v.lang === targetLang || v.lang.startsWith(lang));
      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }

      if (onEnd) {
        utterance.onend = onEnd;
        utterance.onerror = onEnd;
      }

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn("Speech synthesis error:", e);
    }
  }

  public static stopSpeaking() {
    if (this.isTextToSpeechSupported()) {
      window.speechSynthesis.cancel();
    }
  }
}
