// ==========================================
// MYCARE AI - CLIENT AUTHENTICATION & USER DATA SERVICE
// Handles Registration, Login, Forgot Password,
// Cryptographic Token Storage, User Data Isolation & Per-User Persistence
// ==========================================

import { UserAccount, UserProfile, UserPrivateData, UserRole } from '../types';

const API_BASE = ''; // Same origin in production Express server or relative

const LOCAL_STORAGE_USERS_KEY = 'mycare_users_db_v1';
const SESSION_STORAGE_KEY = 'mycare_active_session_v1';
const TOKEN_STORAGE_KEY = 'mycare_auth_token_v1';
const USER_DATA_PREFIX = 'mycare_userdata_';

// Helper for local storage accounts fallback
function getLocalAccounts(): Record<string, UserAccount> {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_USERS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    return {};
  }
}

function saveLocalAccounts(accounts: Record<string, UserAccount>) {
  try {
    localStorage.setItem(LOCAL_STORAGE_USERS_KEY, JSON.stringify(accounts));
  } catch (e) {
    console.error('Failed to save local accounts:', e);
  }
}

export const AuthService = {
  // Get stored auth token
  getToken(): string | null {
    try {
      return sessionStorage.getItem(TOKEN_STORAGE_KEY) || localStorage.getItem(TOKEN_STORAGE_KEY);
    } catch {
      return null;
    }
  },

  setToken(token: string) {
    try {
      sessionStorage.setItem(TOKEN_STORAGE_KEY, token);
      localStorage.setItem(TOKEN_STORAGE_KEY, token);
    } catch {}
  },

  clearToken() {
    try {
      sessionStorage.removeItem(TOKEN_STORAGE_KEY);
      localStorage.removeItem(TOKEN_STORAGE_KEY);
    } catch {}
  },

  getAuthHeaders(): Record<string, string> {
    const token = this.getToken();
    return {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    };
  },

  // Check active session (session-based, so tab close or logout returns to login)
  getActiveSession(): { user: UserProfile; isDemo: boolean } | null {
    try {
      const raw = sessionStorage.getItem(SESSION_STORAGE_KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  },

  setActiveSession(user: UserProfile, isDemo: boolean = false) {
    try {
      sessionStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify({ user, isDemo }));
    } catch (e) {
      console.error('Failed to save session:', e);
    }
  },

  clearSession() {
    try {
      sessionStorage.removeItem(SESSION_STORAGE_KEY);
      this.clearToken();
    } catch (e) {
      console.error('Failed to clear session:', e);
    }
  },

  // Input Validation Helpers
  validateEmail(email: string): boolean {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email.trim().toLowerCase());
  },

  validatePassword(password: string): { valid: boolean; message?: string } {
    if (!password || password.length < 6) {
      return { valid: false, message: 'Password must be at least 6 characters long.' };
    }
    return { valid: true };
  },

  // Register new account
  async register(params: {
    email: string;
    password: string;
    name: string;
    role?: UserRole;
    phone?: string;
    age?: number;
    gender?: string;
    city?: string;
    bloodGroup?: string;
    conditions?: string[];
    allergies?: string[];
    primaryDoctor?: string;
    emergencyContact?: { name: string; relation: string; phone: string };
  }): Promise<{ success: boolean; user?: UserProfile; error?: string }> {
    const normalizedEmail = params.email.trim().toLowerCase();

    if (!this.validateEmail(normalizedEmail)) {
      return { success: false, error: 'Please enter a valid email address.' };
    }

    const passCheck = this.validatePassword(params.password);
    if (!passCheck.valid) {
      return { success: false, error: passCheck.message };
    }

    // Try backend API first
    try {
      const response = await fetch(`${API_BASE}/api/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
      const data = await response.json();
      if (response.ok && data.success) {
        if (data.token) {
          this.setToken(data.token);
        }
        this.saveUserLocally(data.user, params.password);
        this.setActiveSession(data.user, false);
        return { success: true, user: data.user };
      } else {
        return { success: false, error: data.error || 'Registration failed.' };
      }
    } catch (netErr) {
      // Offline / Local fallback
      console.warn('Backend unavailable, registering in local browser storage:', netErr);
      const accounts = getLocalAccounts();
      if (accounts[normalizedEmail]) {
        return { success: false, error: 'An account with this email already exists.' };
      }

      const userId = `usr_${Date.now()}`;
      const userProfile: UserProfile = {
        id: userId,
        name: params.name.trim(),
        email: normalizedEmail,
        phone: params.phone?.trim() || '',
        role: params.role || 'elderly',
        avatar: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=256&q=80',
        age: params.age || 70,
        gender: params.gender || 'Other',
        city: params.city?.trim() || '',
        bloodGroup: params.bloodGroup || 'O+',
        conditions: params.conditions || [],
        allergies: params.allergies || [],
        primaryDoctor: params.primaryDoctor?.trim() || '',
        language: 'en',
        isDemoData: false
      };

      const account: UserAccount = {
        id: userId,
        email: normalizedEmail,
        password: params.password,
        name: params.name.trim(),
        role: userProfile.role,
        profile: userProfile,
        isDemoAccount: false,
        createdAt: new Date().toISOString()
      };

      accounts[normalizedEmail] = account;
      saveLocalAccounts(accounts);

      const starterData: UserPrivateData = {
        medicines: [],
        todayDoses: [],
        vitals: [],
        appointments: [],
        familyMembers: [],
        careTasks: [],
        emergencyContacts: params.emergencyContact ? [
          {
            id: `em_${Date.now()}`,
            name: params.emergencyContact.name,
            relation: params.emergencyContact.relation,
            phone: params.emergencyContact.phone,
            isPrimary: true,
            notifyOnSOS: true,
            isDemoData: false
          }
        ] : [],
        orders: [],
        notifications: [
          {
            id: `notif_${Date.now()}`,
            title: 'Welcome to MyCare AI!',
            message: `Hello ${params.name}! Your account is now active. You can add medicines, set reminders, and connect family members.`,
            type: 'system',
            timestamp: 'Just now',
            read: false
          }
        ],
        guardianMessages: [
          {
            id: `msg_welcome_${Date.now()}`,
            sender: 'guardian',
            text: `Hello ${params.name}! I am your MyCare AI Guardian. How may I assist you with your health schedule today?`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            language: 'en',
            suggestedPills: [
              "How do I add a new medicine?",
              "How do I book a doctor appointment?",
              "What should I do in an emergency?"
            ]
          }
        ]
      };
      this.saveUserData(userId, starterData);
      this.setToken(`local_token_${userId}`);
      this.setActiveSession(userProfile, false);
      return { success: true, user: userProfile };
    }
  },

  // Log in
  async login(email: string, password: string): Promise<{ success: boolean; user?: UserProfile; error?: string }> {
    const normalizedEmail = email.trim().toLowerCase();

    // Try backend API first
    try {
      const response = await fetch(`${API_BASE}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: normalizedEmail, password })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        if (data.token) {
          this.setToken(data.token);
        }
        this.saveUserLocally(data.user, password);
        this.setActiveSession(data.user, false);
        return { success: true, user: data.user };
      } else {
        return { success: false, error: data.error || 'Invalid email or password.' };
      }
    } catch (netErr) {
      // Local fallback
      console.warn('Backend unavailable, checking local storage:', netErr);
      const accounts = getLocalAccounts();
      const account = accounts[normalizedEmail];
      if (!account || account.password !== password) {
        return { success: false, error: 'Invalid email or password.' };
      }
      this.setToken(`local_token_${account.id}`);
      this.setActiveSession(account.profile, false);
      return { success: true, user: account.profile };
    }
  },

  // Forgot password request
  async requestForgotPassword(email: string): Promise<{ success: boolean; message?: string; simulationOtp?: string; error?: string }> {
    const normalizedEmail = email.trim().toLowerCase();
    try {
      const response = await fetch(`${API_BASE}/api/auth/forgot-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: normalizedEmail })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        return { success: true, message: data.message, simulationOtp: data.simulationOtp };
      } else {
        return { success: false, error: data.error || 'Failed to request password reset.' };
      }
    } catch (err) {
      const accounts = getLocalAccounts();
      if (!accounts[normalizedEmail]) {
        return { success: false, error: 'No account registered with this email address.' };
      }
      return {
        success: true,
        message: 'Password reset code generated.',
        simulationOtp: '492016'
      };
    }
  },

  // Reset password
  async resetPassword(email: string, otp: string, newPassword: string): Promise<{ success: boolean; message?: string; error?: string }> {
    const normalizedEmail = email.trim().toLowerCase();
    try {
      const response = await fetch(`${API_BASE}/api/auth/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: normalizedEmail, otp, newPassword })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        const accounts = getLocalAccounts();
        if (accounts[normalizedEmail]) {
          accounts[normalizedEmail].password = newPassword;
          saveLocalAccounts(accounts);
        }
        return { success: true, message: data.message };
      } else {
        return { success: false, error: data.error || 'Failed to reset password.' };
      }
    } catch (err) {
      const accounts = getLocalAccounts();
      if (!accounts[normalizedEmail]) {
        return { success: false, error: 'Account not found.' };
      }
      if (otp.trim() !== '492016') {
        return { success: false, error: 'Invalid verification code.' };
      }
      accounts[normalizedEmail].password = newPassword;
      saveLocalAccounts(accounts);
      return { success: true, message: 'Password has been successfully updated.' };
    }
  },

  // Load User's Private Isolated Data
  async loadUserData(userId: string): Promise<UserPrivateData | null> {
    try {
      const response = await fetch(`${API_BASE}/api/user/data/${userId}`, {
        headers: this.getAuthHeaders()
      });
      if (response.ok) {
        const json = await response.json();
        if (json.data) {
          localStorage.setItem(`${USER_DATA_PREFIX}${userId}`, JSON.stringify(json.data));
          return json.data;
        }
      }
    } catch (e) {
      // Fall through to localStorage
    }

    try {
      const raw = localStorage.getItem(`${USER_DATA_PREFIX}${userId}`);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  },

  // Save User's Private Isolated Data
  async saveUserData(userId: string, data: Partial<UserPrivateData>) {
    try {
      const currentRaw = localStorage.getItem(`${USER_DATA_PREFIX}${userId}`);
      const current = currentRaw ? JSON.parse(currentRaw) : {};
      const updated = { ...current, ...data };
      localStorage.setItem(`${USER_DATA_PREFIX}${userId}`, JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to save to local storage:', e);
    }

    try {
      fetch(`${API_BASE}/api/user/data/${userId}`, {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify(data)
      }).catch(() => {});
    } catch (e) {}
  },

  // Update User Profile
  async updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<UserProfile | null> {
    const accounts = getLocalAccounts();
    for (const [email, acc] of Object.entries(accounts)) {
      if (acc.id === userId) {
        accounts[email].profile = { ...acc.profile, ...updates };
        if (updates.name) accounts[email].name = updates.name;
        saveLocalAccounts(accounts);
        const session = this.getActiveSession();
        if (session && session.user.id === userId) {
          this.setActiveSession(accounts[email].profile, session.isDemo);
        }
        break;
      }
    }

    try {
      const response = await fetch(`${API_BASE}/api/user/profile/${userId}`, {
        method: 'PUT',
        headers: this.getAuthHeaders(),
        body: JSON.stringify(updates)
      });
      if (response.ok) {
        const json = await response.json();
        return json.user;
      }
    } catch (e) {}

    return null;
  },

  saveUserLocally(user: UserProfile, password?: string) {
    const accounts = getLocalAccounts();
    accounts[user.email] = {
      id: user.id,
      email: user.email,
      password: password || 'SavedPassword123',
      name: user.name,
      role: user.role,
      profile: user,
      isDemoAccount: false,
      createdAt: new Date().toISOString()
    };
    saveLocalAccounts(accounts);
  }
};
