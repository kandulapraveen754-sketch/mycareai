import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'events';
import { app, generateAuthToken } from '../server/index.js';

function mockRequest(app, { method = 'GET', url = '/', body = {}, headers = {} }) {
  return new Promise((resolve) => {
    const req = new EventEmitter();
    req.method = method;
    req.url = url;
    req.originalUrl = url;
    req.path = url.split('?')[0];
    req.headers = {
      'content-type': 'application/json',
      ...headers
    };
    req.body = body;
    req.query = {};
    req.params = {};
    req.ip = '127.0.0.1';
    req.socket = { remoteAddress: '127.0.0.1' };

    const res = new EventEmitter();
    let statusCode = 200;
    let headersSent = {};
    let responseBody = '';

    res.status = function (code) {
      statusCode = code;
      return this;
    };
    res.setHeader = function (k, v) {
      headersSent[k.toLowerCase()] = v;
      return this;
    };
    res.getHeader = function (k) {
      return headersSent[k.toLowerCase()];
    };
    res.json = function (obj) {
      responseBody = obj;
      resolve({ status: statusCode, body: responseBody, headers: headersSent });
      return this;
    };
    res.send = function (data) {
      responseBody = data;
      resolve({ status: statusCode, body: responseBody, headers: headersSent });
      return this;
    };

    app.handle(req, res);
  });
}

test('API Integration: Security Headers & Health', async () => {
  const res = await mockRequest(app, { method: 'GET', url: '/api/health' });
  assert.equal(res.status, 200);
  assert.equal(res.body.status, 'online');
  assert.equal(res.body.product, 'MyCare AI');
  assert.equal(res.headers['x-content-type-options'], 'nosniff');
  assert.equal(res.headers['x-frame-options'], 'SAMEORIGIN');
});

test('API Integration: Authentication & Input Validation', async (t) => {
  const testEmail = `patient_test_${Date.now()}@example.com`;

  await t.test('rejects registration with missing fields', async () => {
    const res = await mockRequest(app, {
      method: 'POST',
      url: '/api/auth/register',
      body: { email: '', password: '', name: '' }
    });
    assert.equal(res.status, 400);
    assert.ok(res.body.error);
  });

  await t.test('rejects registration with short password (< 6 chars)', async () => {
    const res = await mockRequest(app, {
      method: 'POST',
      url: '/api/auth/register',
      body: { email: testEmail, password: '123', name: 'Ramesh' }
    });
    assert.equal(res.status, 400);
    assert.ok(res.body.error.includes('at least 6 characters'));
  });

  await t.test('successfully registers patient with PBKDF2 hash & HMAC token', async () => {
    const res = await mockRequest(app, {
      method: 'POST',
      url: '/api/auth/register',
      body: {
        email: testEmail,
        password: 'ValidPassword@123',
        name: 'Ramesh Sharma',
        role: 'elderly',
        age: 72,
        city: 'Hyderabad'
      }
    });
    assert.equal(res.status, 200);
    assert.equal(res.body.success, true);
    assert.ok(res.body.token);
    assert.equal(res.body.user.name, 'Ramesh Sharma');
    assert.equal(res.body.user.role, 'elderly');
  });

  await t.test('rejects duplicate email registration', async () => {
    const res = await mockRequest(app, {
      method: 'POST',
      url: '/api/auth/register',
      body: {
        email: testEmail,
        password: 'ValidPassword@123',
        name: 'Duplicate Patient'
      }
    });
    assert.equal(res.status, 409);
    assert.ok(res.body.error.includes('already exists'));
  });

  await t.test('authenticates patient with correct credentials', async () => {
    const res = await mockRequest(app, {
      method: 'POST',
      url: '/api/auth/login',
      body: { email: testEmail, password: 'ValidPassword@123' }
    });
    assert.equal(res.status, 200);
    assert.equal(res.body.success, true);
    assert.ok(res.body.token);
  });

  await t.test('rejects login with incorrect password', async () => {
    const res = await mockRequest(app, {
      method: 'POST',
      url: '/api/auth/login',
      body: { email: testEmail, password: 'WrongPassword' }
    });
    assert.equal(res.status, 401);
  });
});

test('API Integration: Authorization & IDOR Protection', async (t) => {
  const patientAId = 'usr_patient_A';
  const patientBId = 'usr_patient_B';
  const tokenA = generateAuthToken(patientAId, 'elderly');

  await t.test('rejects unauthenticated access to patient data', async () => {
    const res = await mockRequest(app, {
      method: 'GET',
      url: `/api/user/data/${patientAId}`
    });
    assert.equal(res.status, 401, 'Must reject request with missing token');
  });

  await t.test('allows patient to access their own private data', async () => {
    const res = await mockRequest(app, {
      method: 'GET',
      url: `/api/user/data/${patientAId}`,
      headers: { 'authorization': `Bearer ${tokenA}` }
    });
    assert.equal(res.status, 200);
    assert.equal(res.body.success, true);
  });

  await t.test('blocks IDOR attack when patient A tries to access patient B data', async () => {
    const res = await mockRequest(app, {
      method: 'GET',
      url: `/api/user/data/${patientBId}`,
      headers: { 'authorization': `Bearer ${tokenA}` }
    });
    assert.equal(res.status, 403, 'Must forbid cross-patient access attempt (IDOR)');
  });
});

test('API Integration: AI Guardian & Packaging Scanner', async (t) => {
  await t.test('packaging scanner performs OCR analysis and checks prescription safety', async () => {
    const res = await mockRequest(app, {
      method: 'POST',
      url: '/api/scanner/analyze',
      body: { image: 'sample_strip' }
    });
    assert.equal(res.status, 200);
    assert.equal(res.body.detectedName, 'Telmikind 40');
    assert.equal(res.body.isPrescriptionDrug, true);
    assert.ok(res.body.safetyDisclaimer.includes('consult your pharmacist'));
  });

  await t.test('guardian provides triage advice on emergency queries', async () => {
    const res = await mockRequest(app, {
      method: 'POST',
      url: '/api/guardian/chat',
      body: {
        query: 'I am feeling severe chest pressure and dizziness',
        context: { patientName: 'Ramesh', age: 72 }
      }
    });
    assert.equal(res.status, 200);
    assert.ok(res.body.reply.includes('CRITICAL ALERT') || res.body.reply.includes('EMERGENCY SOS'));
    assert.ok(res.body.disclaimer.includes('does not provide medical diagnoses'));
  });

  await t.test('guardian provides reminder coordination for medicine questions', async () => {
    const res = await mockRequest(app, {
      method: 'POST',
      url: '/api/guardian/chat',
      body: {
        query: 'What medicines should I take?',
        context: {
          patientName: 'Ramesh',
          todayDoses: [{ name: 'Telma 40', status: 'pending' }]
        }
      }
    });
    assert.equal(res.status, 200);
    assert.ok(res.body.reply.includes('pending medicine dose'));
  });
});
