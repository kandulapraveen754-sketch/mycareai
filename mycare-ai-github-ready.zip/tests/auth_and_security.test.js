import test from 'node:test';
import assert from 'node:assert/strict';
import { hashPassword, verifyPassword, generateAuthToken, verifyAuthToken } from '../server/index.js';

test('Security: PBKDF2 Password Hashing & Salt', async (t) => {
  await t.test('generates unique hash and salt for identical passwords', () => {
    const p1 = hashPassword('SecretPass123');
    const p2 = hashPassword('SecretPass123');
    assert.notEqual(p1.salt, p2.salt, 'Salts must be cryptographically unique');
    assert.notEqual(p1.hash, p2.hash, 'Hashes must differ due to unique salts');
    assert.equal(p1.hash.length, 128, 'SHA-512 hex hash must be 128 chars');
  });

  await t.test('verifies correct password against hash and salt', () => {
    const { hash, salt } = hashPassword('MyCareSafePassword@2026');
    const isValid = verifyPassword('MyCareSafePassword@2026', hash, salt);
    assert.equal(isValid, true, 'Valid password must verify');
  });

  await t.test('rejects incorrect password against hash and salt', () => {
    const { hash, salt } = hashPassword('CorrectPassword');
    const isValid = verifyPassword('WrongPassword', hash, salt);
    assert.equal(isValid, false, 'Wrong password must be rejected');
  });

  await t.test('handles backward compatibility for legacy plain text passwords', () => {
    const isValid = verifyPassword('LegacyPass123', 'LegacyPass123', null);
    assert.equal(isValid, true, 'Legacy plain text password must match');
  });
});

test('Security: Cryptographic HMAC-SHA256 Auth Tokens', async (t) => {
  await t.test('generates signed 3-part token', () => {
    const token = generateAuthToken('usr_test_123', 'elderly');
    const parts = token.split('.');
    assert.equal(parts.length, 3, 'Token must contain Header.Payload.Signature');
  });

  await t.test('verifies valid token payload and signature', () => {
    const token = generateAuthToken('usr_patient_456', 'elderly');
    const decoded = verifyAuthToken(token);
    assert.notEqual(decoded, null, 'Valid token must decode');
    assert.equal(decoded.userId, 'usr_patient_456');
    assert.equal(decoded.role, 'elderly');
  });

  await t.test('rejects tampered token signature', () => {
    const token = generateAuthToken('usr_patient_456', 'elderly');
    const parts = token.split('.');
    // Tamper with payload (elevate role to admin)
    const tamperedPayload = Buffer.from(JSON.stringify({ userId: 'usr_patient_456', role: 'admin' })).toString('base64url');
    const tamperedToken = `${parts[0]}.${tamperedPayload}.${parts[2]}`;
    const decoded = verifyAuthToken(tamperedToken);
    assert.equal(decoded, null, 'Tampered token must fail signature verification');
  });

  await t.test('supports backward-compatible legacy session tokens', () => {
    const decoded = verifyAuthToken('token_usr_legacy_999');
    assert.notEqual(decoded, null);
    assert.equal(decoded.userId, 'usr_legacy_999');
  });
});
