import test from 'node:test';
import assert from 'node:assert/strict';

// Core domain logic tests for Medication Management & Pharmacy Cart
test('Clinical Domain Logic: Medication Adherence & Schedules', async (t) => {
  await t.test('calculates adherence rate accurately based on taken vs scheduled doses', () => {
    const weeklyRecords = [
      { day: 'Mon', scheduled: 4, taken: 4 },
      { day: 'Tue', scheduled: 4, taken: 4 },
      { day: 'Wed', scheduled: 4, taken: 3 },
      { day: 'Thu', scheduled: 4, taken: 4 },
      { day: 'Fri', scheduled: 4, taken: 4 },
      { day: 'Sat', scheduled: 4, taken: 3 },
      { day: 'Sun', scheduled: 4, taken: 4 },
    ];

    const totalScheduled = weeklyRecords.reduce((acc, r) => acc + r.scheduled, 0);
    const totalTaken = weeklyRecords.reduce((acc, r) => acc + r.taken, 0);
    const adherence = Math.round((totalTaken / totalScheduled) * 100);

    assert.equal(totalScheduled, 28);
    assert.equal(totalTaken, 26);
    assert.equal(adherence, 93, 'Adherence should be 93% (26/28)');
  });

  await t.test('accurately identifies missed doses and schedules alerts', () => {
    const currentHour = 15; // 3:00 PM
    const doses = [
      { id: 'd1', name: 'Telma 40', time: '08:00 AM', hour24: 8, status: 'taken' },
      { id: 'd2', name: 'Metformin 500', time: '01:00 PM', hour24: 13, status: 'pending' },
      { id: 'd3', name: 'Atorvastatin 10', time: '09:00 PM', hour24: 21, status: 'pending' },
    ];

    // Detect missed doses (past time and still pending)
    const overdueDoses = doses.filter(d => d.status === 'pending' && d.hour24 < currentHour);
    assert.equal(overdueDoses.length, 1, 'Dose 2 should be flagged as overdue');
    assert.equal(overdueDoses[0].name, 'Metformin 500');
  });
});

test('Pharmacy Cart & Prescription Validation Logic', async (t) => {
  const sampleCatalogue = [
    { id: 'med_1', name: 'Telmikind 40', price: 54.50, isPrescriptionRequired: true },
    { id: 'med_2', name: 'Paracetamol 650', price: 32.00, isPrescriptionRequired: false },
    { id: 'med_3', name: 'Vitamin C Chewable', price: 95.00, isPrescriptionRequired: false },
  ];

  await t.test('calculates cart subtotal, discount, and delivery fee correctly', () => {
    const cart = [
      { medicine: sampleCatalogue[0], quantity: 2 }, // 54.50 * 2 = 109.00
      { medicine: sampleCatalogue[1], quantity: 3 }, // 32.00 * 3 = 96.00
    ];

    const subtotal = cart.reduce((sum, item) => sum + item.medicine.price * item.quantity, 0);
    assert.equal(subtotal, 205.00);

    // Free delivery over ₹500, else ₹40
    const deliveryFee = subtotal >= 500 ? 0 : 40;
    assert.equal(deliveryFee, 40);

    // Senior citizen 10% discount
    const discount = Math.round(subtotal * 0.10);
    assert.equal(discount, 21);

    const total = subtotal - discount + deliveryFee;
    assert.equal(total, 224.00);
  });

  await t.test('detects when prescription is required for cart items', () => {
    const cartWithRx = [
      { medicine: sampleCatalogue[0], quantity: 1 }, // Requires Rx
      { medicine: sampleCatalogue[1], quantity: 1 }
    ];
    const cartWithoutRx = [
      { medicine: sampleCatalogue[1], quantity: 1 },
      { medicine: sampleCatalogue[2], quantity: 1 }
    ];

    const rxRequiredA = cartWithRx.some(item => item.medicine.isPrescriptionRequired);
    const rxRequiredB = cartWithoutRx.some(item => item.medicine.isPrescriptionRequired);

    assert.equal(rxRequiredA, true, 'Cart with Schedule H drug must require prescription');
    assert.equal(rxRequiredB, false, 'Cart with only OTC drugs must not require prescription');
  });

  await t.test('enforces checkout validation rule: prescription verification check', () => {
    const validateCheckout = (cart, hasPrescriptionUploaded) => {
      const needsRx = cart.some(item => item.medicine.isPrescriptionRequired);
      if (needsRx && !hasPrescriptionUploaded) {
        return { canCheckout: false, error: 'A valid doctor prescription is required to order prescription medicines.' };
      }
      return { canCheckout: true };
    };

    const cart = [{ medicine: sampleCatalogue[0], quantity: 1 }];
    const failAttempt = validateCheckout(cart, false);
    assert.equal(failAttempt.canCheckout, false);
    assert.ok(failAttempt.error.includes('prescription is required'));

    const successAttempt = validateCheckout(cart, true);
    assert.equal(successAttempt.canCheckout, true);
  });
});
