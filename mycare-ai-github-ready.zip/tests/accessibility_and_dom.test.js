import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.join(__dirname, '..');

test('Accessibility (WCAG 2.1 AA) & HTML Standards Verification', async (t) => {
  const indexHtmlPath = path.join(rootDir, 'index.html');
  const indexHtml = fs.readFileSync(indexHtmlPath, 'utf8');

  await t.test('index.html specifies language attribute', () => {
    assert.match(indexHtml, /<html\s+lang="en"/i, 'HTML element must declare language attribute');
  });

  await t.test('index.html contains responsive viewport meta tag', () => {
    assert.match(indexHtml, /<meta\s+name="viewport"\s+content="width=device-width,\s*initial-scale=1\.0"/i);
  });

  await t.test('index.html specifies descriptive document title and theme color', () => {
    assert.match(indexHtml, /<title>MyCare AI/i);
    assert.match(indexHtml, /<meta\s+name="theme-color"/i);
  });

  const appTsxPath = path.join(rootDir, 'src', 'App.tsx');
  const appTsx = fs.readFileSync(appTsxPath, 'utf8');

  await t.test('App.tsx implements bypass blocks (skip to main content link)', () => {
    assert.match(appTsx, /href="#main-content"/i, 'Must have skip-to-content anchor');
    assert.match(appTsx, /Skip to main content/i);
  });

  await t.test('App.tsx provides main semantic landmark with matching target ID', () => {
    assert.match(appTsx, /id="main-content"/i);
    assert.match(appTsx, /role="main"/i);
  });

  await t.test('Loading states implement ARIA live regions and status roles', () => {
    assert.match(appTsx, /role="status"/i);
    assert.match(appTsx, /aria-live="polite"/i);
  });
});
